/**
 * Market explorer: filters, survey map and results kept in sync.
 *
 * The server renders the filtered list and map, and the form works as a plain GET
 * request. This module adds live filtering, panning and zooming, and pin and card
 * selection. The list is always the primary, complete view; the map is a companion.
 */
import { store, getContext, getElement } from '@wordpress/interactivity';

const MIN_W = 110; // Smallest view box width: about eight times zoom.
let drag = null;

const num = ( value ) => {
	const clean = String( value ?? '' ).replace( /[,$%\s]/g, '' );
	return clean === '' || isNaN( Number( clean ) ) ? null : Number( clean );
};

const matches = ( item, f ) => {
	const q = String( f.q || '' )
		.trim()
		.toLowerCase();
	if ( q && ! String( item.search || '' ).includes( q ) ) {
		return false;
	}
	if ( f.type && item.type !== f.type ) {
		return false;
	}
	if ( f.market && Number( item.market ) !== Number( f.market ) ) {
		return false;
	}
	if ( f.listing && item.listing !== f.listing ) {
		return false;
	}
	const ranges = [
		[ 'min_size', 'size', ( v, l ) => v >= l ],
		[ 'max_size', 'size', ( v, l ) => v <= l ],
		[ 'min_price', 'price', ( v, l ) => v >= l ],
		[ 'max_price', 'price', ( v, l ) => v <= l ],
		[ 'min_cap', 'cap', ( v, l ) => v >= l ],
		[ 'min_rent', 'lease', ( v, l ) => v >= l ],
		[ 'max_rent', 'lease', ( v, l ) => v <= l ],
	];
	for ( const [ key, field, test ] of ranges ) {
		const limit = num( f[ key ] );
		if ( limit === null ) {
			continue;
		}
		if (
			item[ field ] === null ||
			item[ field ] === undefined ||
			! test( item[ field ], limit )
		) {
			return false;
		}
	}
	return true;
};

// Same projection as Axis_CRE\Map::project(), so the first paint does not jump.
function project( points ) {
	const pts = points.filter(
		( p ) => Number.isFinite( p.lat ) && Number.isFinite( p.lng )
	);
	if ( ! pts.length ) {
		return null;
	}
	const [ , , W, H ] = state.vb0;
	const lats = pts.map( ( p ) => p.lat );
	const lngs = pts.map( ( p ) => p.lng );
	const minLat = Math.min( ...lats );
	const maxLat = Math.max( ...lats );
	const minLng = Math.min( ...lngs );
	const maxLng = Math.max( ...lngs );
	const spanLat = Math.max( maxLat - minLat, 0.02 );
	const spanLng = Math.max( maxLng - minLng, 0.02 );
	const midLat = ( minLat + maxLat ) / 2;
	const midLng = ( minLng + maxLng ) / 2;
	const k = Math.cos( ( midLat * Math.PI ) / 180 );
	const scale = Math.min(
		W / ( spanLng * k * 1.28 ),
		H / ( spanLat * 1.28 )
	);
	return { midLat, midLng, k, scale };
}

function place( b, lat, lng ) {
	const [ , , W, H ] = state.vb0;
	return [
		W / 2 + ( lng - b.midLng ) * b.k * b.scale,
		H / 2 - ( lat - b.midLat ) * b.scale,
	];
}

function resetView() {
	state.vb = [ ...state.vb0 ];
	state.limit = state.pageSize;
}

function syncUrl() {
	const url = new URL( window.location.href );
	for ( const [ key, value ] of Object.entries( state.filters ) ) {
		if ( value ) {
			url.searchParams.set( key, value );
		} else {
			url.searchParams.delete( key );
		}
	}
	url.searchParams.delete( 'axis_page' );
	window.history.replaceState( null, '', url );
}

function clamp( vb ) {
	const [ X, Y, W, H ] = state.vb0;
	const [ x, y, w, h ] = vb;
	return [
		Math.min( Math.max( x, X - w * 0.25 ), X + W - w * 0.75 ),
		Math.min( Math.max( y, Y - h * 0.25 ), Y + H - h * 0.75 ),
		w,
		h,
	];
}

function zoomBy( factor, cx, cy ) {
	const [ x, y, w, h ] = state.vb;
	const nw = Math.min( state.vb0[ 2 ], Math.max( MIN_W, w * factor ) );
	const k = nw / w;
	const px = cx ?? x + w / 2;
	const py = cy ?? y + h / 2;
	state.vb = clamp( [ px - ( px - x ) * k, py - ( py - y ) * k, nw, h * k ] );
}

function panBy( dx, dy ) {
	const [ x, y, w, h ] = state.vb;
	state.vb = clamp( [ x + dx, y + dy, w, h ] );
}

function selectCluster( mid, ref ) {
	state.filters.market = String( mid );
	const select = ref
		.closest( '.axis-cre-explorer' )
		.querySelector( 'select[name="market"]' );
	if ( select ) {
		select.value = String( mid );
	}
	resetView();
	syncUrl();
}

function selectPin( pid ) {
	state.selected = pid;
	const index = state.inView.findIndex( ( item ) => item.id === pid );
	if ( index >= state.limit ) {
		state.limit = index + 1;
	}
	window.requestAnimationFrame( () => {
		const card = document.getElementById( 'axis-card-' + pid );
		if ( ! card ) {
			return;
		}
		card.scrollIntoView( { block: 'nearest', behavior: 'smooth' } );
		const link = card.querySelector( 'h3 a' );
		if ( link ) {
			link.focus( { preventScroll: true } );
		}
	} );
}

const { state } = store( 'axis-cre/explorer', {
	state: {
		get matched() {
			return state.items.filter( ( item ) =>
				matches( item, state.filters )
			);
		},
		get matchedIds() {
			return state.matched.map( ( item ) => item.id );
		},
		get mapMode() {
			const markets = new Set(
				state.matched.map( ( item ) => item.market )
			);
			return ! state.markets.length ||
				( state.matched.length && markets.size === 1 )
				? 'assets'
				: 'markets';
		},
		get bounds() {
			if ( state.mapMode === 'markets' ) {
				return project( state.markets );
			}
			return project(
				state.matched.length ? state.matched : state.items
			);
		},
		get inView() {
			const b = state.bounds;
			if (
				! state.followMap ||
				state.isListOnly ||
				state.mapMode !== 'assets' ||
				! b
			) {
				return state.matched;
			}
			const [ x, y, w, h ] = state.vb;
			return state.matched.filter( ( item ) => {
				if (
					! Number.isFinite( item.lat ) ||
					! Number.isFinite( item.lng )
				) {
					return true;
				}
				const [ px, py ] = place( b, item.lat, item.lng );
				return px >= x && px <= x + w && py >= y && py <= y + h;
			} );
		},
		get shownIds() {
			return state.inView
				.slice( 0, state.limit )
				.map( ( item ) => item.id );
		},
		get countText() {
			const n = state.inView.length;
			return ( n === 1 ? state.i18n.one : state.i18n.many ).replace(
				'%d',
				String( n )
			);
		},
		get isEmpty() {
			return state.inView.length === 0;
		},
		get hasMore() {
			return state.inView.length > state.limit;
		},
		get isHidden() {
			const { pid } = getContext();
			return ! state.shownIds.includes( pid );
		},
		get isSelected() {
			const { pid } = getContext();
			return state.selected === pid;
		},
		get isZoomed() {
			return state.vb[ 2 ] < state.vb0[ 2 ] - 0.5;
		},
	},
	actions: {
		setFilter( event ) {
			const field = event.target;
			if ( ! field.name || ! ( field.name in state.filters ) ) {
				return;
			}
			state.filters[ field.name ] = field.value;
			resetView();
			syncUrl();
		},
		submit( event ) {
			event.preventDefault();
			const data = new FormData( event.target );
			for ( const key of Object.keys( state.filters ) ) {
				state.filters[ key ] = data.has( key )
					? String( data.get( key ) )
					: '';
			}
			resetView();
			syncUrl();
		},
		toggleFollow( event ) {
			state.followMap = event.target.checked;
			state.limit = state.pageSize;
		},
		showMap() {
			state.isListOnly = false;
		},
		showList() {
			state.isListOnly = true;
		},
		loadMore() {
			state.limit += state.pageSize;
		},
		selectCard() {
			const { pid } = getContext();
			state.selected = pid;
		},
		// Pins are plain SVG links; their clicks reach the map frame.
		mapClick( event ) {
			const link = event.target.closest( '.pin a' );
			if ( ! link ) {
				return;
			}
			event.preventDefault();
			const pin = link.closest( '.pin' );
			if ( pin.dataset.mid ) {
				selectCluster( Number( pin.dataset.mid ), getElement().ref );
			} else {
				selectPin( Number( pin.dataset.pid ) );
			}
		},
		zoomIn() {
			zoomBy( 0.7 );
		},
		zoomOut() {
			zoomBy( 1 / 0.7 );
		},
		resetMap() {
			state.vb = [ ...state.vb0 ];
		},
		dragStart( event ) {
			if ( event.button !== 0 || event.target.closest( 'a' ) ) {
				return;
			}
			const { ref } = getElement();
			drag = {
				id: event.pointerId,
				x: event.clientX,
				y: event.clientY,
				vb: [ ...state.vb ],
				scale: state.vb[ 2 ] / ref.getBoundingClientRect().width,
			};
			ref.setPointerCapture( event.pointerId );
			ref.classList.add( 'is-dragging' );
		},
		dragMove( event ) {
			if ( ! drag || event.pointerId !== drag.id ) {
				return;
			}
			const dx = ( event.clientX - drag.x ) * drag.scale;
			const dy = ( event.clientY - drag.y ) * drag.scale;
			state.vb = clamp( [
				drag.vb[ 0 ] - dx,
				drag.vb[ 1 ] - dy,
				drag.vb[ 2 ],
				drag.vb[ 3 ],
			] );
		},
		dragEnd() {
			if ( ! drag ) {
				return;
			}
			const { ref } = getElement();
			ref.classList.remove( 'is-dragging' );
			drag = null;
		},
		wheel( event ) {
			// Scrolling the page stays the default; zoom only with Ctrl or Cmd held.
			if ( ! event.ctrlKey && ! event.metaKey ) {
				return;
			}
			event.preventDefault();
			const { ref } = getElement();
			const svg = ref.querySelector( 'svg' );
			const rect = svg.getBoundingClientRect();
			const [ x, y, w, h ] = state.vb;
			const cx = x + ( ( event.clientX - rect.left ) / rect.width ) * w;
			const cy = y + ( ( event.clientY - rect.top ) / rect.height ) * h;
			zoomBy( event.deltaY > 0 ? 1.15 : 1 / 1.15, cx, cy );
		},
		mapKey( event ) {
			const link =
				event.target.closest && event.target.closest( '.pin a' );
			if ( link && event.key === ' ' ) {
				// Pins are role=button links: Space activates them too.
				event.preventDefault();
				link.dispatchEvent(
					new window.MouseEvent( 'click', {
						bubbles: true,
						cancelable: true,
					} )
				);
				return;
			}
			if ( event.target !== getElement().ref ) {
				return;
			}
			const step = state.vb[ 2 ] * 0.1;
			const keys = {
				ArrowLeft: () => panBy( -step, 0 ),
				ArrowRight: () => panBy( step, 0 ),
				ArrowUp: () => panBy( 0, -step ),
				ArrowDown: () => panBy( 0, step ),
				'+': () => zoomBy( 0.7 ),
				'=': () => zoomBy( 0.7 ),
				'-': () => zoomBy( 1 / 0.7 ),
				0: () => ( state.vb = [ ...state.vb0 ] ),
			};
			if ( keys[ event.key ] ) {
				event.preventDefault();
				keys[ event.key ]();
			}
		},
	},
	callbacks: {
		init() {
			state.enhanced = true;
		},
		applyViewBox() {
			const ref = getElement().ref.querySelector( 'svg' );
			if ( ! ref ) {
				return;
			}
			const vb = state.vb;
			const b = state.bounds;
			ref.setAttribute( 'viewBox', vb.join( ' ' ) );
			ref.classList.toggle( 'is-zoomed', state.isZoomed );

			// Pin state: which pins show, the count on each market and the selected asset.
			const mode = state.mapMode;
			const matched = new Set( state.matchedIds );
			const selected = state.selected;
			const perMarket = new Map();
			state.matched.forEach( ( item ) =>
				perMarket.set(
					item.market,
					( perMarket.get( item.market ) || 0 ) + 1
				)
			);
			ref.querySelectorAll( '.pin.is-asset' ).forEach( ( pin ) => {
				const pid = Number( pin.dataset.pid );
				const on = selected === pid;
				pin.classList.toggle(
					'is-hidden',
					mode !== 'assets' || ! matched.has( pid )
				);
				pin.classList.toggle( 'is-selected', on );
				pin.firstElementChild.setAttribute(
					'aria-pressed',
					on ? 'true' : 'false'
				);
			} );
			ref.querySelectorAll( '.pin.is-market' ).forEach( ( pin ) => {
				const n = perMarket.get( Number( pin.dataset.mid ) ) || 0;
				pin.classList.toggle( 'is-hidden', mode !== 'markets' || ! n );
				const count = pin.querySelector( '.pin-count' );
				if ( count ) {
					count.textContent = String( n );
				}
			} );

			if ( ! b ) {
				return;
			}
			// Keep pins the same size on screen at any zoom, and refit them to the results.
			const k = vb[ 2 ] / state.vb0[ 2 ];
			const items = new Map(
				state.items.map( ( item ) => [ item.id, item ] )
			);
			const markets = new Map(
				state.markets.map( ( m ) => [ m.id, m ] )
			);
			ref.querySelectorAll( '.pin' ).forEach( ( pin ) => {
				const p = pin.dataset.pid
					? items.get( Number( pin.dataset.pid ) )
					: markets.get( Number( pin.dataset.mid ) );
				if ( ! p || ! Number.isFinite( p.lat ) ) {
					return;
				}
				const [ x, y ] = place( b, p.lat, p.lng );
				pin.setAttribute(
					'transform',
					`translate(${ x.toFixed( 1 ) } ${ y.toFixed( 1 ) }) scale(${ k })`
				);
				const label = pin.querySelector( '.pin-label' );
				if ( label ) {
					const flip = x > vb[ 0 ] + vb[ 2 ] - 170 * k;
					label.setAttribute( 'x', flip ? '-27' : '27' );
					label.setAttribute( 'text-anchor', flip ? 'end' : 'start' );
				}
			} );
			const [ , , W, H ] = state.vb0;
			ref.querySelectorAll( '[data-tick]' ).forEach( ( tick ) => {
				const at = Number( tick.dataset.at );
				if ( tick.dataset.tick === 'x' ) {
					const lng = b.midLng + ( at - W / 2 ) / ( b.k * b.scale );
					tick.textContent =
						Math.abs( lng )
							.toFixed( 3 )
							.replace( /\.?0+$/, '' ) +
						' ' +
						( lng >= 0 ? state.i18n.east : state.i18n.west );
				} else {
					const lat = b.midLat - ( at - H / 2 ) / b.scale;
					tick.textContent =
						Math.abs( lat )
							.toFixed( 3 )
							.replace( /\.?0+$/, '' ) +
						' ' +
						( lat >= 0 ? state.i18n.north : state.i18n.south );
				}
			} );
		},
	},
} );
