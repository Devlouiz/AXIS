<?php
/**
 * Script module dependencies.
 *
 * @package Axis_CRE
 */

return array(
	'dependencies' => array( '@wordpress/interactivity' ),
	'version'      => '0.2.1',
);
