<?php
/**
 * Server render for axis/property-results.
 *
 * @package Axis_CRE
 *
 * @var array     $attributes Block attributes.
 * @var \WP_Block $block      Block instance.
 */

defined( 'ABSPATH' ) || exit;

echo Axis_CRE\Blocks::render( 'property-results', $attributes, $block ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts in Axis_CRE\Blocks.
