<?php
/**
 * Server render for axis/market-snapshot.
 *
 * @package Axis_CRE
 *
 * @var array     $attributes Block attributes.
 * @var \WP_Block $block      Block instance.
 */

defined( 'ABSPATH' ) || exit;

echo Axis_CRE\Blocks::render( 'market-snapshot', $attributes, $block ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts in Axis_CRE\Blocks.
