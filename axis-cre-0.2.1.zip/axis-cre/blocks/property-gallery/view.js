/**
 * Property gallery: one photo at a time, real buttons, arrow keys, announced position.
 * Without JavaScript every photo is shown in sequence.
 */
import { store, getContext } from '@wordpress/interactivity';

const { state } = store( 'axis-cre/gallery', {
	state: {
		get isActive() {
			const ctx = getContext();
			return ctx.i === ctx.index;
		},
		get countText() {
			const ctx = getContext();
			return state.i18nCount
				.replace( '%1$d', String( ctx.index + 1 ) )
				.replace( '%2$d', String( ctx.count ) );
		},
	},
	actions: {
		prev() {
			const ctx = getContext();
			ctx.index = ( ctx.index - 1 + ctx.count ) % ctx.count;
		},
		next() {
			const ctx = getContext();
			ctx.index = ( ctx.index + 1 ) % ctx.count;
		},
		go() {
			const ctx = getContext();
			ctx.index = ctx.i;
		},
		onKey( event ) {
			const ctx = getContext();
			if ( event.key === 'ArrowLeft' ) {
				ctx.index = ( ctx.index - 1 + ctx.count ) % ctx.count;
				event.preventDefault();
			} else if ( event.key === 'ArrowRight' ) {
				ctx.index = ( ctx.index + 1 ) % ctx.count;
				event.preventDefault();
			}
		},
	},
	callbacks: {
		init() {
			state.enhanced = true;
		},
	},
} );
