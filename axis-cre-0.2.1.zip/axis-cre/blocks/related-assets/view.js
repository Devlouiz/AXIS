/**
 * Related assets: ARIA tabs with arrow, Home and End keys.
 * Without JavaScript the three groups are shown one after another under headings.
 */
import { store, getContext, getElement } from '@wordpress/interactivity';

const { state } = store( 'axis-cre/tabs', {
	state: {
		get isSelected() {
			const ctx = getContext();
			return ctx.i === ctx.active;
		},
		get tabIndex() {
			return state.isSelected ? 0 : -1;
		},
	},
	actions: {
		select() {
			const ctx = getContext();
			ctx.active = ctx.i;
		},
		onKey( event ) {
			const ctx = getContext();
			const { ref } = getElement();
			const tabs = Array.from( ref.querySelectorAll( '[role="tab"]' ) );
			const last = tabs.length - 1;
			let next = null;
			if ( event.key === 'ArrowRight' ) {
				next = ctx.active >= last ? 0 : ctx.active + 1;
			} else if ( event.key === 'ArrowLeft' ) {
				next = ctx.active <= 0 ? last : ctx.active - 1;
			} else if ( event.key === 'Home' ) {
				next = 0;
			} else if ( event.key === 'End' ) {
				next = last;
			}
			if ( next === null ) {
				return;
			}
			event.preventDefault();
			ctx.active = next;
			tabs[ next ].focus();
		},
	},
	callbacks: {
		init() {
			state.enhanced = true;
		},
	},
} );
