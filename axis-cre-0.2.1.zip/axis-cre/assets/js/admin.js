/**
 * Details box: media pickers for photos, files and documents.
 *
 * @param {Object} $  jQuery.
 * @param {Object} wp The wp global.
 */
( function ( $, wp ) {
	const { __ } = wp.i18n;

	const escapeHtml = ( s ) => $( '<div>' ).text( s ).html();

	// Photos and single files.
	$( document ).on( 'click', '.axis-cre-media__add', function () {
		const box = $( this ).closest( '.axis-cre-media' );
		const multiple = box.data( 'multiple' ) === 1;
		const mime = String( box.data( 'mime' ) );
		const frame = wp.media( {
			title: multiple
				? __( 'Add images', 'axis-cre' )
				: __( 'Choose file', 'axis-cre' ),
			button: {
				text: multiple
					? __( 'Add to gallery', 'axis-cre' )
					: __( 'Use this file', 'axis-cre' ),
			},
			multiple: multiple ? 'add' : false,
			library: { type: mime },
		} );
		frame.on( 'select', () => {
			const input = box.find( '.axis-cre-media__ids' );
			const list = box.find( '.axis-cre-media__list' );
			const ids = multiple
				? String( input.val() ).split( ',' ).filter( Boolean )
				: [];
			if ( ! multiple ) {
				list.empty();
			}
			frame
				.state()
				.get( 'selection' )
				.each( ( att ) => {
					const a = att.toJSON();
					if ( ids.includes( String( a.id ) ) ) {
						return;
					}
					ids.push( String( a.id ) );
					const thumb =
						a.sizes && a.sizes.thumbnail
							? '<img src="' +
								escapeHtml( a.sizes.thumbnail.url ) +
								'" alt="">'
							: '<span class="dashicons dashicons-media-default" aria-hidden="true"></span>';
					list.append(
						'<li data-id="' +
							a.id +
							'">' +
							thumb +
							'<span class="axis-cre-media__name">' +
							escapeHtml( a.title ) +
							'</span>' +
							'<button type="button" class="button-link axis-cre-media__remove">' +
							escapeHtml( __( 'Remove', 'axis-cre' ) ) +
							'<span class="screen-reader-text"> ' +
							escapeHtml( a.title ) +
							'</span></button></li>'
					);
				} );
			input.val( ids.join( ',' ) );
		} );
		frame.open();
	} );

	$( document ).on( 'click', '.axis-cre-media__remove', function () {
		const item = $( this ).closest( 'li' );
		const box = item.closest( '.axis-cre-media' );
		const input = box.find( '.axis-cre-media__ids' );
		const id = String( item.data( 'id' ) );
		input.val(
			String( input.val() )
				.split( ',' )
				.filter( ( v ) => v && v !== id )
				.join( ',' )
		);
		const add = box.find( '.axis-cre-media__add' );
		item.remove();
		add.trigger( 'focus' );
	} );

	// Documents with a gated flag.
	$( document ).on( 'click', '.axis-cre-docs-field__add', function () {
		const box = $( this ).closest( '.axis-cre-docs-field' );
		const name = box.data( 'name' );
		const frame = wp.media( {
			title: __( 'Add documents', 'axis-cre' ),
			button: { text: __( 'Add to documents', 'axis-cre' ) },
			multiple: 'add',
		} );
		frame.on( 'select', () => {
			const body = box.find( 'tbody' );
			frame
				.state()
				.get( 'selection' )
				.each( ( att ) => {
					const a = att.toJSON();
					const i = Date.now() + '' + a.id;
					const base = name + '[' + i + ']';
					/* translators: %s: document name. */
					const gate = __( 'Gate %s', 'axis-cre' ).replace(
						'%s',
						a.title
					);
					body.append(
						'<tr><td><input type="hidden" name="' +
							escapeHtml( base ) +
							'[id]" value="' +
							a.id +
							'">' +
							escapeHtml( a.title ) +
							'</td>' +
							'<td><label><input type="checkbox" name="' +
							escapeHtml( base ) +
							'[gated]" value="1"><span class="screen-reader-text">' +
							escapeHtml( gate ) +
							'</span></label></td>' +
							'<td><button type="button" class="button-link axis-cre-docs-field__remove">' +
							escapeHtml( __( 'Remove', 'axis-cre' ) ) +
							'<span class="screen-reader-text"> ' +
							escapeHtml( a.title ) +
							'</span></button></td></tr>'
					);
				} );
		} );
		frame.open();
	} );

	$( document ).on( 'click', '.axis-cre-docs-field__remove', function () {
		const row = $( this ).closest( 'tr' );
		const add = row
			.closest( '.axis-cre-docs-field' )
			.find( '.axis-cre-docs-field__add' );
		row.remove();
		add.trigger( 'focus' );
	} );
} )( window.jQuery, window.wp );
