/**
 * AXIS CRE listing cards.
 *
 * - Step through a card's photos with its buttons or by swiping.
 * - Save and compare listings; both lists live in this browser (localStorage).
 * - Keep header counters, shortlist links and the compare tray in step.
 * - Swap the hero search price bands between sale price and rent.
 *
 * Everything is an enhancement: without this file the cards are links and the forms submit.
 */
( function () {
	'use strict';

	const cfg = window.axisCreCards || {};
	const MAX = cfg.max || 4;
	const KEYS = { save: 'axisCre.saved', compare: 'axisCre.compare' };
	let lists = { save: read( KEYS.save ), compare: read( KEYS.compare ) };
	let live;
	let tray;

	function t( key, fallback ) {
		return cfg[ key ] || fallback;
	}

	function fmt( str ) {
		const args = Array.prototype.slice.call( arguments, 1 );
		let i = 0;
		return String( str ).replace(
			/%(?:(\d)\$)?([sd])/g,
			function ( m, pos ) {
				const v = pos ? args[ pos - 1 ] : args[ i++ ];
				return v === undefined ? '' : v;
			}
		);
	}

	function read( key ) {
		try {
			const v = JSON.parse( window.localStorage.getItem( key ) || '[]' );
			return Array.isArray( v )
				? v.filter( function ( x ) {
						return x && x.id;
					} )
				: [];
		} catch {
			return [];
		}
	}

	function write( kind ) {
		try {
			window.localStorage.setItem(
				KEYS[ kind ],
				JSON.stringify( lists[ kind ] )
			);
		} catch {
			// Storage can be full or blocked; the lists still work for this page view.
		}
	}

	function has( kind, id ) {
		return lists[ kind ].some( function ( x ) {
			return String( x.id ) === String( id );
		} );
	}

	function ids( kind ) {
		return lists[ kind ]
			.map( function ( x ) {
				return x.id;
			} )
			.join( ',' );
	}

	function say( msg ) {
		if ( ! live ) {
			live = document.createElement( 'p' );
			live.className = 'axis-cre-live';
			live.setAttribute( 'role', 'status' );
			live.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( live );
		}
		live.textContent = '';
		window.setTimeout( function () {
			live.textContent = msg;
		}, 60 );
	}

	function shortlistUrl( view ) {
		if ( ! cfg.shortlist ) {
			return '';
		}
		const url = new URL( cfg.shortlist, window.location.href );
		url.searchParams.set( 'view', view );
		if ( lists.save.length ) {
			url.searchParams.set( 'saved', ids( 'save' ) );
		}
		if ( lists.compare.length ) {
			url.searchParams.set( 'compare', ids( 'compare' ) );
		}
		return url.toString();
	}

	function esc( s ) {
		return String( s ).replace( /[&<>"']/g, function ( c ) {
			return {
				'&': '&amp;',
				'<': '&lt;',
				'>': '&gt;',
				'"': '&quot;',
				"'": '&#39;',
			}[ c ];
		} );
	}

	/* ---------- Photos ---------- */

	function showPhoto( media, step ) {
		const photos = media.querySelectorAll( '.axis-cre-card__photo' );
		const n = photos.length;
		if ( n < 2 ) {
			return;
		}
		let cur = 0;
		photos.forEach( function ( p, i ) {
			if ( p.classList.contains( 'is-active' ) ) {
				cur = i;
			}
		} );
		const next = ( cur + step + n ) % n;
		photos[ cur ].classList.remove( 'is-active' );
		photos[ cur ].hidden = true;
		photos[ next ].hidden = false;
		photos[ next ].classList.add( 'is-active' );
		media
			.querySelectorAll( '.axis-cre-card__dots span' )
			.forEach( function ( d, i ) {
				d.classList.toggle( 'is-on', i === next );
			} );
		const idx = media.querySelector( '.axis-cre-card__index' );
		if ( idx ) {
			idx.textContent = String( next + 1 );
		}
		// Preload the one after, so the next step is instant.
		const after = photos[ ( next + 1 ) % n ].querySelector(
			'img[loading="lazy"]'
		);
		if ( after ) {
			after.loading = 'eager';
		}
	}

	function swipe( media ) {
		let x0 = null;
		let y0 = null;
		media.addEventListener(
			'touchstart',
			function ( e ) {
				x0 = e.touches[ 0 ].clientX;
				y0 = e.touches[ 0 ].clientY;
			},
			{ passive: true }
		);
		media.addEventListener(
			'touchend',
			function ( e ) {
				if ( x0 === null ) {
					return;
				}
				const dx = e.changedTouches[ 0 ].clientX - x0;
				const dy = e.changedTouches[ 0 ].clientY - y0;
				x0 = null;
				if (
					Math.abs( dx ) > 40 &&
					Math.abs( dx ) > Math.abs( dy ) * 1.5
				) {
					showPhoto( media, dx < 0 ? 1 : -1 );
				}
			},
			{ passive: true }
		);
	}

	/* ---------- Save and compare ---------- */

	function listing( card ) {
		try {
			return JSON.parse( card.getAttribute( 'data-axis-listing' ) );
		} catch {
			return null;
		}
	}

	function toggle( kind, item ) {
		const on = has( kind, item.id );
		if ( on ) {
			lists[ kind ] = lists[ kind ].filter( function ( x ) {
				return String( x.id ) !== String( item.id );
			} );
		} else {
			if ( kind === 'compare' && lists.compare.length >= MAX ) {
				say(
					fmt(
						t(
							'limit',
							'You can compare up to %d listings. Remove one first.'
						),
						MAX
					)
				);
				if ( tray ) {
					tray.classList.remove( 'is-shake' );
					void tray.offsetWidth; // Restart the animation.
					tray.classList.add( 'is-shake' );
				}
				return;
			}
			lists[ kind ].push( {
				id: item.id,
				title: item.title,
				url: item.url,
				price: item.price,
				photo: item.photo,
			} );
		}
		write( kind );
		const messages = {
			save: on
				? t( 'unsaved', '%s removed from your shortlist.' )
				: t( 'saved', '%s saved to your shortlist.' ),
			compare: on
				? t( 'removed', '%s removed from compare.' )
				: t( 'added', '%s added to compare.' ),
		};
		say( fmt( messages[ kind ], item.title ) );
		sync();
		document.dispatchEvent(
			new CustomEvent( 'axis-cre:lists', {
				detail: { kind, id: item.id, on: ! on },
			} )
		);
	}

	function sync() {
		document
			.querySelectorAll( '[data-axis-listing]' )
			.forEach( function ( card ) {
				const item = listing( card );
				if ( ! item ) {
					return;
				}
				card.querySelectorAll( '[data-axis-action]' ).forEach(
					function ( b ) {
						const on = has(
							b.getAttribute( 'data-axis-action' ),
							item.id
						);
						b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
					}
				);
			} );
		document
			.querySelectorAll( '[data-axis-count]' )
			.forEach( function ( el ) {
				const kind =
					el.getAttribute( 'data-axis-count' ) === 'compare'
						? 'compare'
						: 'save';
				const n = lists[ kind ].length;
				el.textContent = String( n );
				el.hidden = n === 0;
			} );
		document
			.querySelectorAll( '[data-axis-shortlist]' )
			.forEach( function ( a ) {
				const url = shortlistUrl(
					a.getAttribute( 'data-axis-shortlist' )
				);
				if ( url ) {
					a.href = url;
				}
			} );
		renderTray();
	}

	/* ---------- Compare tray ---------- */

	function renderTray() {
		const n = lists.compare.length;
		const onShortlist = document.querySelector(
			'[data-axis-shortlist-view="compare"]'
		);
		if ( ! n || onShortlist ) {
			if ( tray ) {
				tray.hidden = true;
			}
			return;
		}
		if ( ! tray ) {
			tray = document.createElement( 'aside' );
			tray.className = 'axis-cre-tray';
			tray.setAttribute( 'aria-label', t( 'tray', 'Compare listings' ) );
			document.body.appendChild( tray );
			tray.addEventListener( 'click', function ( e ) {
				if ( e.target.closest( '.axis-cre-tray__clear' ) ) {
					lists.compare = [];
					write( 'compare' );
					say( t( 'cleared', 'Compare list cleared.' ) );
					sync();
				}
			} );
		}
		const thumbs = lists.compare
			.map( function ( x ) {
				return x.photo
					? '<img src="' +
							esc( x.photo ) +
							'" alt="" width="44" height="44">'
					: '<span aria-hidden="true">' +
							esc( ( x.title || '?' ).charAt( 0 ) ) +
							'</span>';
			} )
			.join( '' );
		const url = shortlistUrl( 'compare' );
		const label = fmt(
			n === 1
				? t( 'trayOne', '%d listing to compare' )
				: t( 'trayMany', '%d listings to compare' ),
			n
		);
		tray.innerHTML =
			'<div class="axis-cre-tray__thumbs">' +
			thumbs +
			'</div>' +
			'<p class="axis-cre-tray__text">' +
			esc( label ) +
			'<span>' +
			esc( t( 'trayHint', 'Add up to four to see them side by side.' ) ) +
			'</span></p>' +
			'<button type="button" class="axis-cre-tray__clear">' +
			esc( t( 'clear', 'Clear' ) ) +
			'</button>' +
			( url && n > 1
				? '<a class="axis-cre-button axis-cre-tray__go" href="' +
					esc( url ) +
					'">' +
					esc( t( 'compare', 'Compare' ) ) +
					'</a>'
				: '' );
		tray.hidden = false;
	}

	/* ---------- Hero search ---------- */

	function heroSearch( form ) {
		let bands;
		try {
			bands = JSON.parse( form.getAttribute( 'data-axis-bands' ) );
		} catch {
			return;
		}
		const label = form.querySelector( '[data-axis-price-label]' );
		const select =
			label && document.getElementById( label.getAttribute( 'for' ) );
		if ( ! select ) {
			return;
		}
		function apply() {
			const checked = form.querySelector(
				'input[name="listing"]:checked'
			);
			const kind =
				checked && checked.value === 'for-lease' ? 'rent' : 'price';
			const keep = select.value;
			label.textContent =
				kind === 'rent' ? t( 'rent', 'Rent' ) : t( 'price', 'Price' );
			select.innerHTML =
				'<option value="">' +
				esc( t( 'any', 'Any' ) ) +
				'</option>' +
				Object.keys( bands[ kind ] || {} )
					.map( function ( k ) {
						return (
							'<option value="' +
							esc( k ) +
							'"' +
							( k === keep ? ' selected' : '' ) +
							'>' +
							esc( bands[ kind ][ k ] ) +
							'</option>'
						);
					} )
					.join( '' );
		}
		form.addEventListener( 'change', function ( e ) {
			if ( e.target.name === 'listing' ) {
				apply();
			}
		} );
	}

	/* ---------- Shortlist page ---------- */

	function shortlistPage( root ) {
		const view = root.getAttribute( 'data-axis-shortlist-view' );
		const params = new URLSearchParams( window.location.search );
		// Arrived without the lists in the address: rebuild it from this browser's lists.
		if (
			! params.has( 'saved' ) &&
			! params.has( 'compare' ) &&
			( lists.save.length || lists.compare.length )
		) {
			const url = shortlistUrl( view || 'saved' );
			if ( url ) {
				window.location.replace( url );
			}
			return;
		}
		// Removing a listing here takes it off the page and out of the address.
		document.addEventListener( 'axis-cre:lists', function ( e ) {
			const d = e.detail;
			if ( d.on || ( view === 'compare' ) !== ( d.kind === 'compare' ) ) {
				return;
			}
			root.querySelectorAll( '[data-axis-item="' + d.id + '"]' ).forEach(
				function ( el ) {
					el.hidden = true;
				}
			);
			const url = shortlistUrl( view );
			if ( url ) {
				window.history.replaceState( null, '', url );
			}
			const left = lists[ d.kind ].length;
			const empty = root.querySelector( '.axis-cre-shortlist__empty' );
			if ( ! left && empty ) {
				empty.hidden = false;
			}
		} );
	}

	/* ---------- Wiring ---------- */

	function init() {
		document.addEventListener( 'click', function ( e ) {
			const photoBtn = e.target.closest( '[data-axis-photo]' );
			if ( photoBtn ) {
				e.preventDefault();
				showPhoto(
					photoBtn.closest( '.axis-cre-card__media' ),
					parseInt( photoBtn.getAttribute( 'data-axis-photo' ), 10 )
				);
				return;
			}
			const act = e.target.closest( '[data-axis-action]' );
			if ( act ) {
				e.preventDefault();
				const card = act.closest( '[data-axis-listing]' );
				const item = card && listing( card );
				if ( item ) {
					toggle( act.getAttribute( 'data-axis-action' ), item );
				}
			}
		} );

		document
			.querySelectorAll( '.axis-cre-card__media[data-count]' )
			.forEach( function ( media ) {
				if ( parseInt( media.getAttribute( 'data-count' ), 10 ) > 1 ) {
					swipe( media );
				}
			} );

		document
			.querySelectorAll( 'form[data-axis-bands]' )
			.forEach( heroSearch );
		document
			.querySelectorAll( '[data-axis-shortlist-view]' )
			.forEach( shortlistPage );
		document.documentElement.classList.add( 'axis-cre-js' );

		window.addEventListener( 'storage', function ( e ) {
			if ( e.key === KEYS.save || e.key === KEYS.compare ) {
				lists = {
					save: read( KEYS.save ),
					compare: read( KEYS.compare ),
				};
				sync();
			}
		} );
		sync();
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
