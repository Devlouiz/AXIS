/**
 * Editor UI for the AXIS CRE blocks: a server-rendered preview plus settings.
 * Block metadata comes from each block.json; this file adds only the edit view.
 *
 * @param {Object} wp The wp global.
 */
( function ( wp ) {
	const { registerBlockType } = wp.blocks;
	const { createElement: el, Fragment } = wp.element;
	const { InspectorControls, useBlockProps } = wp.blockEditor;
	const {
		PanelBody,
		SelectControl,
		RangeControl,
		ToggleControl,
		TextControl,
		Placeholder,
	} = wp.components;
	const ServerSideRender = wp.serverSideRender;
	const { __ } = wp.i18n;

	const layout = {
		key: 'layout',
		type: 'select',
		label: __( 'Layout', 'axis-cre' ),
		options: [
			[ 'grid', __( 'Grid of cards', 'axis-cre' ) ],
			[ 'list', __( 'List of wide cards', 'axis-cre' ) ],
			[ 'compact', __( 'Compact cards', 'axis-cre' ) ],
			[ 'table', __( 'Comparable rows', 'axis-cre' ) ],
		],
	};
	const perPage = ( max ) => ( {
		key: 'perPage',
		type: 'range',
		label: __( 'Items to show', 'axis-cre' ),
		min: 1,
		max,
	} );
	const scope = ( extra ) => ( {
		key: 'scope',
		type: 'select',
		label: __( 'Which items', 'axis-cre' ),
		options: [ [ 'all', __( 'All', 'axis-cre' ) ], extra ],
	} );
	const mode = ( options ) => ( {
		key: 'mode',
		type: 'select',
		label: __( 'Show', 'axis-cre' ),
		options,
	} );

	const controls = {
		'axis/property-search': [
			{
				key: 'layout',
				type: 'select',
				label: __( 'Layout', 'axis-cre' ),
				options: [
					[ 'row', __( 'Row across the page', 'axis-cre' ) ],
					[ 'sidebar', __( 'Stacked, for a sidebar', 'axis-cre' ) ],
					[
						'hero',
						__(
							'Hero: sale and lease tabs, location, size and price',
							'axis-cre'
						),
					],
				],
			},
		],
		'axis/property-results': [
			layout,
			perPage( 24 ),
			{
				key: 'featured',
				type: 'toggle',
				label: __( 'Featured assets first', 'axis-cre' ),
			},
			scope( [
				'current-market',
				__( 'In the current market', 'axis-cre' ),
			] ),
		],
		'axis/related-assets': [ perPage( 6 ) ],
		'axis/related-listings': [
			{
				panel: __( 'Match on', 'axis-cre' ),
				help: __(
					'Rules are read from the page this block is on: the property, market, expert, transaction or report. On a market page the market always applies; on an expert page, their listings always apply.',
					'axis-cre'
				),
				fields: [
					{
						key: 'matchMarket',
						type: 'toggle',
						label: __( 'Same market', 'axis-cre' ),
					},
					{
						key: 'matchType',
						type: 'toggle',
						label: __( 'Same property type', 'axis-cre' ),
					},
					{
						key: 'matchListing',
						type: 'toggle',
						label: __(
							'Same listing type (for sale, for lease)',
							'axis-cre'
						),
					},
					{
						key: 'matchBroker',
						type: 'toggle',
						label: __( 'Same broker or team', 'axis-cre' ),
					},
					{
						key: 'priceRange',
						type: 'range',
						label: __( 'Price or rent within, %', 'axis-cre' ),
						min: 0,
						max: 100,
						step: 5,
						help: __( '0 turns this rule off.', 'axis-cre' ),
					},
					{
						key: 'sizeRange',
						type: 'range',
						label: __( 'Building size within, %', 'axis-cre' ),
						min: 0,
						max: 100,
						step: 5,
						help: __( '0 turns this rule off.', 'axis-cre' ),
					},
					{
						key: 'radius',
						type: 'number',
						label: __( 'Within distance', 'axis-cre' ),
						min: 0,
						help: __(
							'0 turns this rule off. Needs coordinates on the listings.',
							'axis-cre'
						),
					},
					{
						key: 'unit',
						type: 'select',
						label: __( 'Distance unit', 'axis-cre' ),
						options: [
							[ 'mi', __( 'Miles', 'axis-cre' ) ],
							[ 'km', __( 'Kilometres', 'axis-cre' ) ],
						],
					},
					{
						key: 'fallback',
						type: 'toggle',
						label: __( 'Fill with looser matches', 'axis-cre' ),
						help: __(
							'When too few listings meet every rule, rules are relaxed in this order: listing type, broker, price, size, distance, property type, market.',
							'axis-cre'
						),
					},
				],
			},
			{
				panel: __( 'Display', 'axis-cre' ),
				fields: [
					{
						key: 'showHeading',
						type: 'toggle',
						label: __( 'Show heading', 'axis-cre' ),
					},
					{
						key: 'heading',
						type: 'text',
						label: __( 'Heading', 'axis-cre' ),
						help: __(
							'Leave empty for a heading that fits the page, such as Similar listings or Listings in Chicago.',
							'axis-cre'
						),
						show: ( a ) => a.showHeading,
					},
					{
						key: 'orderBy',
						type: 'select',
						label: __( 'Order', 'axis-cre' ),
						options: [
							[ 'match', __( 'Best match first', 'axis-cre' ) ],
							[ 'nearest', __( 'Nearest first', 'axis-cre' ) ],
							[ 'newest', __( 'Newest first', 'axis-cre' ) ],
						],
					},
					{
						key: 'layout',
						type: 'select',
						label: __( 'Layout', 'axis-cre' ),
						options: [
							[ 'grid', __( 'Grid of cards', 'axis-cre' ) ],
							[ 'carousel', __( 'Carousel', 'axis-cre' ) ],
							[ 'list', __( 'List of wide cards', 'axis-cre' ) ],
							[ 'compact', __( 'Compact cards', 'axis-cre' ) ],
						],
					},
					{
						key: 'columns',
						type: 'range',
						label: __( 'Cards across', 'axis-cre' ),
						min: 2,
						max: 4,
						show: ( a ) =>
							a.layout === 'grid' || a.layout === 'carousel',
					},
					perPage( 12 ),
					{
						key: 'showDistance',
						type: 'toggle',
						label: __( 'Show distance', 'axis-cre' ),
						help: __(
							'Shown when a distance rule is set or the order is nearest first.',
							'axis-cre'
						),
					},
					{
						key: 'showReason',
						type: 'toggle',
						label: __( 'Say why each listing matched', 'axis-cre' ),
					},
				],
			},
		],
		'axis/market-snapshot': [
			mode( [
				[ 'full', __( 'Figures and charts', 'axis-cre' ) ],
				[ 'compact', __( 'Three figures', 'axis-cre' ) ],
				[ 'table', __( 'All markets compared', 'axis-cre' ) ],
			] ),
		],
		'axis/market-map': [
			mode( [
				[ 'market', __( 'This market', 'axis-cre' ) ],
				[
					'property',
					__( 'This property and its neighbours', 'axis-cre' ),
				],
				[ 'all', __( 'All markets', 'axis-cre' ) ],
			] ),
		],
		'axis/market-explorer': [ perPage( 48 ) ],
		'axis/transaction-data': [
			mode( [
				[ 'single', __( 'Story of this transaction', 'axis-cre' ) ],
				[ 'list', __( 'Transaction cards', 'axis-cre' ) ],
				[
					'archive',
					__( 'Archive with totals and filters', 'axis-cre' ),
				],
			] ),
			perPage( 24 ),
			scope( [ 'expert', __( 'By the current expert', 'axis-cre' ) ] ),
		],
		'axis/expert-profile': [
			mode( [
				[ 'profile', __( 'Profile of this expert', 'axis-cre' ) ],
				[ 'cards', __( 'Expert cards', 'axis-cre' ) ],
				[ 'contact', __( 'Listing broker', 'axis-cre' ) ],
				[ 'directory', __( 'Directory with filters', 'axis-cre' ) ],
			] ),
			perPage( 48 ),
		],
		'axis/research-index': [
			mode( [
				[
					'single',
					__( 'Figures and downloads of this report', 'axis-cre' ),
				],
				[ 'list', __( 'Research cards', 'axis-cre' ) ],
				[
					'archive',
					__( 'Archive with tabs and filters', 'axis-cre' ),
				],
			] ),
			perPage( 24 ),
			scope( [ 'expert', __( 'By the current expert', 'axis-cre' ) ] ),
		],
	};

	const names = [
		'property-search',
		'property-results',
		'property-metrics',
		'property-specifications',
		'property-gallery',
		'property-documents',
		'related-assets',
		'related-listings',
		'shortlist',
		'listing-tools',
		'market-snapshot',
		'market-map',
		'market-explorer',
		'transaction-data',
		'expert-profile',
		'research-index',
	];

	const field = ( c, attributes, setAttributes ) => {
		const set = ( value ) => setAttributes( { [ c.key ]: value } );
		if ( c.type === 'select' ) {
			return el( SelectControl, {
				key: c.key,
				label: c.label,
				value: attributes[ c.key ],
				options: c.options.map( ( o ) => ( {
					value: o[ 0 ],
					label: o[ 1 ],
				} ) ),
				onChange: set,
				__nextHasNoMarginBottom: true,
				__next40pxDefaultSize: true,
			} );
		}
		if ( c.type === 'text' ) {
			return el( TextControl, {
				key: c.key,
				label: c.label,
				help: c.help,
				value: attributes[ c.key ] || '',
				onChange: set,
				__nextHasNoMarginBottom: true,
				__next40pxDefaultSize: true,
			} );
		}
		if ( c.type === 'number' ) {
			return el( TextControl, {
				key: c.key,
				label: c.label,
				help: c.help,
				type: 'number',
				min: c.min,
				step: 'any',
				value:
					attributes[ c.key ] === undefined
						? ''
						: String( attributes[ c.key ] ),
				onChange: ( v ) =>
					setAttributes( {
						[ c.key ]: Math.max( c.min || 0, parseFloat( v ) || 0 ),
					} ),
				__nextHasNoMarginBottom: true,
				__next40pxDefaultSize: true,
			} );
		}
		if ( c.type === 'range' ) {
			return el( RangeControl, {
				key: c.key,
				label: c.label,
				help: c.help,
				value: attributes[ c.key ],
				min: c.min,
				max: c.max,
				step: c.step || 1,
				onChange: set,
				__nextHasNoMarginBottom: true,
				__next40pxDefaultSize: true,
			} );
		}
		return el( ToggleControl, {
			key: c.key,
			label: c.label,
			help: c.help,
			checked: !! attributes[ c.key ],
			onChange: set,
			__nextHasNoMarginBottom: true,
		} );
	};

	names.forEach( ( slug ) => {
		const name = 'axis/' + slug;
		registerBlockType( name, {
			edit: function Edit( props ) {
				const { attributes, setAttributes, context } = props;
				const blockProps = useBlockProps();
				const block = wp.blocks.getBlockType( name );
				const fields = controls[ name ] || [];
				const empty = () =>
					el( Placeholder, {
						icon: block.icon && block.icon.src,
						label: block.title,
						instructions: __(
							'Nothing to show here yet. This block shows content from the page it is on; preview it on a published property, market, expert or report, or add sample content under Tools.',
							'axis-cre'
						),
					} );
				return el(
					Fragment,
					null,
					fields.length
						? el(
								InspectorControls,
								null,
								( fields[ 0 ].panel
									? fields
									: [
											{
												panel: __(
													'Settings',
													'axis-cre'
												),
												fields,
											},
										]
								).map( ( p, i ) =>
									el(
										PanelBody,
										{
											key: i,
											title: p.panel,
											initialOpen: i === 0,
										},
										p.help
											? el(
													'p',
													{
														className:
															'components-base-control__help',
														style: { marginTop: 0 },
													},
													p.help
												)
											: null,
										p.fields
											.filter(
												( c ) =>
													! c.show ||
													c.show( attributes )
											)
											.map( ( c ) =>
												field(
													c,
													attributes,
													setAttributes
												)
											)
									)
								)
							)
						: null,
					el(
						'div',
						blockProps,
						el( ServerSideRender, {
							block: name,
							attributes,
							urlQueryArgs:
								context && context.postId
									? { post_id: context.postId }
									: {},
							EmptyResponsePlaceholder: empty,
						} )
					)
				);
			},
			save: () => null,
		} );
	} );
} )( window.wp );
