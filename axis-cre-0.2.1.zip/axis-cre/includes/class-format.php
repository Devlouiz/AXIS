<?php
/**
 * Number, money, area, date and coordinate formatting.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Formatting helpers. All return plain text; escape on output.
 */
class Format {

	/**
	 * Plugin settings with defaults.
	 *
	 * @return array{currency: string, area: string, shortlist: int}
	 */
	public static function settings() {
		$s = get_option( 'axis_cre_settings', array() );
		return array(
			'currency'  => isset( $s['currency'] ) && '' !== $s['currency'] ? (string) $s['currency'] : '$',
			'area'      => isset( $s['area'] ) && 'sqm' === $s['area'] ? 'sqm' : 'sf',
			'shortlist' => isset( $s['shortlist'] ) ? absint( $s['shortlist'] ) : 0,
		);
	}

	/**
	 * Short area unit label.
	 *
	 * @return string
	 */
	public static function area_unit() {
		return 'sqm' === self::settings()['area'] ? _x( 'sq m', 'square metres, short', 'axis-cre' ) : _x( 'sf', 'square feet, short', 'axis-cre' );
	}

	/**
	 * Identifier such as "Asset 0047".
	 *
	 * @param string $type   Post type.
	 * @param int    $number Sequence number.
	 * @return string
	 */
	public static function id( $type, $number ) {
		$number = absint( $number );
		if ( ! $number ) {
			return '';
		}
		switch ( $type ) {
			case Post_Types::PROPERTY:
				/* translators: %s: zero-padded asset number, for example 0047. */
				return sprintf( __( 'Asset %s', 'axis-cre' ), str_pad( (string) $number, 4, '0', STR_PAD_LEFT ) );
			case Post_Types::MARKET:
				/* translators: %s: zero-padded market number, for example 01. */
				return sprintf( __( 'Market %s', 'axis-cre' ), str_pad( (string) $number, 2, '0', STR_PAD_LEFT ) );
			case Post_Types::TRANSACTION:
				/* translators: %s: zero-padded transaction number, for example 018. */
				return sprintf( __( 'Transaction %s', 'axis-cre' ), str_pad( (string) $number, 3, '0', STR_PAD_LEFT ) );
			case Post_Types::EXPERT:
				/* translators: %s: zero-padded expert number, for example 017. */
				return sprintf( __( 'Expert %s', 'axis-cre' ), str_pad( (string) $number, 3, '0', STR_PAD_LEFT ) );
			case Post_Types::RESEARCH:
				/* translators: %s: zero-padded research number, for example 026. */
				return sprintf( __( 'Research %s', 'axis-cre' ), str_pad( (string) $number, 3, '0', STR_PAD_LEFT ) );
		}
		return '';
	}

	/**
	 * Compact money: $84.5M, $3.8B, $410K, $78.40.
	 *
	 * @param mixed $value    Amount.
	 * @param bool  $decimals Show cents for small values.
	 * @return string
	 */
	public static function money( $value, $decimals = false ) {
		if ( '' === $value || null === $value || ! is_numeric( $value ) ) {
			return '';
		}
		$value = (float) $value;
		$c     = self::settings()['currency'];
		$abs   = abs( $value );
		if ( $abs >= 1e9 ) {
			return $c . self::trim( $value / 1e9, 1 ) . _x( 'B', 'billions, short', 'axis-cre' );
		}
		if ( $abs >= 1e6 ) {
			return $c . self::trim( $value / 1e6, 1 ) . _x( 'M', 'millions, short', 'axis-cre' );
		}
		if ( $abs >= 1e4 ) {
			return $c . self::trim( $value / 1e3, 0 ) . _x( 'K', 'thousands, short', 'axis-cre' );
		}
		return $c . number_format_i18n( $value, $decimals ? 2 : 0 );
	}

	/**
	 * Rent per area unit: $78.40 / sf.
	 *
	 * @param mixed  $value Rent.
	 * @param string $unit  Unit label; defaults to the site's area unit.
	 * @return string
	 */
	public static function rent( $value, $unit = '' ) {
		if ( '' === $value || ! is_numeric( $value ) ) {
			return '';
		}
		$unit = $unit ? $unit : self::area_unit();
		return self::settings()['currency'] . number_format_i18n( (float) $value, 2 ) . ' / ' . $unit;
	}

	/**
	 * Area: 420,000 sf.
	 *
	 * @param mixed $value Area.
	 * @return string
	 */
	public static function area( $value ) {
		if ( '' === $value || ! is_numeric( $value ) ) {
			return '';
		}
		return number_format_i18n( (float) $value ) . ' ' . self::area_unit();
	}

	/**
	 * Compact area for tight spaces: 2.1M sf, 420K sf, 18.5K sf.
	 *
	 * @param mixed $value Area.
	 * @return string
	 */
	public static function area_short( $value ) {
		if ( '' === $value || ! is_numeric( $value ) ) {
			return '';
		}
		$value = (float) $value;
		if ( $value >= 1e6 ) {
			return self::trim( $value / 1e6, 1 ) . _x( 'M', 'millions, short', 'axis-cre' ) . ' ' . self::area_unit();
		}
		if ( $value >= 1e4 ) {
			return self::trim( $value / 1e3, $value >= 1e5 ? 0 : 1 ) . _x( 'K', 'thousands, short', 'axis-cre' ) . ' ' . self::area_unit();
		}
		return self::area( $value );
	}

	/**
	 * Percent: 92%, 6.2%.
	 *
	 * @param mixed $value Percent value.
	 * @return string
	 */
	public static function percent( $value ) {
		if ( '' === $value || ! is_numeric( $value ) ) {
			return '';
		}
		return self::trim( (float) $value, 1 ) . '%';
	}

	/**
	 * Change in percentage points, written out: "Up 0.8 pts".
	 *
	 * @param mixed $value Signed change.
	 * @return string
	 */
	public static function change( $value ) {
		if ( '' === $value || ! is_numeric( $value ) ) {
			return '';
		}
		$value = (float) $value;
		if ( abs( $value ) < 0.05 ) {
			return __( 'Flat', 'axis-cre' );
		}
		/* translators: %s: change in percentage points, for example 0.8. */
		$label = $value > 0 ? __( 'Up %s pts', 'axis-cre' ) : __( 'Down %s pts', 'axis-cre' );
		return sprintf( $label, self::trim( abs( $value ), 1 ) );
	}

	/**
	 * Coordinates: 40.7543 N, 73.9787 W.
	 *
	 * @param mixed $lat Latitude.
	 * @param mixed $lng Longitude.
	 * @return string
	 */
	public static function coordinates( $lat, $lng ) {
		if ( ! is_numeric( $lat ) || ! is_numeric( $lng ) ) {
			return '';
		}
		$lat = (float) $lat;
		$lng = (float) $lng;
		return sprintf(
			'%s %s, %s %s',
			number_format_i18n( abs( $lat ), 4 ),
			$lat >= 0 ? _x( 'N', 'north', 'axis-cre' ) : _x( 'S', 'south', 'axis-cre' ),
			number_format_i18n( abs( $lng ), 4 ),
			$lng >= 0 ? _x( 'E', 'east', 'axis-cre' ) : _x( 'W', 'west', 'axis-cre' )
		);
	}

	/**
	 * Short date: 12 Sep 2026.
	 *
	 * @param string $ymd Date as Y-m-d, or empty.
	 * @return string
	 */
	public static function date( $ymd ) {
		if ( ! $ymd ) {
			return '';
		}
		$ts = strtotime( $ymd );
		return $ts ? date_i18n( _x( 'j M Y', 'short date format', 'axis-cre' ), $ts ) : '';
	}

	/**
	 * Number with up to $places decimals, trailing zeros removed.
	 *
	 * @param float $value  Value.
	 * @param int   $places Decimal places.
	 * @return string
	 */
	public static function trim( $value, $places ) {
		$out = number_format_i18n( $value, $places );
		if ( $places > 0 ) {
			global $wp_locale;
			$point = isset( $wp_locale->number_format['decimal_point'] ) ? $wp_locale->number_format['decimal_point'] : '.';
			$out   = rtrim( rtrim( $out, '0' ), $point );
		}
		return $out;
	}
}
