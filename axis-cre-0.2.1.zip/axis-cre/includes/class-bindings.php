<?php
/**
 * Block Bindings source `axis/field`, used by the AXIS theme's templates.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Formatted field values for bound core blocks.
 */
class Bindings {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_filter( 'render_block', array( __CLASS__, 'render_block' ), 10, 3 );
	}

	/**
	 * Register the source.
	 */
	public static function register() {
		if ( ! function_exists( 'register_block_bindings_source' ) ) {
			return;
		}
		register_block_bindings_source(
			'axis/field',
			array(
				'label'              => __( 'AXIS field', 'axis-cre' ),
				'get_value_callback' => array( __CLASS__, 'get_value' ),
				'uses_context'       => array( 'postId', 'postType' ),
			)
		);
	}

	/**
	 * Binding callback.
	 *
	 * @param array<string, mixed> $args  Source args; `key` names the field.
	 * @param \WP_Block            $block Block instance.
	 * @return string Escaped text.
	 */
	public static function get_value( $args, $block ) {
		$post_id = isset( $block->context['postId'] ) ? (int) $block->context['postId'] : (int) get_the_ID();
		$key     = isset( $args['key'] ) ? sanitize_key( $args['key'] ) : '';
		return esc_html( self::value( $post_id, $key ) );
	}

	/**
	 * Plain-text value of a field for a post, formatted for display.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $key     Field key from the contract.
	 * @return string
	 */
	public static function value( $post_id, $key ) {
		if ( ! $post_id ) {
			return '';
		}
		$type = get_post_type( $post_id );

		switch ( $key ) {
			case 'asset_id':
			case 'market_id':
			case 'transaction_id':
			case 'expert_id':
			case 'research_id':
				return Format::id( $type, Fields::get( $post_id, 'number' ) );

			case 'coordinates':
				return Format::coordinates( Fields::get( $post_id, 'lat' ), Fields::get( $post_id, 'lng' ) );

			case 'status':
				$t = Repository::term( $post_id, 'axis_listing_type' );
				return $t ? $t->name : '';

			case 'asset_class_line':
				$p = Repository::property( $post_id );
				return $p ? $p['class_line'] : '';

			case 'asset_class':
				$t = Repository::term( $post_id, 'axis_property_type' );
				return $t ? $t->slug : '';

			case 'listed':
				$listed  = Format::date( Fields::get( $post_id, 'listed' ) );
				$updated = get_the_modified_date( _x( 'j M Y', 'short date format', 'axis-cre' ), $post_id );
				if ( $listed ) {
					/* translators: 1: date listed, 2: date updated. */
					return sprintf( __( 'Listed %1$s. Updated %2$s', 'axis-cre' ), $listed, $updated );
				}
				/* translators: %s: date updated. */
				return sprintf( __( 'Updated %s', 'axis-cre' ), $updated );

			case 'price_line':
				$p = Repository::property( $post_id );
				if ( ! $p ) {
					return '';
				}
				if ( $p['price'] ) {
					/* translators: %s: asking price, for example $84.5M. */
					return sprintf( __( '%s asking', 'axis-cre' ), Format::money( $p['price'] ) );
				}
				if ( $p['lease'] ) {
					/* translators: %s: lease rate, for example $78.40 / sf. */
					return sprintf( __( '%s per year', 'axis-cre' ), Format::rent( $p['lease'] ) );
				}
				return '';

			case 'market_name':
				$m = Repository::market_for( $post_id );
				return $m ? $m['title'] : '';

			case 'market_summary':
				return self::market_summary( $post_id );

			case 'transaction_value':
				return Format::money( Fields::get( $post_id, 'value' ) );

			case 'transaction_line':
				$t = Repository::transaction( $post_id );
				return $t ? $t['line'] : '';

			case 'expert_role':
				$e = Repository::expert( $post_id );
				return $e ? $e['role_line'] : '';

			case 'research_type':
				$t = Repository::term( $post_id, 'axis_research_type' );
				return $t ? $t->name : '';

			case 'research_meta':
				$r = Repository::research( $post_id );
				return $r ? $r['meta'] : '';
		}

		return '';
	}

	/**
	 * "United States. 18 available assets, 214 transactions since 2020, 9 experts."
	 *
	 * @param int $market_id Market ID.
	 * @return string
	 */
	private static function market_summary( $market_id ) {
		$m = Repository::market( $market_id );
		if ( ! $m ) {
			return '';
		}
		$assets  = Repository::count_in_market( Post_Types::PROPERTY, $market_id );
		$deals   = Repository::count_in_market( Post_Types::TRANSACTION, $market_id );
		$experts = Repository::count_in_market( Post_Types::EXPERT, $market_id, 'markets' );
		$parts   = array();
		/* translators: %s: number of assets. */
		$parts[] = sprintf( _n( '%s available asset', '%s available assets', $assets, 'axis-cre' ), number_format_i18n( $assets ) );
		if ( $m['since'] ) {
			/* translators: 1: number of transactions, 2: year. */
			$parts[] = sprintf( _n( '%1$s transaction since %2$d', '%1$s transactions since %2$d', $deals, 'axis-cre' ), number_format_i18n( $deals ), $m['since'] );
		} else {
			/* translators: %s: number of transactions. */
			$parts[] = sprintf( _n( '%s transaction', '%s transactions', $deals, 'axis-cre' ), number_format_i18n( $deals ) );
		}
		/* translators: %s: number of experts. */
		$parts[] = sprintf( _n( '%s expert', '%s experts', $experts, 'axis-cre' ), number_format_i18n( $experts ) );
		$lead    = $m['country'] ? $m['country'] . '. ' : '';
		return $lead . implode( ', ', $parts ) . '.';
	}

	/**
	 * Hide bound blocks with no value, and add the hatch modifier to asset class lines.
	 *
	 * @param string    $content Rendered block.
	 * @param array     $block   Parsed block.
	 * @param \WP_Block $instance Block instance.
	 * @return string
	 */
	public static function render_block( $content, $block, $instance = null ) {
		$bindings = isset( $block['attrs']['metadata']['bindings'] ) ? $block['attrs']['metadata']['bindings'] : null;
		if ( ! $bindings || empty( $bindings['content']['source'] ) || 'axis/field' !== $bindings['content']['source'] ) {
			return $content;
		}
		$key     = isset( $bindings['content']['args']['key'] ) ? sanitize_key( $bindings['content']['args']['key'] ) : '';
		$post_id = ( $instance && isset( $instance->context['postId'] ) ) ? (int) $instance->context['postId'] : (int) get_the_ID();
		if ( '' === self::value( $post_id, $key ) ) {
			return '';
		}
		if ( 'asset_class_line' === $key ) {
			$slug = self::value( $post_id, 'asset_class' );
			$p    = new \WP_HTML_Tag_Processor( $content );
			if ( $slug && $p->next_tag() ) {
				$p->add_class( 'axis-class' );
				$p->add_class( 'axis-class--' . $slug );
				$content = $p->get_updated_html();
			}
		}
		return $content;
	}
}
