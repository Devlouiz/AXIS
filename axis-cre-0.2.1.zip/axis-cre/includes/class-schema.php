<?php
/**
 * Structured data (JSON-LD) for properties, markets, experts and research.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Prints one JSON-LD graph on single AXIS pages.
 */
class Schema {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'output' ), 20 );
	}

	/**
	 * Print the graph.
	 */
	public static function output() {
		if ( ! is_singular( Post_Types::all() ) ) {
			return;
		}
		/**
		 * Whether AXIS CRE prints JSON-LD. Return false when an SEO plugin handles it.
		 *
		 * @param bool $enabled Default true.
		 */
		if ( ! apply_filters( 'axis_cre_schema_enabled', true ) ) {
			return;
		}
		$data = self::data( (int) get_queried_object_id() );
		/**
		 * Filter the JSON-LD for an AXIS page.
		 *
		 * @param array $data    Schema.org data, or an empty array.
		 * @param int   $post_id Post ID.
		 */
		$data = apply_filters( 'axis_cre_schema', $data, (int) get_queried_object_id() );
		if ( ! $data ) {
			return;
		}
		echo "\n" . '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . '</script>' . "\n";
	}

	/**
	 * Schema.org data for a post.
	 *
	 * @param int $id Post ID.
	 * @return array<string, mixed>
	 */
	public static function data( $id ) {
		$type = get_post_type( $id );
		$base = array(
			'@context' => 'https://schema.org',
			'url'      => get_permalink( $id ),
			'name'     => get_the_title( $id ),
		);
		$desc = wp_strip_all_tags( get_the_excerpt( $id ) );
		if ( $desc ) {
			$base['description'] = $desc;
		}
		$image = get_the_post_thumbnail_url( $id, 'large' );
		if ( $image ) {
			$base['image'] = $image;
		}

		switch ( $type ) {
			case Post_Types::PROPERTY:
				$p     = Repository::property( $id );
				$place = array(
					'@type'   => 'Place',
					'name'    => $p['title'],
					'address' => array_filter(
						array(
							'@type'           => 'PostalAddress',
							'streetAddress'   => Fields::get( $id, 'address' ),
							'addressLocality' => Fields::get( $id, 'city' ),
							'addressRegion'   => Fields::get( $id, 'region' ),
							'postalCode'      => Fields::get( $id, 'postcode' ),
							'addressCountry'  => Fields::get( $id, 'country' ),
						)
					),
				);
				if ( null !== $p['lat'] && null !== $p['lng'] ) {
					$place['geo'] = array(
						'@type'     => 'GeoCoordinates',
						'latitude'  => $p['lat'],
						'longitude' => $p['lng'],
					);
				}
				$data = $base + array(
					'@type'           => 'RealEstateListing',
					'identifier'      => $p['label'],
					'contentLocation' => $place,
				);
				if ( $p['listed'] ) {
					$data['datePosted'] = $p['listed'];
				}
				if ( $p['price'] ) {
					$data['offers'] = array(
						'@type'         => 'Offer',
						'price'         => $p['price'],
						'priceCurrency' => self::currency(),
						'availability'  => 'https://schema.org/InStock',
					);
				}
				return $data;

			case Post_Types::MARKET:
				$m    = Repository::market( $id );
				$data = $base + array(
					'@type'      => 'Place',
					'identifier' => $m['label'],
				);
				if ( null !== $m['lat'] && null !== $m['lng'] ) {
					$data['geo'] = array(
						'@type'     => 'GeoCoordinates',
						'latitude'  => $m['lat'],
						'longitude' => $m['lng'],
					);
				}
				return $data;

			case Post_Types::EXPERT:
				$e    = Repository::expert( $id );
				$data = $base + array(
					'@type'    => 'Person',
					'jobTitle' => $e['job'],
					'worksFor' => array(
						'@type' => 'Organization',
						'name'  => get_bloginfo( 'name' ),
						'url'   => home_url( '/' ),
					),
				);
				if ( $e['email'] ) {
					$data['email'] = $e['email'];
				}
				if ( $e['phone'] ) {
					$data['telephone'] = $e['phone'];
				}
				if ( $e['linkedin'] ) {
					$data['sameAs'] = array( $e['linkedin'] );
				}
				if ( $e['markets'] ) {
					$data['areaServed'] = array_values( wp_list_pluck( $e['markets'], 'title' ) );
				}
				return array_filter( $data );

			case Post_Types::RESEARCH:
				$r       = Repository::research( $id );
				$data    = $base + array(
					'@type'         => 'Report',
					'headline'      => $r['title'],
					'datePublished' => get_the_date( 'c', $id ),
					'dateModified'  => get_the_modified_date( 'c', $id ),
					'publisher'     => array(
						'@type' => 'Organization',
						'name'  => get_bloginfo( 'name' ),
					),
				);
				$authors = array();
				foreach ( $r['experts'] as $eid ) {
					$e = Repository::expert( $eid );
					if ( $e ) {
						$authors[] = array(
							'@type' => 'Person',
							'name'  => $e['title'],
							'url'   => $e['url'],
						);
					}
				}
				if ( $authors ) {
					$data['author'] = $authors;
				}
				if ( $r['pages'] ) {
					$data['numberOfPages'] = $r['pages'];
				}
				if ( $r['markets'] ) {
					$data['spatialCoverage'] = array_values( wp_list_pluck( $r['markets'], 'title' ) );
				}
				return $data;

			case Post_Types::TRANSACTION:
				$t = Repository::transaction( $id );
				return $base + array(
					'@type'         => 'Article',
					'headline'      => $t['title'],
					'identifier'    => $t['label'],
					'datePublished' => get_the_date( 'c', $id ),
				);
		}
		return array();
	}

	/**
	 * ISO currency from the configured symbol, for offers.
	 *
	 * @return string
	 */
	private static function currency() {
		$map = array(
			'$'  => 'USD',
			'€'  => 'EUR',
			'£'  => 'GBP',
			'C$' => 'CAD',
			'A$' => 'AUD',
			'¥'  => 'JPY',
		);
		$sym = Format::settings()['currency'];
		/**
		 * ISO 4217 code used in offers.
		 *
		 * @param string $code   Currency code.
		 * @param string $symbol Configured symbol.
		 */
		return (string) apply_filters( 'axis_cre_currency_code', isset( $map[ $sym ] ) ? $map[ $sym ] : 'USD', $sym );
	}
}
