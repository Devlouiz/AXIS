<?php
/**
 * Block registration and server rendering for the 13 AXIS CRE blocks.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Registers blocks from /blocks and renders them.
 */
class Blocks {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_filter( 'block_categories_all', array( __CLASS__, 'category' ) );
		add_filter( 'wp_robots', array( __CLASS__, 'robots' ) );
		add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'sitemap_args' ), 10, 2 );
	}

	/**
	 * The shortlist shows one visitor's own lists: keep it out of search results.
	 *
	 * @param array<string, bool|string> $robots Robots directives.
	 * @return array<string, bool|string>
	 */
	public static function robots( $robots ) {
		if ( is_singular() && has_block( 'axis/shortlist' ) ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
		}
		return $robots;
	}

	/**
	 * Leave the shortlist page out of the page sitemap.
	 *
	 * @param array<string, mixed> $args      Query arguments.
	 * @param string               $post_type Post type.
	 * @return array<string, mixed>
	 */
	public static function sitemap_args( $args, $post_type ) {
		$id = Format::settings()['shortlist'];
		if ( 'page' === $post_type && $id ) {
			$args['post__not_in'] = array_merge( isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array(), array( $id ) );
		}
		return $args;
	}

	/**
	 * Block category.
	 *
	 * @param array<int, array<string, string>> $categories Categories.
	 * @return array<int, array<string, string>>
	 */
	public static function category( $categories ) {
		array_unshift(
			$categories,
			array(
				'slug'  => 'axis-cre',
				'title' => __( 'AXIS CRE', 'axis-cre' ),
			)
		);
		return $categories;
	}

	/**
	 * Register shared assets and every block in /blocks.
	 */
	public static function register() {
		wp_register_style( 'axis-cre', AXIS_CRE_URL . 'assets/css/axis-cre.css', array(), AXIS_CRE_VERSION );
		wp_register_script(
			'axis-cre-editor',
			AXIS_CRE_URL . 'assets/js/editor.js',
			array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render', 'wp-i18n' ),
			AXIS_CRE_VERSION,
			true
		);
		wp_set_script_translations( 'axis-cre-editor', 'axis-cre', AXIS_CRE_DIR . 'languages' );

		// Listing cards: photo stepping, save and compare, the compare tray and the hero search tabs.
		wp_register_script(
			'axis-cre-cards',
			AXIS_CRE_URL . 'assets/js/cards.js',
			array(),
			AXIS_CRE_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		foreach ( glob( AXIS_CRE_DIR . 'blocks/*/block.json' ) as $file ) {
			register_block_type( dirname( $file ) );
		}
	}

	/**
	 * Strings and settings for the card script.
	 *
	 * @return array<string, mixed>
	 */
	public static function card_strings() {
		return array(
			'shortlist' => Render::shortlist_url(),
			'max'       => 4,
			/* translators: %s: listing name. */
			'saved'     => __( '%s saved to your shortlist.', 'axis-cre' ),
			/* translators: %s: listing name. */
			'unsaved'   => __( '%s removed from your shortlist.', 'axis-cre' ),
			/* translators: %s: listing name. */
			'added'     => __( '%s added to compare.', 'axis-cre' ),
			/* translators: %s: listing name. */
			'removed'   => __( '%s removed from compare.', 'axis-cre' ),
			/* translators: %d: the most listings that can be compared. */
			'limit'     => __( 'You can compare up to %d listings. Remove one first.', 'axis-cre' ),
			/* translators: %d: number of listings. */
			'trayOne'   => __( '%d listing to compare', 'axis-cre' ),
			/* translators: %d: number of listings. */
			'trayMany'  => __( '%d listings to compare', 'axis-cre' ),
			'trayHint'  => __( 'Add up to four to see them side by side.', 'axis-cre' ),
			'compare'   => __( 'Compare', 'axis-cre' ),
			'clear'     => __( 'Clear', 'axis-cre' ),
			'cleared'   => __( 'Compare list cleared.', 'axis-cre' ),
			'tray'      => __( 'Compare listings', 'axis-cre' ),
			'price'     => __( 'Price', 'axis-cre' ),
			'rent'      => __( 'Rent', 'axis-cre' ),
			'any'       => __( 'Any', 'axis-cre' ),
			/* translators: 1: photo number, 2: number of photos. */
			'photo'     => __( 'Photo %1$d of %2$d', 'axis-cre' ),
		);
	}

	/**
	 * Render entry point used by each block's render.php.
	 *
	 * @param string               $name       Block folder name.
	 * @param array<string, mixed> $attributes Attributes.
	 * @param \WP_Block|null       $block      Block instance.
	 * @return string
	 */
	public static function render( $name, $attributes, $block = null ) {
		$post_id = 0;
		// On archives the global post is the first result, not the page's subject; ignore it there.
		if ( is_singular() || in_the_loop() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			$post_id = ( $block && isset( $block->context['postId'] ) ) ? (int) $block->context['postId'] : (int) get_the_ID();
		}
		$method = 'render_' . str_replace( '-', '_', $name );
		if ( ! method_exists( __CLASS__, $method ) ) {
			return '';
		}
		$html = self::$method( (array) $attributes, $post_id );
		if ( '' === $html ) {
			return '';
		}
		return '<div ' . get_block_wrapper_attributes( array( 'class' => 'axis-cre axis-cre-' . $name ) ) . '>' . $html . '</div>';
	}

	/**
	 * Attribute with default.
	 *
	 * @param array<string, mixed> $a   Attributes.
	 * @param string               $key Key.
	 * @param mixed                $def Default.
	 * @return mixed
	 */
	private static function attr( $a, $key, $def ) {
		return isset( $a[ $key ] ) && '' !== $a[ $key ] ? $a[ $key ] : $def;
	}

	/**
	 * Property filters read from the request.
	 *
	 * @return array<string, mixed>
	 */
	private static function property_filters() {
		$f = array(
			'q'         => Render::query_var( 'q', 'text' ),
			'type'      => Render::query_var( 'type' ),
			'market'    => Render::query_var( 'market', 'int' ),
			'listing'   => Render::query_var( 'listing' ),
			'min_size'  => Render::query_var( 'min_size', 'float' ),
			'max_size'  => Render::query_var( 'max_size', 'float' ),
			'min_price' => Render::query_var( 'min_price', 'float' ),
			'max_price' => Render::query_var( 'max_price', 'float' ),
			'min_rent'  => Render::query_var( 'min_rent', 'float' ),
			'max_rent'  => Render::query_var( 'max_rent', 'float' ),
			'min_cap'   => Render::query_var( 'min_cap', 'float' ),
		);
		// The hero search sends bands; turn them into ranges.
		$size = Render::query_var( 'size_band' );
		$band = self::bands();
		if ( $size && isset( $band['size'][ $size ] ) ) {
			list( $f['min_size'], $f['max_size'] ) = $band['size'][ $size ][1];
		}
		$price = Render::query_var( 'price_band' );
		$kind  = 'for-lease' === $f['listing'] ? 'rent' : 'price';
		if ( $price && isset( $band[ $kind ][ $price ] ) ) {
			list( $f[ 'min_' . $kind ], $f[ 'max_' . $kind ] ) = $band[ $kind ][ $price ][1];
		}
		return $f;
	}

	/**
	 * Search bands for the hero form: label and [min, max] ('' for open).
	 *
	 * @return array<string, array<string, array{0: string, 1: array{0: float|string, 1: float|string}}>>
	 */
	public static function bands() {
		$cur  = Format::settings()['currency'];
		$unit = Format::area_unit();
		return array(
			'size'  => array(
				'small'  => array( sprintf( /* translators: 1: area, 2: unit. */ __( 'Up to %1$s %2$s', 'axis-cre' ), number_format_i18n( 50000 ), $unit ), array( '', 50000 ) ),
				'medium' => array( sprintf( /* translators: 1: area, 2: area, 3: unit. */ __( '%1$s to %2$s %3$s', 'axis-cre' ), number_format_i18n( 50000 ), number_format_i18n( 250000 ), $unit ), array( 50000, 250000 ) ),
				'large'  => array( sprintf( /* translators: 1: area, 2: unit. */ __( 'Over %1$s %2$s', 'axis-cre' ), number_format_i18n( 250000 ), $unit ), array( 250000, '' ) ),
			),
			'price' => array(
				'low'  => array( sprintf( /* translators: %s: amount. */ __( 'Up to %s', 'axis-cre' ), $cur . '25M' ), array( '', 25000000 ) ),
				'mid'  => array( sprintf( /* translators: 1: amount, 2: amount. */ __( '%1$s to %2$s', 'axis-cre' ), $cur . '25M', $cur . '100M' ), array( 25000000, 100000000 ) ),
				'high' => array( sprintf( /* translators: %s: amount. */ __( 'Over %s', 'axis-cre' ), $cur . '100M' ), array( 100000000, '' ) ),
			),
			'rent'  => array(
				'low'  => array( sprintf( /* translators: 1: rent, 2: unit. */ __( 'Up to %1$s / %2$s', 'axis-cre' ), $cur . '25', $unit ), array( '', 25 ) ),
				'mid'  => array( sprintf( /* translators: 1: rent, 2: rent, 3: unit. */ __( '%1$s to %2$s / %3$s', 'axis-cre' ), $cur . '25', $cur . '50', $unit ), array( 25, 50 ) ),
				'high' => array( sprintf( /* translators: 1: rent, 2: unit. */ __( 'Over %1$s / %2$s', 'axis-cre' ), $cur . '50', $unit ), array( 50, '' ) ),
			),
		);
	}

	/**
	 * The property filter fields.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function property_fields() {
		return array(
			array(
				'name'        => 'q',
				'label'       => __( 'Location', 'axis-cre' ),
				'type'        => 'text',
				'placeholder' => __( 'City, market or street', 'axis-cre' ),
			),
			array(
				'name'    => 'type',
				'label'   => __( 'Property type', 'axis-cre' ),
				'type'    => 'select',
				'options' => Render::term_options( 'axis_property_type', __( 'All types', 'axis-cre' ) ),
			),
			array(
				'name'    => 'market',
				'label'   => __( 'Market', 'axis-cre' ),
				'type'    => 'select',
				'options' => Render::market_options( __( 'All markets', 'axis-cre' ) ),
			),
			array(
				'name'    => 'listing',
				'label'   => __( 'Listing', 'axis-cre' ),
				'type'    => 'select',
				'options' => Render::term_options( 'axis_listing_type', __( 'Buy or lease', 'axis-cre' ) ),
			),
			array(
				'name'        => 'min_size',
				/* translators: %s: area unit, for example sf. */
				'label'       => sprintf( __( 'Minimum size, %s', 'axis-cre' ), Format::area_unit() ),
				'type'        => 'number',
				'placeholder' => __( 'Any', 'axis-cre' ),
			),
			array(
				'name'        => 'max_price',
				'label'       => __( 'Maximum price', 'axis-cre' ),
				'type'        => 'number',
				'placeholder' => __( 'Any', 'axis-cre' ),
			),
			array(
				'name'        => 'min_cap',
				'label'       => __( 'Minimum cap rate, %', 'axis-cre' ),
				'type'        => 'number',
				'placeholder' => __( 'Any', 'axis-cre' ),
			),
		);
	}

	// ------------------------------------------------------------------ property blocks

	/**
	 * Property search: a GET form that drives property results and the archive.
	 *
	 * @param array<string, mixed> $a Attributes.
	 * @return string
	 */
	private static function render_property_search( $a ) {
		$archive = get_post_type_archive_link( Post_Types::PROPERTY );
		$action  = is_post_type_archive( Post_Types::PROPERTY ) || is_singular() ? '' : $archive;
		if ( 'hero' === self::attr( $a, 'layout', 'row' ) ) {
			return self::hero_search( $archive );
		}
		return Render::filter_form( self::property_fields(), __( 'Show results', 'axis-cre' ), self::attr( $a, 'layout', 'row' ), $action );
	}

	/**
	 * Hero search: For sale and For lease as tabs, then location, type, size and price.
	 * The tabs are radio buttons, so the form works without JavaScript.
	 *
	 * @param string $action Archive URL.
	 * @return string
	 */
	private static function hero_search( $action ) {
		static $n = 0;
		++$n;
		$id      = 'axis-hs' . $n;
		$listing = Render::query_var( 'listing' );
		$listing = $listing ? $listing : 'investment-sale';
		$bands   = self::bands();
		$tabs    = array(
			'investment-sale' => __( 'For sale', 'axis-cre' ),
			'for-lease'       => __( 'For lease', 'axis-cre' ),
		);
		$labels  = array();
		foreach ( array( 'price', 'rent' ) as $kind ) {
			foreach ( $bands[ $kind ] as $k => $b ) {
				$labels[ $kind ][ $k ] = $b[0];
			}
		}
		$out  = '<form class="axis-cre-hero-search" method="get" action="' . esc_url( $action ) . '" role="search" data-axis-bands="' . esc_attr( wp_json_encode( $labels ) ) . '">';
		$out .= '<fieldset class="axis-cre-hero-search__tabs"><legend class="screen-reader-text">' . esc_html__( 'Listing type', 'axis-cre' ) . '</legend>';
		foreach ( $tabs as $val => $label ) {
			$out .= '<label class="axis-cre-tab"><input type="radio" name="listing" value="' . esc_attr( $val ) . '"' . checked( $listing, $val, false ) . '><span>' . esc_html( $label ) . '</span></label>';
		}
		$out    .= '</fieldset><div class="axis-cre-hero-search__fields">';
		$out    .= '<div class="axis-cre-field is-wide"><label for="' . esc_attr( $id ) . '-q">' . esc_html__( 'Location', 'axis-cre' ) . '</label><input id="' . esc_attr( $id ) . '-q" name="q" type="search" autocomplete="off" value="' . esc_attr( (string) Render::query_var( 'q', 'text' ) ) . '" placeholder="' . esc_attr__( 'City, market or street', 'axis-cre' ) . '"></div>';
		$selects = array(
			'type'       => array( __( 'Property type', 'axis-cre' ), Render::term_options( 'axis_property_type', __( 'All types', 'axis-cre' ) ) ),
			'size_band'  => array( __( 'Size', 'axis-cre' ), array( '' => __( 'Any size', 'axis-cre' ) ) + wp_list_pluck( $bands['size'], 0 ) ),
			'price_band' => array( 'for-lease' === $listing ? __( 'Rent', 'axis-cre' ) : __( 'Price', 'axis-cre' ), array( '' => __( 'Any', 'axis-cre' ) ) + ( 'for-lease' === $listing ? $labels['rent'] : $labels['price'] ) ),
		);
		foreach ( $selects as $name => $sel ) {
			$cur  = Render::query_var( $name );
			$out .= '<div class="axis-cre-field"><label for="' . esc_attr( $id . '-' . $name ) . '"' . ( 'price_band' === $name ? ' data-axis-price-label' : '' ) . '>' . esc_html( $sel[0] ) . '</label><select id="' . esc_attr( $id . '-' . $name ) . '" name="' . esc_attr( $name ) . '">';
			foreach ( $sel[1] as $val => $label ) {
				$out .= '<option value="' . esc_attr( (string) $val ) . '"' . selected( (string) $cur, (string) $val, false ) . '>' . esc_html( $label ) . '</option>';
			}
			$out .= '</select></div>';
		}
		$out .= '<button type="submit" class="wp-element-button axis-cre-button axis-cre-hero-search__go">' . Render::icon( 'search' ) . esc_html__( 'Search', 'axis-cre' ) . '</button>';
		$out .= '</div></form>';
		Render::card_assets();
		return $out;
	}

	/**
	 * Property results in grid, list, compact or table layout.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function render_property_results( $a, $post_id ) {
		$layout  = self::attr( $a, 'layout', 'grid' );
		$per     = (int) self::attr( $a, 'perPage', 6 );
		$filters = self::property_filters();
		$page    = max( 1, (int) Render::query_var( 'axis_page', 'int' ) );
		$args    = array_merge(
			$filters,
			array(
				'per_page' => $per,
				'page'     => $page,
				'featured' => ! empty( $a['featured'] ),
			)
		);
		if ( 'current-market' === self::attr( $a, 'scope', 'all' ) ) {
			$m = Repository::market_for( $post_id );
			if ( $m ) {
				$args['market'] = $m['id'];
			}
		}
		if ( Post_Types::PROPERTY === get_post_type( $post_id ) ) {
			$args['exclude'] = array( $post_id );
		}
		$res = Repository::properties( $args );
		if ( ! $res['items'] && $args['featured'] ) {
			$args['featured'] = false;
			$res              = Repository::properties( $args );
		}
		if ( ! $res['items'] ) {
			$filtered = array_filter( $filters );
			return Render::empty_state(
				$filtered ? __( 'No assets match these filters', 'axis-cre' ) : __( 'No assets listed yet', 'axis-cre' ),
				$filtered ? __( 'Try a wider size or price range, or include more property types.', 'axis-cre' ) : __( 'Published properties appear here automatically.', 'axis-cre' ),
				$filtered ? remove_query_arg( array_merge( array_keys( $filters ), array( 'axis_page' ) ) ) : '',
				__( 'Clear filters', 'axis-cre' )
			);
		}
		if ( 'table' === $layout ) {
			$out = Render::asset_table( $res['items'], __( 'Available assets', 'axis-cre' ) );
		} else {
			$cards = array_map(
				function ( $p ) use ( $layout ) {
					return Render::asset_card( $p, $layout );
				},
				$res['items']
			);
			$out   = Render::grid( $cards, __( 'Assets', 'axis-cre' ), 'is-' . $layout );
		}
		if ( is_post_type_archive( Post_Types::PROPERTY ) || array_filter( $filters ) ) {
			$out .= Render::pagination( $page, $res['pages'] );
		}
		return $out;
	}

	/**
	 * The four key metrics of a property.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function render_property_metrics( $a, $post_id ) {
		$p = Repository::property( $post_id );
		if ( ! $p ) {
			return '';
		}
		$floors  = (int) Fields::get( $post_id, 'floors' );
		$tenants = (int) Fields::get( $post_id, 'tenants' );
		$noi     = Fields::get( $post_id, 'noi' );
		$figures = array(
			array(
				'value' => Format::area( $p['size'] ),
				'label' => __( 'Building area', 'axis-cre' ),
				/* translators: %d: number of floors. */
				'note'  => $floors ? sprintf( _n( '%d floor', '%d floors', $floors, 'axis-cre' ), $floors ) : '',
			),
			array(
				'value' => Format::percent( $p['occupancy'] ),
				'label' => __( 'Occupancy', 'axis-cre' ),
				/* translators: %d: number of tenants. */
				'note'  => $tenants ? sprintf( _n( '%d tenant', '%d tenants', $tenants, 'axis-cre' ), $tenants ) : '',
			),
		);
		if ( $p['price'] ) {
			$figures[] = array(
				'value' => Format::money( $p['price'] ),
				'label' => __( 'Asking price', 'axis-cre' ),
				// Price per area unit, for example $201.19 / sf.
				'note'  => $p['size'] ? Format::rent( $p['price'] / $p['size'] ) : '',
			);
		} elseif ( $p['lease'] ) {
			$figures[] = array(
				'value' => Format::rent( $p['lease'] ),
				'label' => __( 'Lease rate', 'axis-cre' ),
				'note'  => __( 'Per year', 'axis-cre' ),
			);
		}
		$figures[] = array(
			'value' => Format::percent( $p['cap'] ),
			'label' => __( 'Cap rate', 'axis-cre' ),
			/* translators: %s: net operating income, for example $5.2M. */
			'note'  => $noi ? sprintf( __( 'On %s net operating income', 'axis-cre' ), Format::money( $noi ) ) : '',
		);
		return Render::figures( $figures );
	}

	/**
	 * Labelled specification rows; empty fields are left out.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function render_property_specifications( $a, $post_id ) {
		$p = Repository::property( $post_id );
		if ( ! $p ) {
			return '';
		}
		$g    = function ( $k ) use ( $post_id ) {
			return Fields::get( $post_id, $k );
		};
		$rows = array(
			__( 'Property type', 'axis-cre' )        => $p['type_name'],
			__( 'Asset class', 'axis-cre' )          => $p['class'],
			__( 'Address', 'axis-cre' )              => trim( implode( ', ', array_filter( array( $g( 'address' ), $p['city'], $g( 'postcode' ) ) ) ) ),
			__( 'Year built', 'axis-cre' )           => $g( 'year_built' ),
			__( 'Renovated', 'axis-cre' )            => $g( 'renovated' ),
			__( 'Floors', 'axis-cre' )               => $g( 'floors' ),
			__( 'Building area', 'axis-cre' )        => Format::area( $p['size'] ),
			__( 'Typical floor', 'axis-cre' )        => Format::area( $g( 'typical_floor' ) ),
			__( 'Units', 'axis-cre' )                => $g( 'units' ) ? number_format_i18n( (int) $g( 'units' ) ) : '',
			__( 'Lot size', 'axis-cre' )             => $g( 'lot_size' ) ? sprintf( /* translators: %s: acres. */ __( '%s acres', 'axis-cre' ), Format::trim( (float) $g( 'lot_size' ), 2 ) ) : '',
			__( 'Parking', 'axis-cre' )              => $g( 'parking' ) ? sprintf( /* translators: %s: number of spaces. */ __( '%s spaces', 'axis-cre' ), number_format_i18n( (int) $g( 'parking' ) ) ) : '',
			__( 'Occupancy', 'axis-cre' )            => Format::percent( $p['occupancy'] ),
			__( 'Net operating income', 'axis-cre' ) => Format::money( $g( 'noi' ) ),
			__( 'Cap rate', 'axis-cre' )             => Format::percent( $p['cap'] ),
			__( 'Zoning', 'axis-cre' )               => $g( 'zoning' ),
		);
		$rows = array_filter(
			$rows,
			function ( $v ) {
				return '' !== (string) $v && '0' !== (string) $v;
			}
		);
		if ( ! $rows ) {
			return '';
		}
		$out = '<dl class="axis-cre-specs">';
		foreach ( $rows as $k => $v ) {
			$out .= '<div><dt>' . esc_html( $k ) . '</dt><dd>' . esc_html( (string) $v ) . '</dd></div>';
		}
		return $out . '</dl>';
	}

	/**
	 * Accessible gallery: real buttons, announced counter, arrow keys.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function render_property_gallery( $a, $post_id ) {
		$ids = array_map( 'intval', (array) Fields::get( $post_id, 'gallery' ) );
		if ( ! $ids && has_post_thumbnail( $post_id ) ) {
			$ids = array( (int) get_post_thumbnail_id( $post_id ) );
		}
		$ids = array_values( array_filter( $ids, 'wp_attachment_is_image' ) );
		if ( ! $ids ) {
			return '';
		}
		$count = count( $ids );
		wp_interactivity_state(
			'axis-cre/gallery',
			array(
				'enhanced'  => false,
				'isActive'  => function () {
					$c = wp_interactivity_get_context();
					return isset( $c['i'] ) && (int) $c['i'] === (int) $c['index'];
				},
				'countText' => function () {
					$c = wp_interactivity_get_context();
					/* translators: 1: current photo, 2: number of photos. */
					return sprintf( __( 'Photo %1$d of %2$d', 'axis-cre' ), (int) $c['index'] + 1, (int) $c['count'] );
				},
				/* translators: 1: current photo, 2: number of photos. */
				'i18nCount' => __( 'Photo %1$d of %2$d', 'axis-cre' ),
			)
		);
		$ctx  = array(
			'index' => 0,
			'count' => $count,
		);
		$out  = '<section class="axis-cre-gallery" data-wp-interactive="axis-cre/gallery" data-wp-context="' . esc_attr( wp_json_encode( $ctx ) ) . '" data-wp-init="callbacks.init" data-wp-class--is-enhanced="state.enhanced" data-wp-on--keydown="actions.onKey" aria-roledescription="' . esc_attr__( 'gallery', 'axis-cre' ) . '" aria-label="' . esc_attr( get_the_title( $post_id ) ) . '">';
		$out .= '<div class="axis-cre-gallery__stage">';
		foreach ( $ids as $i => $id ) {
			$caption = wp_get_attachment_caption( $id );
			$out    .= '<figure class="axis-cre-gallery__slide" data-wp-context="' . esc_attr( wp_json_encode( array( 'i' => $i ) ) ) . '" data-wp-class--is-active="state.isActive">' . Render::image( $id, 'full' );
			$out    .= $caption ? '<figcaption>' . esc_html( $caption ) . '</figcaption>' : '';
			$out    .= '</figure>';
		}
		$out .= '</div>';
		if ( $count > 1 ) {
			$out .= '<div class="axis-cre-gallery__bar"><p class="axis-cre-gallery__count" aria-live="polite" data-wp-text="state.countText"></p><div class="axis-cre-gallery__buttons">';
			$out .= '<button type="button" class="axis-cre-button is-secondary" data-wp-on--click="actions.prev">' . esc_html__( 'Previous photo', 'axis-cre' ) . '</button>';
			$out .= '<button type="button" class="axis-cre-button is-secondary" data-wp-on--click="actions.next">' . esc_html__( 'Next photo', 'axis-cre' ) . '</button></div></div>';
			$out .= '<ul class="axis-cre-gallery__thumbs">';
			foreach ( $ids as $i => $id ) {
				$caption = wp_get_attachment_caption( $id );
				/* translators: 1: photo number, 2: caption. */
				$label = $caption ? sprintf( __( 'Show photo %1$d: %2$s', 'axis-cre' ), $i + 1, $caption ) : sprintf( /* translators: %d: photo number. */ __( 'Show photo %d', 'axis-cre' ), $i + 1 );
				$out  .= '<li data-wp-context="' . esc_attr( wp_json_encode( array( 'i' => $i ) ) ) . '"><button type="button" aria-label="' . esc_attr( $label ) . '" data-wp-on--click="actions.go" data-wp-bind--aria-pressed="state.isActive">' . wp_get_attachment_image( $id, 'thumbnail', false, array( 'alt' => '' ) ) . '</button></li>';
			}
			$out .= '</ul>';
		}
		return $out . '</section>';
	}

	/**
	 * Documents with type and size; gated ones offer a request instead of a download.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function render_property_documents( $a, $post_id ) {
		$docs = (array) Fields::get( $post_id, 'documents' );
		if ( ! $docs ) {
			return '<p class="axis-cre-muted">' . esc_html__( 'Documents are available on request from the listing broker.', 'axis-cre' ) . '</p>';
		}
		$experts = array_map( 'intval', (array) Fields::get( $post_id, 'experts' ) );
		$broker  = $experts ? Repository::expert( $experts[0] ) : null;
		$gated   = false;
		$rows    = '';
		foreach ( $docs as $doc ) {
			$id = isset( $doc['id'] ) ? (int) $doc['id'] : 0;
			if ( ! $id || ! get_post( $id ) ) {
				continue;
			}
			$file = get_attached_file( $id );
			$ext  = strtoupper( (string) pathinfo( (string) $file, PATHINFO_EXTENSION ) );
			$size = $file && file_exists( $file ) ? size_format( filesize( $file ), 1 ) : '';
			$name = get_the_title( $id );
			$meta = implode( ', ', array_filter( array( $ext, $size ) ) );
			if ( ! empty( $doc['gated'] ) ) {
				$gated = true;
				if ( $broker && $broker['email'] ) {
					/* translators: 1: document name, 2: property name. */
					$subject = sprintf( __( 'Access request: %1$s, %2$s', 'axis-cre' ), $name, get_the_title( $post_id ) );
					$href    = 'mailto:' . antispambot( $broker['email'] ) . '?subject=' . rawurlencode( $subject );
				} else {
					$href = '#broker';
				}
				$action = '<a href="' . esc_url( $href, array( 'mailto', 'http', 'https' ) ) . '">' . esc_html__( 'Request access', 'axis-cre' ) . '<span class="screen-reader-text">: ' . esc_html( $name ) . '</span></a>';
			} else {
				$action = '<a href="' . esc_url( wp_get_attachment_url( $id ) ) . '" download>' . esc_html__( 'Download', 'axis-cre' ) . '<span class="screen-reader-text">: ' . esc_html( $name ) . '</span></a>';
			}
			$rows .= '<li><span class="axis-cre-docs__name">' . esc_html( $name ) . '<span class="is-style-technical-label">' . esc_html( $meta ) . '</span></span>' . $action . '</li>';
		}
		if ( '' === $rows ) {
			return '';
		}
		$out = $gated ? '<p class="axis-cre-muted">' . esc_html__( 'Some documents need a signed confidentiality agreement. Request access and the listing team replies within one working day.', 'axis-cre' ) . '</p>' : '';
		return $out . '<ul class="axis-cre-docs">' . $rows . '</ul>';
	}

	/**
	 * Related assets in three tabs, chosen by rule.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function render_related_assets( $a, $post_id ) {
		$p = Repository::property( $post_id );
		if ( ! $p ) {
			return '';
		}
		$per    = (int) self::attr( $a, 'perPage', 3 );
		$base   = array(
			'per_page' => $per,
			'exclude'  => array( $post_id ),
		);
		$groups = array(
			__( 'Same market', 'axis-cre' )           => $p['market'] ? Repository::properties( $base + array( 'market' => $p['market'] ) )['items'] : array(),
			__( 'Same asset type', 'axis-cre' )       => $p['type'] ? Repository::properties( $base + array( 'type' => $p['type'] ) )['items'] : array(),
			__( 'Same transaction type', 'axis-cre' ) => $p['status_slug'] ? Repository::properties( $base + array( 'listing' => $p['status_slug'] ) )['items'] : array(),
		);
		$groups = array_filter( $groups );
		if ( ! $groups ) {
			return '';
		}
		wp_interactivity_state(
			'axis-cre/tabs',
			array(
				'enhanced'   => false,
				'isSelected' => function () {
					$c = wp_interactivity_get_context();
					return (int) $c['i'] === (int) $c['active'];
				},
			)
		);
		$uid  = 'axis-rel-' . $post_id;
		$out  = '<div class="axis-cre-tabs" data-wp-interactive="axis-cre/tabs" data-wp-context="' . esc_attr( wp_json_encode( array( 'active' => 0 ) ) ) . '" data-wp-init="callbacks.init" data-wp-class--is-enhanced="state.enhanced">';
		$out .= '<div class="axis-cre-tabs__list" role="tablist" aria-label="' . esc_attr__( 'Related assets', 'axis-cre' ) . '" data-wp-on--keydown="actions.onKey">';
		$i    = 0;
		foreach ( array_keys( $groups ) as $label ) {
			$out .= '<button type="button" role="tab" id="' . esc_attr( $uid . '-t' . $i ) . '" aria-controls="' . esc_attr( $uid . '-p' . $i ) . '" data-wp-context="' . esc_attr( wp_json_encode( array( 'i' => $i ) ) ) . '" data-wp-bind--aria-selected="state.isSelected" data-wp-bind--tabindex="state.tabIndex" data-wp-on--click="actions.select">' . esc_html( $label ) . '</button>';
			++$i;
		}
		$out .= '</div>';
		$i    = 0;
		foreach ( $groups as $label => $items ) {
			$cards = array_map(
				function ( $item ) {
					return Render::asset_card( $item, 'grid' );
				},
				$items
			);
			$out  .= '<section class="axis-cre-tabs__panel" role="tabpanel" id="' . esc_attr( $uid . '-p' . $i ) . '" aria-labelledby="' . esc_attr( $uid . '-t' . $i ) . '" data-wp-context="' . esc_attr( wp_json_encode( array( 'i' => $i ) ) ) . '" data-wp-class--is-active="state.isSelected"><h3 class="axis-cre-tabs__heading">' . esc_html( $label ) . '</h3>' . Render::grid( $cards, $label ) . '</section>';
			++$i;
		}
		return $out . '</div>';
	}

	/**
	 * Related listings: chosen by rule relative to the post the block is on.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function render_related_listings( $a, $post_id ) {
		$res = Related::find( $a, $post_id );
		if ( ! $res['items'] ) {
			return '';
		}
		$layout  = self::attr( $a, 'layout', 'grid' );
		$unit    = 'km' === self::attr( $a, 'unit', 'mi' ) ? 'km' : 'mi';
		$columns = max( 2, min( 4, (int) self::attr( $a, 'columns', 3 ) ) );
		$heading = ! isset( $a['showHeading'] ) || ! empty( $a['showHeading'] ) ? trim( (string) self::attr( $a, 'heading', '' ) ) : '';
		if ( '' === $heading && ( ! isset( $a['showHeading'] ) || ! empty( $a['showHeading'] ) ) ) {
			$heading = self::related_heading( $res['subject'], $post_id );
		}
		$show_d = ! isset( $a['showDistance'] ) || ! empty( $a['showDistance'] );
		$show_r = ! empty( $a['showReason'] );
		$near   = isset( $res['rules']['radius'] ) || 'nearest' === self::attr( $a, 'orderBy', 'match' );

		$cards = array();
		foreach ( $res['items'] as $p ) {
			if ( $show_d && $near ) {
				$p['distance_label'] = Related::distance_label( $p['distance'], $unit );
			}
			if ( $show_r ) {
				$p['reason'] = Related::reason( $p['met'], $res['rules'] );
			}
			$cards[] = Render::asset_card( $p, 'carousel' === $layout ? 'grid' : $layout );
		}
		$label = '' !== $heading ? $heading : __( 'Related listings', 'axis-cre' );
		$grid  = Render::grid( $cards, $label, 'is-' . ( 'carousel' === $layout ? 'grid' : $layout ) . ' has-' . $columns . '-columns' );

		$out = '';
		if ( '' !== $heading ) {
			$out .= '<div class="axis-cre-related__head"><h2 class="axis-cre-related__title">' . esc_html( $heading ) . '</h2>';
			$more = self::related_more( $res['subject'], $res['rules'] );
			if ( $more ) {
				$out .= '<a class="axis-cre-button is-secondary" href="' . esc_url( $more ) . '">' . esc_html__( 'See all', 'axis-cre' ) . Render::icon( 'arrow' ) . '</a>';
			}
			$out .= '</div>';
		}
		if ( 'carousel' === $layout ) {
			// The AXIS theme turns this into a scroll-snap carousel; elsewhere it stays a grid.
			$out .= '<div class="is-style-axis-carousel axis-per-' . $columns . '">' . $grid . '</div>';
		} else {
			$out .= $grid;
		}
		return $out;
	}

	/**
	 * Default heading that fits the page: similar listings on a property, the market's listings on a market.
	 *
	 * @param array<string, mixed> $s       Subject.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function related_heading( $s, $post_id ) {
		switch ( $s['kind'] ) {
			case 'property':
				return __( 'Similar listings', 'axis-cre' );
			case 'market':
				/* translators: %s: market name. */
				return sprintf( __( 'Listings in %s', 'axis-cre' ), get_the_title( $post_id ) );
			case 'expert':
				/* translators: %s: first name. */
				return sprintf( __( 'Listed by %s', 'axis-cre' ), strtok( get_the_title( $post_id ), ' ' ) );
			case 'transaction':
				return __( 'Comparable listings', 'axis-cre' );
			case 'research':
				return __( 'Listings in these markets', 'axis-cre' );
		}
		return __( 'Latest listings', 'axis-cre' );
	}

	/**
	 * Archive link that repeats the strict rules as search filters.
	 *
	 * @param array<string, mixed> $s     Subject.
	 * @param array<string, mixed> $rules Rules.
	 * @return string
	 */
	private static function related_more( $s, $rules ) {
		$url = get_post_type_archive_link( Post_Types::PROPERTY );
		if ( ! $url ) {
			return '';
		}
		$args = array();
		if ( isset( $rules['market'] ) ) {
			$args['market'] = $rules['market'][0];
		}
		if ( isset( $rules['type'] ) ) {
			$args['type'] = $rules['type'];
		}
		if ( isset( $rules['listing'] ) ) {
			$args['listing'] = $rules['listing'];
		}
		return add_query_arg( $args, $url );
	}

	/**
	 * Comma-separated listing IDs from the address.
	 *
	 * @param string $key Parameter.
	 * @return int[]
	 */
	private static function id_list( $key ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only list of public listing IDs.
		$raw = isset( $_GET[ $key ] ) && is_string( $_GET[ $key ] ) ? sanitize_text_field( wp_unslash( $_GET[ $key ] ) ) : '';
		$ids = array_values( array_unique( array_filter( array_map( 'absint', explode( ',', $raw ) ) ) ) );
		return array_slice( $ids, 0, 50 );
	}

	/**
	 * Shortlist: saved listings as cards, or up to four side by side.
	 * The lists live in the visitor's browser; the card script puts them in the address.
	 *
	 * @return string
	 */
	private static function render_shortlist() {
		Render::card_assets();
		$view    = 'compare' === Render::query_var( 'view' ) ? 'compare' : 'saved';
		$saved   = self::id_list( 'saved' );
		$compare = array_slice( self::id_list( 'compare' ), 0, 4 );
		$keep    = array(
			'saved'   => $saved ? implode( ',', $saved ) : false,
			'compare' => $compare ? implode( ',', $compare ) : false,
		);
		$tabs    = array(
			'saved'   => array( __( 'Saved', 'axis-cre' ), count( $saved ) ),
			'compare' => array( __( 'Compare', 'axis-cre' ), count( $compare ) ),
		);

		$out  = '<div class="axis-cre-shortlist__inner" data-axis-shortlist-view="' . esc_attr( $view ) . '">';
		$out .= '<nav class="axis-cre-typetabs" aria-label="' . esc_attr__( 'Shortlist', 'axis-cre' ) . '"><ul>';
		foreach ( $tabs as $k => $tab ) {
			$out .= '<li><a href="' . esc_url( add_query_arg( array_merge( $keep, array( 'view' => $k ) ) ) ) . '"' . ( $k === $view ? ' aria-current="page"' : '' ) . '>' . esc_html( $tab[0] ) . ' <span>' . esc_html( number_format_i18n( $tab[1] ) ) . '</span></a></li>';
		}
		$out .= '</ul></nav>';

		$ids   = 'compare' === $view ? $compare : $saved;
		$items = $ids ? Repository::properties(
			array(
				'ids'      => $ids,
				'per_page' => count( $ids ),
			)
		)['items'] : array();

		$archive = (string) get_post_type_archive_link( Post_Types::PROPERTY );
		$empty   = 'compare' === $view
			? Render::empty_state( __( 'Nothing to compare yet', 'axis-cre' ), __( 'Use the compare button on up to four listing cards, then come back here to see them side by side.', 'axis-cre' ), $archive, __( 'Browse listings', 'axis-cre' ) )
			: Render::empty_state( __( 'No saved listings yet', 'axis-cre' ), __( 'Use the heart on any listing card to keep it here. Saved listings stay in this browser.', 'axis-cre' ), $archive, __( 'Browse listings', 'axis-cre' ) );
		$out    .= '<div class="axis-cre-shortlist__empty"' . ( $items ? ' hidden' : '' ) . '>' . $empty . '</div>';
		if ( ! $items ) {
			return $out . '</div>';
		}

		$out .= '<h2 class="screen-reader-text">' . esc_html( 'saved' === $view ? __( 'Saved listings', 'axis-cre' ) : __( 'Listings compared', 'axis-cre' ) ) . '</h2>';
		if ( 'saved' === $view ) {
			$out .= '<ul class="axis-cre-grid is-grid" aria-label="' . esc_attr__( 'Saved listings', 'axis-cre' ) . '">';
			foreach ( $items as $p ) {
				$out .= '<li data-axis-item="' . (int) $p['id'] . '">' . Render::asset_card( $p, 'grid' ) . '</li>';
			}
			return $out . '</ul></div>';
		}
		return $out . self::compare_table( $items ) . '</div>';
	}

	/**
	 * Listings side by side, with the strongest figure in each row marked.
	 *
	 * @param array<int, array<string, mixed>> $items Properties.
	 * @return string
	 */
	private static function compare_table( $items ) {
		$per_area = function ( $p ) {
			return $p['price'] && $p['size'] ? $p['price'] / $p['size'] : null;
		};
		$rows     = array(
			array(
				__( 'Asking price', 'axis-cre' ),
				function ( $p ) {
						return $p['price'] ? Format::money( $p['price'] ) : '';
				},
				null,
			),
			array(
				__( 'Lease rate', 'axis-cre' ),
				function ( $p ) {
						return $p['lease'] ? Format::rent( $p['lease'] ) : '';
				},
				'min:lease',
			),
			array(
				sprintf( /* translators: %s: area unit. */ __( 'Price per %s', 'axis-cre' ), Format::area_unit() ),
				function ( $p ) use ( $per_area ) {
						$v = $per_area( $p );
						return $v ? (string) preg_replace( '/\.00 /', ' ', Format::rent( round( $v ) ) ) : '';
				},
				'min:per_area',
			),
			array(
				__( 'Cap rate', 'axis-cre' ),
				function ( $p ) {
						return Format::percent( $p['cap'] );
				},
				'max:cap',
			),
			array(
				__( 'Building area', 'axis-cre' ),
				function ( $p ) {
						return Format::area( $p['size'] );
				},
				null,
			),
			array(
				__( 'Occupancy', 'axis-cre' ),
				function ( $p ) {
						return Format::percent( $p['occupancy'] );
				},
				'max:occupancy',
			),
			array(
				__( 'Property type', 'axis-cre' ),
				function ( $p ) {
						return trim( implode( ', ', array_filter( array( $p['type_name'], $p['class'] ) ) ) );
				},
				null,
			),
			array(
				__( 'Market', 'axis-cre' ),
				function ( $p ) {
						return $p['market_name'];
				},
				null,
			),
			array(
				__( 'Location', 'axis-cre' ),
				function ( $p ) {
						return $p['city'];
				},
				null,
			),
			array(
				__( 'Year built', 'axis-cre' ),
				function ( $p ) {
						return $p['year'] ? (string) $p['year'] : '';
				},
				null,
			),
			array(
				__( 'Floors from', 'axis-cre' ),
				function ( $p ) {
						return Format::area( $p['floor'] );
				},
				null,
			),
			array(
				__( 'Units', 'axis-cre' ),
				function ( $p ) {
						return $p['units'] ? number_format_i18n( $p['units'] ) : '';
				},
				null,
			),
			array(
				__( 'Status', 'axis-cre' ),
				function ( $p ) {
						return $p['status'];
				},
				null,
			),
			array(
				__( 'Listing broker', 'axis-cre' ),
				function ( $p ) {
						return $p['broker'] ? $p['broker']['title'] : '';
				},
				null,
			),
		);

		// Best value per marked row, when two or more listings have one.
		$best = array();
		foreach ( $rows as $i => $row ) {
			if ( ! $row[2] ) {
				continue;
			}
			list( $dir, $field ) = explode( ':', $row[2] );
			$vals                = array();
			foreach ( $items as $p ) {
				$v = 'per_area' === $field ? $per_area( $p ) : $p[ $field ];
				if ( null !== $v && '' !== $v ) {
					$vals[ $p['id'] ] = (float) $v;
				}
			}
			if ( count( $vals ) > 1 && count( array_unique( $vals ) ) > 1 ) {
				$best[ $i ] = array_keys( $vals, 'min' === $dir ? min( $vals ) : max( $vals ), true );
			}
		}

		$out  = '<section class="axis-cre-table-wrap axis-cre-compare" tabindex="0" aria-label="' . esc_attr__( 'Listings compared', 'axis-cre' ) . '"><table class="axis-cre-table">';
		$out .= '<caption class="screen-reader-text">' . esc_html__( 'Listings compared', 'axis-cre' ) . '</caption><thead><tr><td></td>';
		foreach ( $items as $p ) {
			$data = array(
				'id'    => $p['id'],
				'title' => $p['title'],
				'url'   => $p['url'],
				'price' => Render::price_parts( $p )[0],
				'photo' => $p['image'] ? (string) wp_get_attachment_image_url( $p['image'], 'thumbnail' ) : '',
			);
			$out .= '<th scope="col" data-axis-item="' . (int) $p['id'] . '"><div class="axis-cre-compare__head" data-axis-listing="' . esc_attr( wp_json_encode( $data ) ) . '">';
			$out .= '<a class="axis-cre-compare__photo" href="' . esc_url( $p['url'] ) . '" tabindex="-1" aria-hidden="true">' . Render::image( $p['image'], 'medium_large' ) . '</a>';
			$out .= '<a class="axis-cre-compare__title" href="' . esc_url( $p['url'] ) . '">' . esc_html( $p['title'] ) . '</a>';
			/* translators: %s: listing name. */
			$out .= '<button type="button" class="axis-cre-compare__remove" data-axis-action="compare" aria-pressed="true" aria-label="' . esc_attr( sprintf( __( 'Remove %s from compare', 'axis-cre' ), $p['title'] ) ) . '">' . Render::icon( 'close' ) . '<span aria-hidden="true">' . esc_html__( 'Remove', 'axis-cre' ) . '</span></button>';
			$out .= '</div></th>';
		}
		$out .= '</tr></thead><tbody>';
		foreach ( $rows as $i => $row ) {
			$cells = array();
			foreach ( $items as $p ) {
				$cells[ $p['id'] ] = (string) call_user_func( $row[1], $p );
			}
			if ( ! array_filter( $cells ) ) {
				continue;
			}
			$out .= '<tr><th scope="row">' . esc_html( $row[0] ) . '</th>';
			foreach ( $cells as $id => $v ) {
				$is_best = isset( $best[ $i ] ) && in_array( $id, $best[ $i ], true );
				$out    .= '<td data-axis-item="' . (int) $id . '"' . ( $is_best ? ' class="is-best"' : '' ) . '>' . ( '' === $v ? '<span class="axis-cre-muted" aria-hidden="true">–</span><span class="screen-reader-text">' . esc_html__( 'Not given', 'axis-cre' ) . '</span>' : esc_html( $v ) );
				$out    .= $is_best ? ' <span class="axis-cre-badge is-soft">' . esc_html__( 'Best', 'axis-cre' ) . '</span>' : '';
				$out    .= '</td>';
			}
			$out .= '</tr>';
		}
		return $out . '</tbody></table></section>';
	}

	/**
	 * Header tools: saved and compare counters that open the shortlist.
	 *
	 * @return string
	 */
	private static function render_listing_tools() {
		$url = Render::shortlist_url();
		if ( ! $url ) {
			return '';
		}
		Render::card_assets();
		$tools = array(
			'saved'   => array( 'heart', __( 'Saved listings', 'axis-cre' ) ),
			'compare' => array( 'compare', __( 'Compare listings', 'axis-cre' ) ),
		);
		$out   = '';
		foreach ( $tools as $view => $t ) {
			$out .= '<a class="axis-cre-tool" href="' . esc_url( add_query_arg( 'view', $view, $url ) ) . '" data-axis-shortlist="' . esc_attr( $view ) . '">' . Render::icon( $t[0] ) . '<span class="screen-reader-text">' . esc_html( $t[1] ) . '</span><span class="axis-cre-tool__n" data-axis-count="' . esc_attr( $view ) . '" hidden>0</span></a>';
		}
		return $out;
	}

	// ------------------------------------------------------------------ market blocks

	/**
	 * Market figures by property type, with charts in full mode.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function render_market_snapshot( $a, $post_id ) {
		$mode = self::attr( $a, 'mode', 'full' );
		if ( 'table' === $mode ) {
			return self::market_table();
		}
		$m = Repository::market_for( $post_id );
		if ( ! $m || ! $m['sectors'] ) {
			return '';
		}

		if ( 'compact' === $mode ) {
			$p      = Repository::property( $post_id );
			$sector = $m['sectors'][0];
			foreach ( $m['sectors'] as $s ) {
				if ( $p && $s['slug'] === $p['type'] ) {
					$sector = $s;
				}
			}
			return '<dl class="axis-cre-rows">' .
				'<div><dt>' . esc_html__( 'Vacancy', 'axis-cre' ) . '</dt><dd>' . esc_html( Format::percent( $sector['vacancy'] ) ) . '</dd></div>' .
				'<div><dt>' . esc_html__( 'Average asking rent', 'axis-cre' ) . '</dt><dd>' . esc_html( Format::rent( $sector['rent'], $sector['unit'] ) ) . '</dd></div>' .
				'<div><dt>' . esc_html__( 'Vacancy, year on year', 'axis-cre' ) . '</dt><dd>' . esc_html( Format::change( $sector['change'] ) ) . '</dd></div>' .
				'</dl><p class="axis-cre-muted">' . esc_html( trim( $sector['name'] . '. ' . $m['quarter'] ) ) . ' <a href="' . esc_url( $m['url'] ) . '">' . esc_html(
					/* translators: %s: market name. */
					sprintf( __( 'More on %s', 'axis-cre' ), $m['title'] )
				) . '</a></p>';
		}

		$out  = '<div class="axis-cre-sectors">';
		$out .= '<div class="axis-cre-sectors__market"><p class="is-style-technical-label">' . esc_html( $m['label'] ) . '</p><p class="axis-cre-sectors__name">' . esc_html( $m['title'] ) . '</p><p class="axis-cre-muted">' . esc_html( trim( implode( '. ', array_filter( array( $m['country'], $m['quarter'] ) ) ) ) ) . '</p></div>';
		foreach ( $m['sectors'] as $s ) {
			$out .= '<div class="axis-cre-sector axis-metric"><p>' . Render::asset_class( $s['slug'], $s['name'] ) . '</p><dl class="axis-cre-rows">';
			$out .= '<div><dt>' . esc_html__( 'Average asking rent', 'axis-cre' ) . '</dt><dd>' . esc_html( Format::rent( $s['rent'], $s['unit'] ) ) . '</dd></div>';
			$out .= '<div><dt>' . esc_html__( 'Vacancy', 'axis-cre' ) . '</dt><dd>' . esc_html( Format::percent( $s['vacancy'] ) ) . '</dd></div>';
			$out .= '<div><dt>' . esc_html__( 'Vacancy, year on year', 'axis-cre' ) . '</dt><dd>' . esc_html( Format::change( $s['change'] ) ) . '</dd></div>';
			$out .= '</dl></div>';
		}
		$out .= '</div>';

		$charts = '';
		if ( $m['submarkets'] ) {
			$office = __( 'Vacancy by submarket', 'axis-cre' );
			$rows   = array_map(
				function ( $s ) {
					return array( $s['name'], $s['vacancy'] );
				},
				$m['submarkets']
			);
			/* translators: %s: data period, for example Q2 2026. */
			$charts .= Charts::bars( $office, trim( sprintf( __( '%s, percent of inventory', 'axis-cre' ), $m['quarter'] ), ', ' ), $rows, '%' );
		}
		if ( count( $m['trend'] ) > 1 ) {
			$title = $m['trend_name'] ? $m['trend_name'] : __( 'Average asking rent', 'axis-cre' );
			/* translators: %s: area unit, for example sf. */
			$charts .= Charts::trend( $title, sprintf( __( 'Per %s, by period', 'axis-cre' ), Format::area_unit() ), $m['trend'], Format::settings()['currency'] );
		}
		if ( $charts ) {
			$out .= '<div class="axis-cre-charts">' . $charts . '</div>';
		}
		return $out;
	}

	/**
	 * All markets compared in one table.
	 *
	 * @return string
	 */
	private static function market_table() {
		$markets = Repository::markets();
		if ( ! $markets ) {
			return '';
		}
		$out  = '<section class="axis-cre-table-wrap" tabindex="0" aria-label="' . esc_attr__( 'Markets compared', 'axis-cre' ) . '"><table class="axis-cre-table"><caption class="screen-reader-text">' . esc_html__( 'Markets compared', 'axis-cre' ) . '</caption><thead><tr>';
		$out .= '<th scope="col">' . esc_html__( 'Market', 'axis-cre' ) . '</th><th scope="col">' . esc_html__( 'Country', 'axis-cre' ) . '</th><th scope="col" class="num">' . esc_html__( 'Available assets', 'axis-cre' ) . '</th><th scope="col" class="num">' . esc_html__( 'Office vacancy', 'axis-cre' ) . '</th><th scope="col" class="num">' . esc_html__( 'Office asking rent', 'axis-cre' ) . '</th><th scope="col" class="num">' . esc_html__( 'Experts', 'axis-cre' ) . '</th></tr></thead><tbody>';
		foreach ( $markets as $m ) {
			$office = $m['sectors'] ? $m['sectors'][0] : null;
			foreach ( $m['sectors'] as $s ) {
				if ( 'office' === $s['slug'] ) {
					$office = $s;
				}
			}
			$out .= '<tr><th scope="row"><a href="' . esc_url( $m['url'] ) . '">' . esc_html( $m['title'] ) . '</a></th><td>' . esc_html( $m['country'] ) . '</td>';
			$out .= '<td class="num">' . esc_html( number_format_i18n( Repository::count_in_market( Post_Types::PROPERTY, $m['id'] ) ) ) . '</td>';
			$out .= '<td class="num">' . esc_html( $office ? Format::percent( $office['vacancy'] ) : '' ) . '</td>';
			$out .= '<td class="num">' . esc_html( $office ? Format::rent( $office['rent'], $office['unit'] ) : '' ) . '</td>';
			$out .= '<td class="num">' . esc_html( number_format_i18n( Repository::count_in_market( Post_Types::EXPERT, $m['id'], 'markets' ) ) ) . '</td></tr>';
		}
		return $out . '</tbody></table></section>';
	}

	/**
	 * Survey map for a market, a property, or all markets.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function render_market_map( $a, $post_id ) {
		$mode   = self::attr( $a, 'mode', 'market' );
		$points = array();

		if ( 'all' === $mode ) {
			foreach ( Repository::markets() as $m ) {
				$n        = Repository::count_in_market( Post_Types::PROPERTY, $m['id'] );
				$points[] = array(
					'id'   => $m['id'],
					'lat'  => $m['lat'],
					'lng'  => $m['lng'],
					'kind' => 'market',
					'text' => (string) $n,
					'name' => $m['title'],
					'url'  => $m['url'],
					/* translators: %s: number of assets. */
					'meta' => sprintf( _n( '%s asset', '%s assets', $n, 'axis-cre' ), number_format_i18n( $n ) ),
				);
			}
			return Map::static_map( $points, __( 'Map of markets. The same markets are listed beside it.', 'axis-cre' ), __( 'Markets', 'axis-cre' ), 2 );
		}

		$m = Repository::market_for( $post_id );
		if ( 'property' === $mode ) {
			$self = Repository::property( $post_id );
			if ( ! $self ) {
				return '';
			}
			$near = $self['market'] ? Repository::properties(
				array(
					'market'   => $self['market'],
					'per_page' => 8,
					'exclude'  => array( $post_id ),
				)
			)['items'] : array();
			foreach ( array_merge( array( $self ), $near ) as $p ) {
				$points[] = array(
					'id'       => $p['id'],
					'lat'      => $p['lat'],
					'lng'      => $p['lng'],
					'text'     => $p['price'] ? Format::money( $p['price'] ) : $p['label'],
					'name'     => $p['title'],
					'url'      => $p['id'] === $post_id ? '' : $p['url'],
					'selected' => $p['id'] === $post_id,
					'meta'     => $p['class_line'],
				);
			}
			return Map::static_map( $points, __( 'Map of this property and nearby assets. They are listed beside it.', 'axis-cre' ), __( 'On the map', 'axis-cre' ) );
		}

		if ( ! $m ) {
			return '';
		}
		foreach ( $m['submarkets'] as $s ) {
			$points[] = array(
				'id'   => 0,
				'lat'  => $s['lat'],
				'lng'  => $s['lng'],
				'kind' => 'submarket',
				'text' => $s['name'],
				'name' => $s['name'],
				/* translators: %s: vacancy percent. */
				'meta' => null !== $s['vacancy'] ? sprintf( __( '%s vacancy', 'axis-cre' ), Format::percent( $s['vacancy'] ) ) : '',
			);
		}
		foreach ( Repository::properties(
			array(
				'market'   => $m['id'],
				'per_page' => 50,
			)
		)['items'] as $p ) {
			$points[] = array(
				'id'   => $p['id'],
				'lat'  => $p['lat'],
				'lng'  => $p['lng'],
				'text' => $p['price'] ? Format::money( $p['price'] ) : $p['label'],
				'name' => $p['title'],
				'url'  => $p['url'],
				'meta' => $p['class_line'],
			);
		}
		/* translators: %s: market name. */
		return Map::static_map( $points, sprintf( __( 'Map of %s. Submarkets and assets are listed beside it.', 'axis-cre' ), $m['title'] ), __( 'Submarkets and assets', 'axis-cre' ) );
	}

	/**
	 * Market explorer: filters, survey map and results kept in sync.
	 * Works as a plain form without JavaScript; enhanced with the Interactivity API.
	 *
	 * @param array<string, mixed> $a Attributes.
	 * @return string
	 */
	private static function render_market_explorer( $a ) {
		$per     = (int) self::attr( $a, 'perPage', 12 );
		$filters = self::property_filters();
		$all     = Repository::properties( array( 'per_page' => 300 ) )['items'];

		// Server-side match, used for the first paint and when JavaScript is off.
		$q       = strtolower( (string) $filters['q'] );
		$matches = function ( $p ) use ( $filters, $q ) {
			if ( '' !== $q && false === strpos( $p['search'], $q ) ) {
				return false;
			}
			if ( $filters['type'] && $p['type'] !== $filters['type'] ) {
				return false;
			}
			if ( $filters['market'] && (int) $p['market'] !== (int) $filters['market'] ) {
				return false;
			}
			if ( $filters['listing'] && $p['status_slug'] !== $filters['listing'] ) {
				return false;
			}
			$ranges = array(
				'min_size'  => array( 'size', 1 ),
				'max_size'  => array( 'size', -1 ),
				'min_price' => array( 'price', 1 ),
				'max_price' => array( 'price', -1 ),
				'min_cap'   => array( 'cap', 1 ),
				'min_rent'  => array( 'lease', 1 ),
				'max_rent'  => array( 'lease', -1 ),
			);
			foreach ( $ranges as $key => $spec ) {
				if ( '' === $filters[ $key ] ) {
					continue;
				}
				$v = $p[ $spec[0] ];
				if ( null === $v || ( 1 === $spec[1] ? $v < $filters[ $key ] : $v > $filters[ $key ] ) ) {
					return false;
				}
			}
			return true;
		};
		$matched = array_values( array_filter( $all, $matches ) );
		$visible = array_map( 'intval', wp_list_pluck( $matched, 'id' ) );

		// Markets that hold assets become clusters when results span several markets.
		$counts = array_count_values( array_map( 'intval', wp_list_pluck( $matched, 'market' ) ) );
		$mlist  = array();
		foreach ( Repository::markets() as $m ) {
			if ( null !== $m['lat'] && in_array( $m['id'], array_map( 'intval', wp_list_pluck( $all, 'market' ) ), true ) ) {
				$mlist[] = array(
					'id'    => $m['id'],
					'lat'   => $m['lat'],
					'lng'   => $m['lng'],
					'title' => $m['title'],
				);
			}
		}
		$assets_mode = ! $mlist || ( $matched && 1 === count( $counts ) );
		if ( $assets_mode ) {
			$proj = Map::project( $matched ? $matched : $all );
		} else {
			$proj = Map::project( $mlist );
		}
		$bounds = $proj['bounds'];
		$shown  = array_slice( $visible, 0, $per );

		$items = array();
		foreach ( $all as $p ) {
			$items[] = array(
				'id'      => $p['id'],
				'type'    => $p['type'],
				'market'  => (int) $p['market'],
				'listing' => $p['status_slug'],
				'size'    => $p['size'],
				'price'   => $p['price'],
				'cap'     => $p['cap'],
				'lease'   => $p['lease'],
				'search'  => $p['search'],
				'lat'     => $p['lat'],
				'lng'     => $p['lng'],
			);
		}
		/* translators: %d: number of assets. */
		$one = __( '%d asset', 'axis-cre' );
		/* translators: %d: number of assets. */
		$many = __( '%d assets', 'axis-cre' );
		$n    = count( $visible );

		wp_interactivity_state(
			'axis-cre/explorer',
			array(
				'items'      => $items,
				'markets'    => array_map(
					function ( $m ) {
						return array(
							'id'  => $m['id'],
							'lat' => $m['lat'],
							'lng' => $m['lng'],
						);
					},
					$mlist
				),
				'filters'    => array_map( 'strval', $filters ),
				'limit'      => $per,
				'pageSize'   => $per,
				'selected'   => 0,
				'followMap'  => true,
				'vb'         => array( 0, 0, Map::W, Map::H ),
				'vb0'        => array( 0, 0, Map::W, Map::H ),
				'i18n'       => array(
					'one'   => $one,
					'many'  => $many,
					'north' => _x( 'N', 'north', 'axis-cre' ),
					'south' => _x( 'S', 'south', 'axis-cre' ),
					'east'  => _x( 'E', 'east', 'axis-cre' ),
					'west'  => _x( 'W', 'west', 'axis-cre' ),
				),
				'countText'  => sprintf( 1 === $n ? $one : $many, $n ),
				'isEmpty'    => 0 === $n,
				'hasMore'    => $n > $per,
				'isListOnly' => false,
				'enhanced'   => false,
				'isSelected' => false,
				'isHidden'   => function () use ( $shown ) {
					$c = wp_interactivity_get_context();
					return ! in_array( (int) $c['pid'], $shown, true );
				},
			)
		);

		$out  = '<div class="axis-cre-explorer" data-wp-interactive="axis-cre/explorer" data-wp-init="callbacks.init" data-wp-class--is-enhanced="state.enhanced" data-wp-class--is-list-only="state.isListOnly">';
		$form = Render::filter_form( self::property_fields(), __( 'Show results', 'axis-cre' ), 'row' );
		// Live filtering on change; the submit button stays for keyboard and no-JS use.
		$form = str_replace( '<form ', '<form data-wp-on--change="actions.setFilter" data-wp-on--submit="actions.submit" ', $form );
		$out .= $form;

		$out .= '<div class="axis-cre-explorer__bar"><h2 class="axis-cre-explorer__count" aria-live="polite" data-wp-text="state.countText">' . esc_html( sprintf( 1 === $n ? $one : $many, $n ) ) . '</h2>';
		$out .= '<div class="axis-cre-explorer__tools"><label class="axis-cre-check"><input type="checkbox" checked data-wp-on--change="actions.toggleFollow"> ' . esc_html__( 'Update results as the map moves', 'axis-cre' ) . '</label>';
		$out .= '<div class="axis-cre-toggle" role="group" aria-label="' . esc_attr__( 'View', 'axis-cre' ) . '"><button type="button" aria-pressed="true" data-wp-bind--aria-pressed="!state.isListOnly" data-wp-on--click="actions.showMap">' . esc_html__( 'Map and list', 'axis-cre' ) . '</button><button type="button" aria-pressed="false" data-wp-bind--aria-pressed="state.isListOnly" data-wp-on--click="actions.showList">' . esc_html__( 'List only', 'axis-cre' ) . '</button></div></div></div>';

		$out .= '<div class="axis-cre-explorer__body"><div class="axis-cre-explorer__results">';
		$out .= '<ul class="axis-cre-explorer__list" aria-label="' . esc_attr__( 'Assets', 'axis-cre' ) . '">';
		foreach ( $all as $p ) {
			$card = Render::asset_card(
				$p,
				'compact',
				array(
					'id' => 'axis-card-' . $p['id'],
				)
			);
			$out .= '<li class="' . ( in_array( $p['id'], $shown, true ) ? '' : 'is-hidden' ) . '" data-wp-context="' . esc_attr( wp_json_encode( array( 'pid' => $p['id'] ) ) ) . '" data-wp-class--is-hidden="state.isHidden" data-wp-class--is-selected="state.isSelected" data-wp-on--mouseenter="actions.selectCard" data-wp-on--focusin="actions.selectCard">' . $card . '</li>';
		}
		$out .= '</ul>';
		$out .= '<div class="axis-cre-explorer__empty' . ( $n ? ' is-hidden' : '' ) . '" data-wp-class--is-hidden="!state.isEmpty">' . Render::empty_state( __( 'No assets match these filters', 'axis-cre' ), __( 'Try a wider size or price range, include more property types, or move the map.', 'axis-cre' ), remove_query_arg( array_merge( array_keys( $filters ), array( 'axis_page' ) ) ), __( 'Clear filters', 'axis-cre' ) ) . '</div>';
		$out .= '<p class="axis-cre-explorer__more' . ( $n > $per ? '' : ' is-hidden' ) . '" data-wp-class--is-hidden="!state.hasMore"><button type="button" class="axis-cre-button is-secondary" data-wp-on--click="actions.loadMore">' . esc_html__( 'Show more assets', 'axis-cre' ) . '</button></p>';
		$out .= '</div>';

		if ( $bounds ) {
			$pins = array();
			foreach ( $mlist as $m ) {
				$xy     = Map::place( $bounds, $m['lat'], $m['lng'] );
				$count  = isset( $counts[ $m['id'] ] ) ? $counts[ $m['id'] ] : 0;
				$pins[] = array(
					'mid'    => $m['id'],
					'x'      => $xy[0],
					'y'      => $xy[1],
					'text'   => (string) $count,
					'name'   => $m['title'],
					'url'    => add_query_arg( 'market', $m['id'], remove_query_arg( 'axis_page' ) ),
					'hidden' => $assets_mode || ! $count,
				);
			}
			foreach ( $all as $p ) {
				if ( null === $p['lat'] || null === $p['lng'] ) {
					continue;
				}
				$xy     = Map::place( $bounds, $p['lat'], $p['lng'] );
				$pins[] = array(
					'pid'    => $p['id'],
					'x'      => $xy[0],
					'y'      => $xy[1],
					'text'   => $p['price'] ? Format::money( $p['price'] ) : $p['label'],
					'name'   => $p['title'],
					'hidden' => ! $assets_mode || ! in_array( $p['id'], $visible, true ),
				);
			}
			$out .= '<div class="axis-cre-explorer__map"><div class="axis-cre-map__frame" data-wp-watch="callbacks.applyViewBox" data-wp-on--click="actions.mapClick" data-wp-on--pointerdown="actions.dragStart" data-wp-on--pointermove="actions.dragMove" data-wp-on--pointerup="actions.dragEnd" data-wp-on--pointercancel="actions.dragEnd" data-wp-on--wheel="actions.wheel" tabindex="0" aria-label="' . esc_attr__( 'Map. Use arrow keys to move and plus or minus to zoom.', 'axis-cre' ) . '" data-wp-on--keydown="actions.mapKey">';
			$out .= Map::explorer_svg( $pins, $bounds, __( 'Survey map of assets. Market pins narrow the results to that market; asset pins select their card in the list.', 'axis-cre' ) );
			$out .= '</div><div class="axis-cre-map__controls"><button type="button" class="axis-cre-button is-secondary" data-wp-on--click="actions.zoomIn">' . esc_html__( 'Zoom in', 'axis-cre' ) . '</button><button type="button" class="axis-cre-button is-secondary" data-wp-on--click="actions.zoomOut">' . esc_html__( 'Zoom out', 'axis-cre' ) . '</button><button type="button" class="axis-cre-button is-secondary" data-wp-on--click="actions.resetMap">' . esc_html__( 'Reset map', 'axis-cre' ) . '</button></div>';
			$out .= '<p class="axis-cre-map__note">' . esc_html__( 'Survey map: positions are to scale; streets are not shown.', 'axis-cre' ) . '</p></div>';
		} else {
			$out .= '<p class="axis-cre-map__note">' . esc_html__( 'The map appears once properties have coordinates. Results are listed instead.', 'axis-cre' ) . '</p>';
		}
		$out .= '</div></div>';

		return $out;
	}

	// ------------------------------------------------------------------ transactions, experts, research

	/**
	 * Transaction story, list or archive.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function render_transaction_data( $a, $post_id ) {
		$mode = self::attr( $a, 'mode', 'list' );
		$per  = (int) self::attr( $a, 'perPage', 3 );
		$type = get_post_type( $post_id );

		if ( 'single' === $mode ) {
			$t = Repository::transaction( $post_id );
			if ( ! $t ) {
				return '';
			}
			$out = '';
			if ( $t['story'] ) {
				$out .= '<div class="axis-cre-story">';
				foreach ( $t['story'] as $label => $text ) {
					$out .= '<section class="axis-metric"><h2 class="axis-cre-story__title">' . esc_html( $label ) . '</h2><p>' . esc_html( $text ) . '</p></section>';
				}
				$out .= '</div>';
			}
			$facts = array_filter(
				array(
					__( 'Client', 'axis-cre' )   => esc_html( $t['client'] ),
					__( 'Our role', 'axis-cre' ) => esc_html( $t['role'] ),
					__( 'Asset', 'axis-cre' )    => $t['property'] && get_post( $t['property'] ) ? '<a href="' . esc_url( get_permalink( $t['property'] ) ) . '">' . esc_html( get_the_title( $t['property'] ) ) . '</a>' : '',
					__( 'Market', 'axis-cre' )   => $t['market'] && get_post( $t['market'] ) ? '<a href="' . esc_url( get_permalink( $t['market'] ) ) . '">' . esc_html( get_the_title( $t['market'] ) ) . '</a>' : '',
				)
			);
			$team  = array_filter( array_map( array( 'Axis_CRE\Repository', 'expert' ), $t['experts'] ) );
			if ( $team ) {
				$facts[ __( 'Team', 'axis-cre' ) ] = implode(
					', ',
					array_map(
						function ( $e ) {
							return '<a href="' . esc_url( $e['url'] ) . '">' . esc_html( $e['title'] ) . '</a>';
						},
						$team
					)
				);
			}
			if ( $facts ) {
				$out .= '<dl class="axis-cre-rows is-wide">';
				foreach ( $facts as $k => $v ) {
					$out .= '<div><dt>' . esc_html( $k ) . '</dt><dd>' . $v . '</dd></div>'; // Escaped above.
				}
				$out .= '</dl>';
			}
			return $out;
		}

		$args = array( 'per_page' => $per );
		if ( Post_Types::EXPERT === $type || 'expert' === self::attr( $a, 'scope', 'all' ) ) {
			$args['expert'] = Post_Types::EXPERT === $type ? $post_id : 0;
		}
		if ( Post_Types::MARKET === $type ) {
			$args['market'] = $post_id;
		}
		if ( Post_Types::TRANSACTION === $type ) {
			$args['exclude'] = array( $post_id );
			$self            = Repository::transaction( $post_id );
			if ( $self && $self['type'] ) {
				$args['type'] = $self['type'];
			}
		}

		$out = '';
		if ( 'archive' === $mode ) {
			$page           = max( 1, (int) Render::query_var( 'axis_page', 'int' ) );
			$args['page']   = $page;
			$args['year']   = Render::query_var( 'in_year', 'int' );
			$args['deal']   = Render::query_var( 'deal' );
			$args['type']   = Render::query_var( 'type' );
			$args['market'] = Render::query_var( 'market', 'int' );
			$year_now       = (int) gmdate( 'Y' );
			$this_year      = Repository::transactions(
				array(
					'year'     => $year_now,
					'per_page' => 500,
				)
			);
			$all            = Repository::transactions( array( 'per_page' => 500 ) );
			$markets        = count( array_unique( array_filter( wp_list_pluck( $all['items'], 'market' ) ) ) );
			$years          = array_unique( array_filter( array_map( 'intval', wp_list_pluck( $all['items'], 'year' ) ) ) );
			rsort( $years );
			$out .= Render::figures(
				array(
					array(
						'value' => Format::money( array_sum( array_map( 'floatval', wp_list_pluck( $this_year['items'], 'value' ) ) ) ),
						/* translators: %d: year. */
						'label' => sprintf( __( 'Volume in %d', 'axis-cre' ), $year_now ),
					),
					array(
						'value' => number_format_i18n( $all['total'] ),
						'label' => __( 'Transactions', 'axis-cre' ),
					),
					array(
						'value' => number_format_i18n( $markets ),
						'label' => __( 'Markets', 'axis-cre' ),
					),
				)
			);
			$out .= Render::filter_form(
				array(
					array(
						'name'    => 'in_year',
						'label'   => __( 'Year', 'axis-cre' ),
						'type'    => 'select',
						'options' => array( '' => __( 'All years', 'axis-cre' ) ) + array_combine( $years, $years ),
					),
					array(
						'name'    => 'deal',
						'label'   => __( 'Deal type', 'axis-cre' ),
						'type'    => 'select',
						'options' => Render::term_options( 'axis_transaction_type', __( 'All deal types', 'axis-cre' ) ),
					),
					array(
						'name'    => 'type',
						'label'   => __( 'Property type', 'axis-cre' ),
						'type'    => 'select',
						'options' => Render::term_options( 'axis_property_type', __( 'All types', 'axis-cre' ) ),
					),
					array(
						'name'    => 'market',
						'label'   => __( 'Market', 'axis-cre' ),
						'type'    => 'select',
						'options' => Render::market_options( __( 'All markets', 'axis-cre' ) ),
					),
				),
				__( 'Show transactions', 'axis-cre' )
			);
		}

		$res = Repository::transactions( $args );
		if ( ! $res['items'] && 'list' === $mode && Post_Types::TRANSACTION === $type && ! empty( $args['type'] ) ) {
			// Nothing of the same property type yet: show the latest transactions instead.
			unset( $args['type'] );
			$res = Repository::transactions( $args );
		}
		if ( ! $res['items'] ) {
			return 'archive' === $mode ? $out . Render::empty_state( __( 'No transactions match these filters', 'axis-cre' ), __( 'Try another year or deal type.', 'axis-cre' ), remove_query_arg( array( 'in_year', 'deal', 'type', 'market', 'axis_page' ) ), __( 'Clear filters', 'axis-cre' ) ) : '';
		}
		if ( 'archive' === $mode ) {
			$out .= '<h2 class="screen-reader-text">' . esc_html__( 'Transactions', 'axis-cre' ) . '</h2>';
		}
		$out .= Render::grid( array_map( array( 'Axis_CRE\Render', 'transaction_card' ), $res['items'] ), __( 'Transactions', 'axis-cre' ) );
		if ( 'archive' === $mode ) {
			$out .= Render::pagination( $args['page'], $res['pages'] );
		}
		return $out;
	}

	/**
	 * Expert profile, cards, listing contact or directory.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function render_expert_profile( $a, $post_id ) {
		$mode = self::attr( $a, 'mode', 'cards' );
		$per  = (int) self::attr( $a, 'perPage', 4 );
		$type = get_post_type( $post_id );

		if ( 'profile' === $mode ) {
			$e = Repository::expert( $post_id );
			if ( ! $e ) {
				return '';
			}
			$first = strtok( $e['title'], ' ' );
			$rows  = array_filter(
				array(
					__( 'Markets', 'axis-cre' )        => esc_html( implode( ', ', wp_list_pluck( $e['markets'], 'title' ) ) ),
					__( 'Property types', 'axis-cre' ) => esc_html( implode( ', ', $e['types'] ) ),
					__( 'Specialties', 'axis-cre' )    => esc_html( implode( ', ', $e['specialties'] ) ),
					__( 'Phone', 'axis-cre' )          => $e['phone'] ? '<a href="' . esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $e['phone'] ), array( 'tel' ) ) . '">' . esc_html( str_replace( ' ', "\u{00A0}", $e['phone'] ) ) . '</a>' : '',
					__( 'Email', 'axis-cre' )          => $e['email'] ? '<a href="' . esc_url( 'mailto:' . antispambot( $e['email'] ), array( 'mailto' ) ) . '">' . esc_html( antispambot( $e['email'] ) ) . '</a>' : '',
					__( 'LinkedIn', 'axis-cre' )       => $e['linkedin'] ? '<a href="' . esc_url( $e['linkedin'] ) . '">' . esc_html__( 'Profile on LinkedIn', 'axis-cre' ) . '</a>' : '',
				)
			);
			$face  = $e['image'] ? Render::image( $e['image'], 'large' ) : '<span class="axis-cre-profile__initials" aria-hidden="true">' . esc_html( Render::initials( $e['title'] ) ) . '</span>';
			$out   = '<div class="axis-cre-profile"><div class="axis-cre-profile__photo' . ( $e['image'] ? '' : ' is-initials' ) . '">' . $face . '</div><div class="axis-cre-profile__details">';
			$out  .= '<p class="is-style-technical-label">' . esc_html( $e['label'] ) . '</p><h1 class="axis-cre-profile__name">' . esc_html( $e['title'] ) . '</h1><p class="axis-cre-profile__role">' . esc_html( $e['role_line'] ) . '</p>';
			if ( $rows ) {
				$out .= '<dl class="axis-cre-rows">';
				foreach ( $rows as $k => $v ) {
					$out .= '<div><dt>' . esc_html( $k ) . '</dt><dd>' . $v . '</dd></div>'; // Escaped above.
				}
				$out .= '</dl>';
			}
			$out .= '<p class="axis-cre-actions">';
			if ( $e['email'] ) {
				/* translators: %s: first name. */
				$out .= '<a class="wp-element-button axis-cre-button" href="' . esc_url( 'mailto:' . antispambot( $e['email'] ), array( 'mailto' ) ) . '">' . esc_html( sprintf( __( 'Contact %s', 'axis-cre' ), $first ) ) . '</a>';
			}
			$out     .= '<a class="axis-cre-button is-secondary" href="' . esc_url( rest_url( 'axis-cre/v1/experts/' . $post_id . '/vcard' ) ) . '" download>' . esc_html__( 'Download contact card', 'axis-cre' ) . '</a></p>';
			$out     .= '</div></div>';
			$research = Repository::research_items(
				array(
					'expert'   => $post_id,
					'per_page' => 1,
				)
			)['total'];
			$out     .= Render::figures(
				array(
					array(
						'value' => $e['deals'] ? number_format_i18n( $e['deals'] ) : '',
						'label' => __( 'Transactions', 'axis-cre' ),
					),
					array(
						'value' => $e['volume'] ? Format::money( $e['volume'] ) : '',
						'label' => __( 'Volume', 'axis-cre' ),
					),
					array(
						'value' => $e['since'] ? number_format_i18n( max( 1, (int) gmdate( 'Y' ) - $e['since'] ) ) : '',
						'label' => __( 'Years with the firm', 'axis-cre' ),
					),
					array(
						'value' => $research ? number_format_i18n( $research ) : '',
						'label' => __( 'Research pieces', 'axis-cre' ),
					),
				)
			);
			return $out;
		}

		if ( 'contact' === $mode ) {
			$ids = array_map( 'intval', (array) Fields::get( $post_id, 'experts' ) );
			$e   = $ids ? Repository::expert( $ids[0] ) : null;
			if ( ! $e ) {
				return '<p class="is-style-technical-label">' . esc_html__( 'Listing team', 'axis-cre' ) . '</p><p>' . esc_html__( 'Ask the team about this property and its documents.', 'axis-cre' ) . '</p><p><a class="wp-element-button axis-cre-button" href="' . esc_url( home_url( '/contact/' ) ) . '">' . esc_html__( 'Contact the team', 'axis-cre' ) . '</a></p>';
			}
			$first = strtok( $e['title'], ' ' );
			/* translators: %s: property name. */
			$subject = sprintf( __( 'Enquiry: %s', 'axis-cre' ), get_the_title( $post_id ) );
			$out     = '<p class="is-style-technical-label">' . esc_html__( 'Listing broker', 'axis-cre' ) . '</p><h2 class="axis-cre-contact__name"><a href="' . esc_url( $e['url'] ) . '">' . esc_html( $e['title'] ) . '</a></h2><p class="axis-cre-muted">' . esc_html( $e['role_line'] ) . '</p><dl class="axis-cre-rows">';
			if ( $e['phone'] ) {
				$out .= '<div><dt>' . esc_html__( 'Phone', 'axis-cre' ) . '</dt><dd><a href="' . esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $e['phone'] ), array( 'tel' ) ) . '">' . esc_html( str_replace( ' ', "\u{00A0}", $e['phone'] ) ) . '</a></dd></div>';
			}
			if ( $e['email'] ) {
				$out .= '<div><dt>' . esc_html__( 'Email', 'axis-cre' ) . '</dt><dd><a href="' . esc_url( 'mailto:' . antispambot( $e['email'] ), array( 'mailto' ) ) . '">' . esc_html( antispambot( $e['email'] ) ) . '</a></dd></div>';
			}
			$out .= '</dl>';
			if ( $e['email'] ) {
				/* translators: %s: first name. */
				$out .= '<p><a class="wp-element-button axis-cre-button" href="' . esc_url( 'mailto:' . antispambot( $e['email'] ) . '?subject=' . rawurlencode( $subject ), array( 'mailto' ) ) . '">' . esc_html( sprintf( __( 'Contact %s', 'axis-cre' ), $first ) ) . '</a></p>';
			}
			return $out . '<p class="axis-cre-muted">' . esc_html__( 'Usually replies within one working day.', 'axis-cre' ) . '</p>';
		}

		$args = array( 'per_page' => $per );
		if ( Post_Types::MARKET === $type ) {
			$args['market'] = $post_id;
		}
		if ( Post_Types::PROPERTY === $type ) {
			$args['ids'] = array_map( 'intval', (array) Fields::get( $post_id, 'experts' ) );
		}
		$out = '';
		if ( 'directory' === $mode ) {
			$args['page']    = max( 1, (int) Render::query_var( 'axis_page', 'int' ) );
			$args['market']  = Render::query_var( 'market', 'int' );
			$args['service'] = Render::query_var( 'service' );
			$args['type']    = Render::query_var( 'type' );
			$out            .= Render::filter_form(
				array(
					array(
						'name'    => 'market',
						'label'   => __( 'Market', 'axis-cre' ),
						'type'    => 'select',
						'options' => Render::market_options( __( 'All markets', 'axis-cre' ) ),
					),
					array(
						'name'    => 'service',
						'label'   => __( 'Specialty', 'axis-cre' ),
						'type'    => 'select',
						'options' => Render::term_options( 'axis_service', __( 'All specialties', 'axis-cre' ) ),
					),
					array(
						'name'    => 'type',
						'label'   => __( 'Property type', 'axis-cre' ),
						'type'    => 'select',
						'options' => Render::term_options( 'axis_property_type', __( 'All types', 'axis-cre' ) ),
					),
				),
				__( 'Show experts', 'axis-cre' )
			);
		}
		$res = Repository::experts( $args );
		if ( ! $res['items'] ) {
			return 'directory' === $mode ? $out . Render::empty_state( __( 'No experts match these filters', 'axis-cre' ), __( 'Try another market or specialty.', 'axis-cre' ), remove_query_arg( array( 'market', 'service', 'type', 'axis_page' ) ), __( 'Clear filters', 'axis-cre' ) ) : '';
		}
		if ( 'directory' === $mode ) {
			/* translators: 1: experts shown, 2: total experts. */
			$out .= '<p class="axis-cre-muted" role="status">' . esc_html( sprintf( __( 'Showing %1$d of %2$d', 'axis-cre' ), count( $res['items'] ), $res['total'] ) ) . '</p>';
		}
		if ( 'directory' === $mode ) {
			$out .= '<h2 class="screen-reader-text">' . esc_html__( 'Experts', 'axis-cre' ) . '</h2>';
		}
		$out .= Render::grid( array_map( array( 'Axis_CRE\Render', 'expert_card' ), $res['items'] ), __( 'Experts', 'axis-cre' ), 'is-people' );
		if ( 'directory' === $mode ) {
			$out .= Render::pagination( $args['page'], $res['pages'] );
		}
		return $out;
	}

	/**
	 * Research report details, cards, or archive.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Current post.
	 * @return string
	 */
	private static function render_research_index( $a, $post_id ) {
		$mode = self::attr( $a, 'mode', 'list' );
		$per  = (int) self::attr( $a, 'perPage', 3 );
		$type = get_post_type( $post_id );

		if ( 'single' === $mode ) {
			$r = Repository::research( $post_id );
			if ( ! $r ) {
				return '';
			}
			$out  = Render::figures( $r['figures'] );
			$acts = '';
			if ( $r['pdf'] ) {
				$acts .= '<a class="wp-element-button axis-cre-button" href="' . esc_url( wp_get_attachment_url( $r['pdf'] ) ) . '" download>' . esc_html__( 'Download report', 'axis-cre' ) . '</a>';
			}
			if ( $r['data'] ) {
				$acts .= '<a class="axis-cre-button is-secondary" href="' . esc_url( wp_get_attachment_url( $r['data'] ) ) . '" download>' . esc_html__( 'Get the data as CSV', 'axis-cre' ) . '</a>';
			}
			$out .= $acts ? '<p class="axis-cre-actions">' . $acts . '</p>' : '';
			if ( $r['markets'] ) {
				$out .= '<p class="axis-cre-muted">' . esc_html__( 'Markets covered:', 'axis-cre' ) . ' ' . implode(
					', ',
					array_map(
						function ( $m ) {
							return '<a href="' . esc_url( $m['url'] ) . '">' . esc_html( $m['title'] ) . '</a>';
						},
						$r['markets']
					)
				) . '</p>';
			}
			return $out;
		}

		$args = array( 'per_page' => $per );
		if ( Post_Types::EXPERT === $type ) {
			$args['expert'] = $post_id;
		}
		if ( Post_Types::MARKET === $type ) {
			$args['market'] = $post_id;
		}
		if ( Post_Types::RESEARCH === $type ) {
			$args['exclude'] = array( $post_id );
		}

		$out = '';
		if ( 'archive' === $mode ) {
			$args['page']   = max( 1, (int) Render::query_var( 'axis_page', 'int' ) );
			$args['type']   = Render::query_var( 'rtype' );
			$args['market'] = Render::query_var( 'market', 'int' );
			$args['year']   = Render::query_var( 'in_year', 'int' );
			$terms          = get_terms(
				array(
					'taxonomy'   => 'axis_research_type',
					'hide_empty' => true,
				)
			);
			$out           .= '<nav class="axis-cre-typetabs" aria-label="' . esc_attr__( 'Research types', 'axis-cre' ) . '"><ul>';
			$all_total      = Repository::research_items( array( 'per_page' => 1 ) )['total'];
			$out           .= '<li><a href="' . esc_url( remove_query_arg( array( 'rtype', 'axis_page' ) ) ) . '"' . ( $args['type'] ? '' : ' aria-current="page"' ) . '>' . esc_html__( 'All', 'axis-cre' ) . ' <span>' . esc_html( number_format_i18n( $all_total ) ) . '</span></a></li>';
			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $t ) {
					$out .= '<li><a href="' . esc_url( add_query_arg( 'rtype', $t->slug, remove_query_arg( 'axis_page' ) ) ) . '"' . ( $args['type'] === $t->slug ? ' aria-current="page"' : '' ) . '>' . esc_html( $t->name ) . ' <span>' . esc_html( number_format_i18n( $t->count ) ) . '</span></a></li>';
				}
			}
			$out .= '</ul></nav>';
			$out .= Render::filter_form(
				array(
					array(
						'name'    => 'market',
						'label'   => __( 'Market', 'axis-cre' ),
						'type'    => 'select',
						'options' => Render::market_options( __( 'All markets', 'axis-cre' ) ),
					),
					array(
						'name'        => 'in_year',
						'label'       => __( 'Year', 'axis-cre' ),
						'type'        => 'number',
						'placeholder' => __( 'Any', 'axis-cre' ),
					),
				),
				__( 'Show research', 'axis-cre' )
			);
		}

		$res = Repository::research_items( $args );
		if ( ! $res['items'] ) {
			return 'archive' === $mode ? $out . Render::empty_state( __( 'No research matches these filters', 'axis-cre' ), __( 'Try another market or year.', 'axis-cre' ), remove_query_arg( array( 'rtype', 'market', 'in_year', 'axis_page' ) ), __( 'Clear filters', 'axis-cre' ) ) : '';
		}
		if ( 'archive' === $mode ) {
			$out .= '<h2 class="screen-reader-text">' . esc_html__( 'Research', 'axis-cre' ) . '</h2>';
		}
		$out .= Render::grid( array_map( array( 'Axis_CRE\Render', 'research_card' ), $res['items'] ), __( 'Research', 'axis-cre' ) );
		if ( 'archive' === $mode ) {
			$out .= Render::pagination( $args['page'], $res['pages'] );
		}
		return $out;
	}
}
