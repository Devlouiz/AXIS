<?php
/**
 * Survey map: an SVG projection of real coordinates on the Axis Grid.
 *
 * No tiles, keys or third-party requests. Positions are to scale; streets are not drawn.
 * Developers can replace it through the `axis_cre_map_html` filter.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Map projection and rendering.
 */
class Map {

	const W = 880;
	const H = 520;

	/**
	 * Project points into map space.
	 *
	 * @param array<int, array<string, mixed>> $points Points with lat and lng.
	 * @param int                              $w      Width.
	 * @param int                              $h      Height.
	 * @return array{points: array<int, array<string, mixed>>, bounds: array<string, float>}
	 */
	public static function project( $points, $w = self::W, $h = self::H ) {
		$points = array_values(
			array_filter(
				$points,
				function ( $p ) {
					return is_numeric( $p['lat'] ) && is_numeric( $p['lng'] );
				}
			)
		);
		if ( ! $points ) {
			return array(
				'points' => array(),
				'bounds' => array(),
			);
		}
		$lats    = wp_list_pluck( $points, 'lat' );
		$lngs    = wp_list_pluck( $points, 'lng' );
		$min_lat = min( $lats );
		$max_lat = max( $lats );
		$min_lng = min( $lngs );
		$max_lng = max( $lngs );

		// Keep a minimum span so a single point sits in a sensible frame.
		$span_lat = max( $max_lat - $min_lat, 0.02 );
		$span_lng = max( $max_lng - $min_lng, 0.02 );
		$mid_lat  = ( $min_lat + $max_lat ) / 2;
		$mid_lng  = ( $min_lng + $max_lng ) / 2;
		$k        = cos( deg2rad( $mid_lat ) );

		// Fit to the frame with 14% padding, preserving the aspect at this latitude.
		$pad   = 1.28;
		$sx    = $w / ( $span_lng * $k * $pad );
		$sy    = $h / ( $span_lat * $pad );
		$scale = min( $sx, $sy );

		foreach ( $points as &$p ) {
			$p['x'] = round( $w / 2 + ( (float) $p['lng'] - $mid_lng ) * $k * $scale, 1 );
			$p['y'] = round( $h / 2 - ( (float) $p['lat'] - $mid_lat ) * $scale, 1 );
		}
		unset( $p );

		return array(
			'points' => $points,
			'bounds' => array(
				'mid_lat' => $mid_lat,
				'mid_lng' => $mid_lng,
				'k'       => $k,
				'scale'   => $scale,
			),
		);
	}

	/**
	 * Convert map x back to longitude, y to latitude, for edge labels.
	 *
	 * @param array<string, float> $b Bounds from project().
	 * @param float                $x X.
	 * @param float                $y Y.
	 * @return array{0: float, 1: float}
	 */
	public static function unproject( $b, $x, $y ) {
		return array(
			$b['mid_lat'] - ( $y - self::H / 2 ) / $b['scale'],
			$b['mid_lng'] + ( $x - self::W / 2 ) / ( $b['k'] * $b['scale'] ),
		);
	}

	/**
	 * Place one coordinate with existing bounds.
	 *
	 * @param array<string, float> $b   Bounds from project().
	 * @param float                $lat Latitude.
	 * @param float                $lng Longitude.
	 * @return array{0: float, 1: float}
	 */
	public static function place( $b, $lat, $lng ) {
		return array(
			round( self::W / 2 + ( (float) $lng - $b['mid_lng'] ) * $b['k'] * $b['scale'], 1 ),
			round( self::H / 2 - ( (float) $lat - $b['mid_lat'] ) * $b['scale'], 1 ),
		);
	}

	/**
	 * Opening tag, grid and edge coordinates.
	 *
	 * @param array<string, float> $bounds Bounds from project().
	 * @param string               $attrs  Extra attributes for the svg element, already escaped.
	 * @return string
	 */
	private static function base( $bounds, $attrs ) {
		$w   = self::W;
		$h   = self::H;
		$svg = '<svg class="axis-cre-map__svg" viewBox="0 0 ' . $w . ' ' . $h . '" ' . $attrs . '><g class="grid" aria-hidden="true">';
		for ( $x = 80; $x < $w; $x += 80 ) {
			$svg .= '<line x1="' . $x . '" y1="0" x2="' . $x . '" y2="' . $h . '"/>';
		}
		for ( $y = 80; $y < $h; $y += 80 ) {
			$svg .= '<line x1="0" y1="' . $y . '" x2="' . $w . '" y2="' . $y . '"/>';
		}
		$svg .= '</g>';
		if ( $bounds ) {
			$svg .= '<g class="ticks" aria-hidden="true">';
			foreach ( array( 160, 400, 640 ) as $x ) {
				$c    = self::unproject( $bounds, $x, 0 );
				$svg .= '<text x="' . ( $x + 4 ) . '" y="16" data-tick="x" data-at="' . $x . '">' . esc_html( Format::trim( abs( $c[1] ), 3 ) . ' ' . ( $c[1] >= 0 ? _x( 'E', 'east', 'axis-cre' ) : _x( 'W', 'west', 'axis-cre' ) ) ) . '</text>';
			}
			foreach ( array( 160, 400 ) as $y ) {
				$c    = self::unproject( $bounds, 0, $y );
				$svg .= '<text x="6" y="' . ( $y - 6 ) . '" data-tick="y" data-at="' . $y . '">' . esc_html( Format::trim( abs( $c[0] ), 3 ) . ' ' . ( $c[0] >= 0 ? _x( 'N', 'north', 'axis-cre' ) : _x( 'S', 'south', 'axis-cre' ) ) ) . '</text>';
			}
			$svg .= '</g>';
		}
		return $svg;
	}

	/**
	 * Shapes for one pin.
	 *
	 * @param string $kind asset, market, cluster or submarket.
	 * @param string $text Pin text.
	 * @param string $name Label beside round pins.
	 * @param string $text_attrs Extra attributes for the pin text, already escaped.
	 * @param float  $x          Pin x, to keep labels inside the frame.
	 * @return string
	 */
	private static function shapes( $kind, $text, $name = '', $text_attrs = '', $x = 0 ) {
		$out = self::shape_parts( $kind, $text, $name, $text_attrs );
		if ( $x > self::W - 170 ) {
			// Labels near the right edge sit to the left of their pin.
			$out = str_replace( '<text class="pin-label" x="27"', '<text class="pin-label" text-anchor="end" x="-27"', $out );
		}
		return '<g class="pin__body">' . $out . '</g>';
	}

	/**
	 * Pin shapes without the wrapper.
	 *
	 * @param string $kind       Pin kind.
	 * @param string $text       Pin text.
	 * @param string $name       Label.
	 * @param string $text_attrs Extra attributes, already escaped.
	 * @return string
	 */
	private static function shape_parts( $kind, $text, $name, $text_attrs ) {
		if ( 'cluster' === $kind || 'market' === $kind ) {
			$out = '<circle r="20"/><text text-anchor="middle" y="5"' . $text_attrs . '>' . esc_html( $text ) . '</text>';
			if ( '' !== $name ) {
				$out .= '<text class="pin-label" x="27" y="5">' . esc_html( $name ) . '</text>';
			}
			return $out;
		}
		if ( 'submarket' === $kind ) {
			return '<circle r="6"/><text class="pin-label" x="12" y="5">' . esc_html( $text ) . '</text>';
		}
		$tw = max( 36, 12 + 8.6 * mb_strlen( $text ) );
		return '<rect x="' . ( -$tw / 2 ) . '" y="-36" width="' . $tw . '" height="27" rx="2"/><path d="M-6 -10 L0 0 L6 -10 Z"/><text text-anchor="middle" y="-17">' . esc_html( $text ) . '</text>';
	}

	/**
	 * Static map SVG.
	 *
	 * @param array<int, array<string, mixed>> $points Projected points: x, y, text, name, kind, selected.
	 * @param array<string, float>             $bounds Bounds from project().
	 * @param string                           $label  Accessible name.
	 * @return string
	 */
	public static function svg( $points, $bounds, $label ) {
		$svg = self::base( $bounds, 'role="img" aria-label="' . esc_attr( $label ) . '"' ) . '<g class="pins">';
		foreach ( $points as $p ) {
			$kind = isset( $p['kind'] ) ? $p['kind'] : 'asset';
			$cls  = 'pin is-' . $kind . ( ! empty( $p['selected'] ) ? ' is-selected' : '' );
			$svg .= '<g class="' . esc_attr( $cls ) . '" transform="translate(' . esc_attr( (string) $p['x'] ) . ' ' . esc_attr( (string) $p['y'] ) . ')">' . self::shapes( $kind, (string) $p['text'], isset( $p['name'] ) && 'asset' !== $kind ? (string) $p['name'] : '', '', (float) $p['x'] ) . '</g>';
		}
		return $svg . '</g></svg>';
	}

	/**
	 * Explorer map: market pins (pid absent, mid set) and asset pins as buttons.
	 *
	 * @param array<int, array<string, mixed>> $pins   Pins: mid or pid, x, y, text, name, url, hidden.
	 * @param array<string, float>             $bounds Bounds from project().
	 * @param string                           $label  Accessible name.
	 * @return string
	 */
	public static function explorer_svg( $pins, $bounds, $label ) {
		// No interactivity directives inside the SVG: the server cannot process them there.
		// The explorer script keeps pins in step from the map frame instead.
		$svg = self::base( $bounds, 'role="group" aria-label="' . esc_attr( $label ) . '"' ) . '<g class="pins">';
		// Markets first so asset pins draw above them.
		foreach ( $pins as $p ) {
			$pos    = ' transform="translate(' . esc_attr( (string) $p['x'] ) . ' ' . esc_attr( (string) $p['y'] ) . ')"';
			$hidden = ! empty( $p['hidden'] ) ? ' is-hidden' : '';
			if ( isset( $p['mid'] ) ) {
				$svg .= '<g class="pin is-market' . $hidden . '" data-mid="' . (int) $p['mid'] . '"' . $pos . '>';
				// The name comes from the pin's own text, its count and market, which the script keeps current.
				$svg .= '<a href="' . esc_url( $p['url'] ) . '" role="button">' . self::shapes( 'market', (string) $p['text'], (string) $p['name'], ' class="pin-count"', (float) $p['x'] ) . '</a></g>';
			} else {
				$svg .= '<g class="pin is-asset' . $hidden . '" data-pid="' . (int) $p['pid'] . '"' . $pos . '>';
				$svg .= '<a href="#axis-card-' . (int) $p['pid'] . '" role="button" aria-label="' . esc_attr( $p['name'] ) . '" aria-pressed="false">' . self::shapes( 'asset', (string) $p['text'] ) . '</a></g>';
			}
		}
		return $svg . '</g></svg>';
	}

	/**
	 * Static map with its accessible list.
	 *
	 * @param array<int, array<string, mixed>> $points Points: id, lat, lng, text, name, url, kind, selected, meta.
	 * @param string                           $label  Accessible name.
	 * @param string                           $list_title Heading for the list.
	 * @param int                              $level      Heading level of the list title, 2 or 3.
	 * @return string
	 */
	public static function static_map( $points, $label, $list_title, $level = 3 ) {
		$proj = self::project( $points );
		if ( ! $proj['points'] ) {
			return Render::empty_state( __( 'No locations to show yet', 'axis-cre' ), __( 'Add latitude and longitude to items to place them on the map.', 'axis-cre' ) );
		}
		$map = '<div class="axis-cre-map__frame">' . self::svg( $proj['points'], $proj['bounds'], $label ) . '<p class="axis-cre-map__note">' . esc_html__( 'Survey map: positions are to scale; streets are not shown.', 'axis-cre' ) . '</p></div>';

		$tag  = 2 === (int) $level ? 'h2' : 'h3';
		$list = '<div class="axis-cre-map__list"><' . $tag . ' class="axis-cre-map__list-title">' . esc_html( $list_title ) . '</' . $tag . '><ul>';
		foreach ( $points as $p ) {
			$name  = isset( $p['name'] ) ? $p['name'] : $p['text'];
			$list .= '<li' . ( ! empty( $p['selected'] ) ? ' aria-current="true"' : '' ) . '>' . ( ! empty( $p['url'] ) ? '<a href="' . esc_url( $p['url'] ) . '">' . esc_html( $name ) . '</a>' : '<span>' . esc_html( $name ) . '</span>' ) . '<span class="is-style-technical-label">' . esc_html( isset( $p['meta'] ) ? $p['meta'] : '' ) . '</span></li>';
		}
		$list .= '</ul></div>';

		/**
		 * Filter the static map markup, for example to swap in a tile map.
		 *
		 * @param string $html   Map and list markup.
		 * @param array  $points Points passed to the map.
		 */
		return (string) apply_filters( 'axis_cre_map_html', '<div class="axis-cre-map">' . $map . $list . '</div>', $points );
	}
}
