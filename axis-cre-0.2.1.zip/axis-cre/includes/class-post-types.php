<?php
/**
 * Post types and taxonomies.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the five content types and their taxonomies.
 */
class Post_Types {

	const PROPERTY    = 'axis_property';
	const MARKET      = 'axis_market';
	const TRANSACTION = 'axis_transaction';
	const EXPERT      = 'axis_expert';
	const RESEARCH    = 'axis_research';

	/**
	 * Hook registration.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ), 5 );
	}

	/**
	 * All AXIS post types.
	 *
	 * @return string[]
	 */
	public static function all() {
		return array( self::PROPERTY, self::MARKET, self::TRANSACTION, self::EXPERT, self::RESEARCH );
	}

	/**
	 * Register post types and taxonomies.
	 */
	public static function register() {
		$types = array(
			self::PROPERTY    => array(
				'slug'     => 'properties',
				'icon'     => 'dashicons-building',
				'singular' => __( 'Property', 'axis-cre' ),
				'plural'   => __( 'Properties', 'axis-cre' ),
				'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields' ),
			),
			self::MARKET      => array(
				'slug'     => 'markets',
				'icon'     => 'dashicons-location-alt',
				'singular' => __( 'Market', 'axis-cre' ),
				'plural'   => __( 'Markets', 'axis-cre' ),
				'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields', 'page-attributes' ),
			),
			self::TRANSACTION => array(
				'slug'     => 'transactions',
				'icon'     => 'dashicons-chart-line',
				'singular' => __( 'Transaction', 'axis-cre' ),
				'plural'   => __( 'Transactions', 'axis-cre' ),
				'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields' ),
			),
			self::EXPERT      => array(
				'slug'     => 'experts',
				'icon'     => 'dashicons-businessperson',
				'singular' => __( 'Expert', 'axis-cre' ),
				'plural'   => __( 'Experts', 'axis-cre' ),
				'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields', 'page-attributes' ),
			),
			self::RESEARCH    => array(
				'slug'     => 'research',
				'icon'     => 'dashicons-media-document',
				'singular' => __( 'Research', 'axis-cre' ),
				'plural'   => __( 'Research', 'axis-cre' ),
				'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields', 'author' ),
			),
		);

		$position = 21;
		foreach ( $types as $type => $def ) {
			register_post_type(
				$type,
				array(
					'labels'        => array(
						'name'               => $def['plural'],
						'singular_name'      => $def['singular'],
						/* translators: %s: content type name, for example Property. */
						'add_new_item'       => sprintf( __( 'Add %s', 'axis-cre' ), $def['singular'] ),
						/* translators: %s: content type name, for example Property. */
						'edit_item'          => sprintf( __( 'Edit %s', 'axis-cre' ), $def['singular'] ),
						/* translators: %s: content type name, for example Property. */
						'view_item'          => sprintf( __( 'View %s', 'axis-cre' ), $def['singular'] ),
						/* translators: %s: content type name, plural, for example Properties. */
						'search_items'       => sprintf( __( 'Search %s', 'axis-cre' ), $def['plural'] ),
						/* translators: %s: content type name, plural, for example Properties. */
						'not_found'          => sprintf( __( 'No %s found', 'axis-cre' ), strtolower( $def['plural'] ) ),
						/* translators: %s: content type name, plural, for example Properties. */
						'all_items'          => sprintf( __( 'All %s', 'axis-cre' ), $def['plural'] ),
						'menu_name'          => $def['plural'],
						'not_found_in_trash' => __( 'Nothing found in the bin', 'axis-cre' ),
					),
					'public'        => true,
					'show_in_rest'  => true,
					'has_archive'   => $def['slug'],
					'rewrite'       => array(
						'slug'       => $def['slug'],
						'with_front' => false,
					),
					'menu_icon'     => $def['icon'],
					'menu_position' => min( 24, $position++ ),
					'supports'      => $def['supports'],
				)
			);
		}

		$taxonomies = array(
			'axis_property_type'    => array(
				'objects'  => array( self::PROPERTY, self::TRANSACTION, self::EXPERT, self::RESEARCH ),
				'slug'     => 'property-type',
				'singular' => __( 'Property type', 'axis-cre' ),
				'plural'   => __( 'Property types', 'axis-cre' ),
			),
			'axis_listing_type'     => array(
				'objects'  => array( self::PROPERTY ),
				'slug'     => 'listing',
				'singular' => __( 'Listing type', 'axis-cre' ),
				'plural'   => __( 'Listing types', 'axis-cre' ),
			),
			'axis_transaction_type' => array(
				'objects'  => array( self::TRANSACTION ),
				'slug'     => 'deal-type',
				'singular' => __( 'Deal type', 'axis-cre' ),
				'plural'   => __( 'Deal types', 'axis-cre' ),
			),
			'axis_service'          => array(
				'objects'  => array( self::TRANSACTION, self::EXPERT ),
				'slug'     => 'service',
				'singular' => __( 'Service', 'axis-cre' ),
				'plural'   => __( 'Services', 'axis-cre' ),
			),
			'axis_research_type'    => array(
				'objects'  => array( self::RESEARCH ),
				'slug'     => 'research-type',
				'singular' => __( 'Research type', 'axis-cre' ),
				'plural'   => __( 'Research types', 'axis-cre' ),
			),
		);

		foreach ( $taxonomies as $taxonomy => $def ) {
			register_taxonomy(
				$taxonomy,
				$def['objects'],
				array(
					'labels'            => array(
						'name'          => $def['plural'],
						'singular_name' => $def['singular'],
						'menu_name'     => $def['plural'],
					),
					'hierarchical'      => true,
					'public'            => true,
					'show_in_rest'      => true,
					'show_admin_column' => true,
					'rewrite'           => array(
						'slug'       => $def['slug'],
						'with_front' => false,
					),
				)
			);
		}
	}

	/**
	 * Activation: register, seed default terms, flush rewrites.
	 */
	public static function activate() {
		self::register();
		self::seed_terms();
		flush_rewrite_rules();
	}

	/**
	 * Deactivation: drop the post types and taxonomies before flushing, so their URLs stop resolving.
	 */
	public static function deactivate() {
		foreach ( get_object_taxonomies( self::all() ) as $taxonomy ) {
			if ( 0 === strpos( $taxonomy, 'axis_' ) ) {
				unregister_taxonomy( $taxonomy );
			}
		}
		foreach ( self::all() as $type ) {
			unregister_post_type( $type );
		}
		flush_rewrite_rules();
	}

	/**
	 * Default terms. Slugs are fixed so hatches and rules keep working in any language.
	 */
	public static function seed_terms() {
		$defaults = array(
			'axis_property_type'    => array(
				'office'      => __( 'Office', 'axis-cre' ),
				'industrial'  => __( 'Industrial', 'axis-cre' ),
				'multifamily' => __( 'Multifamily', 'axis-cre' ),
				'retail'      => __( 'Retail', 'axis-cre' ),
				'mixed-use'   => __( 'Mixed use', 'axis-cre' ),
				'land'        => __( 'Land', 'axis-cre' ),
			),
			'axis_listing_type'     => array(
				'investment-sale' => __( 'Investment sale', 'axis-cre' ),
				'for-lease'       => __( 'For lease', 'axis-cre' ),
				'under-offer'     => __( 'Under offer', 'axis-cre' ),
				'sold'            => __( 'Sold', 'axis-cre' ),
				'leased'          => __( 'Leased', 'axis-cre' ),
			),
			'axis_transaction_type' => array(
				'sale'             => __( 'Sale', 'axis-cre' ),
				'lease'            => __( 'Lease', 'axis-cre' ),
				'recapitalisation' => __( 'Recapitalisation', 'axis-cre' ),
				'debt-placement'   => __( 'Debt placement', 'axis-cre' ),
				'portfolio-sale'   => __( 'Portfolio sale', 'axis-cre' ),
			),
			'axis_service'          => array(
				'capital-markets'         => __( 'Capital markets', 'axis-cre' ),
				'tenant-representation'   => __( 'Tenant representation', 'axis-cre' ),
				'landlord-representation' => __( 'Landlord representation', 'axis-cre' ),
				'valuation-and-advisory'  => __( 'Valuation and advisory', 'axis-cre' ),
				'development'             => __( 'Development', 'axis-cre' ),
				'property-management'     => __( 'Property management', 'axis-cre' ),
			),
			'axis_research_type'    => array(
				'market-report'       => __( 'Market report', 'axis-cre' ),
				'outlook'             => __( 'Outlook', 'axis-cre' ),
				'data-brief'          => __( 'Data brief', 'axis-cre' ),
				'transaction-insight' => __( 'Transaction insight', 'axis-cre' ),
				'perspective'         => __( 'Perspective', 'axis-cre' ),
			),
		);

		foreach ( $defaults as $taxonomy => $terms ) {
			foreach ( $terms as $slug => $name ) {
				if ( ! get_term_by( 'slug', $slug, $taxonomy ) ) {
					wp_insert_term( $name, $taxonomy, array( 'slug' => $slug ) );
				}
			}
		}
	}
}
