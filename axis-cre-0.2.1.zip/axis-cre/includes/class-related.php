<?php
/**
 * Related listings: properties chosen by rule, relative to the post the block sits on.
 *
 * The subject is read from the block context, so the same block works on a property,
 * a market, an expert, a transaction or a research template, and inside a Query Loop.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Picks and orders related properties.
 */
class Related {

	/**
	 * Rules in the order they are relaxed when there are too few strict matches:
	 * the first one is dropped first.
	 */
	const RELAX = array( 'listing', 'broker', 'price', 'size', 'radius', 'type', 'market' );

	/**
	 * What the block relates to: market, type, listing, price, size, place and team of the subject post.
	 *
	 * @param int $post_id Post the block is on, or 0.
	 * @return array<string, mixed>
	 */
	public static function subject( $post_id ) {
		$s    = array(
			'kind'    => '',
			'markets' => array(),
			'type'    => '',
			'listing' => '',
			'price'   => null,
			'lease'   => null,
			'size'    => null,
			'lat'     => null,
			'lng'     => null,
			'experts' => array(),
			'exclude' => array(),
			'forced'  => array(),
		);
		$type = $post_id ? get_post_type( $post_id ) : '';

		$from_property = function ( $p ) use ( &$s ) {
			$s['markets'] = $p['market'] ? array( (int) $p['market'] ) : $s['markets'];
			$s['type']    = $p['type'] ? $p['type'] : $s['type'];
			$s['listing'] = $p['status_slug'];
			$s['price']   = $p['price'];
			$s['lease']   = $p['lease'];
			$s['size']    = $p['size'];
			$s['lat']     = $p['lat'];
			$s['lng']     = $p['lng'];
			$s['experts'] = $s['experts'] ? $s['experts'] : $p['experts'];
		};

		if ( Post_Types::PROPERTY === $type ) {
			$p = Repository::property( $post_id );
			if ( $p ) {
				$s['kind']    = 'property';
				$s['exclude'] = array( $post_id );
				$from_property( $p );
			}
		} elseif ( Post_Types::MARKET === $type ) {
			$m = Repository::market( $post_id );
			if ( $m ) {
				$s['kind']    = 'market';
				$s['markets'] = array( $post_id );
				$s['lat']     = $m['lat'];
				$s['lng']     = $m['lng'];
				$s['forced']  = array( 'market' );
			}
		} elseif ( Post_Types::EXPERT === $type ) {
			$e = Repository::expert( $post_id );
			if ( $e ) {
				$s['kind']    = 'expert';
				$s['experts'] = array( $post_id );
				$s['markets'] = array_map( 'intval', wp_list_pluck( $e['markets'], 'id' ) );
				$s['forced']  = array( 'broker' );
			}
		} elseif ( Post_Types::TRANSACTION === $type ) {
			$t = Repository::transaction( $post_id );
			if ( $t ) {
				$s['kind']    = 'transaction';
				$s['markets'] = $t['market'] ? array( $t['market'] ) : array();
				$s['type']    = $t['type'];
				$s['experts'] = array_values( array_filter( $t['experts'] ) );
				$p            = $t['property'] ? Repository::property( $t['property'] ) : null;
				if ( $p ) {
					$from_property( $p );
					$s['listing'] = '';
					$s['exclude'] = array( $p['id'] );
				}
				if ( null === $s['price'] && is_numeric( $t['value'] ) ) {
					$s['price'] = (float) $t['value'];
				}
			}
		} elseif ( Post_Types::RESEARCH === $type ) {
			$r = Repository::research( $post_id );
			if ( $r ) {
				$s['kind']    = 'research';
				$s['markets'] = array_map( 'intval', wp_list_pluck( $r['markets'], 'id' ) );
			}
		}
		if ( $s['markets'] && null === $s['lat'] ) {
			$m = Repository::market( $s['markets'][0] );
			if ( $m ) {
				$s['lat'] = $m['lat'];
				$s['lng'] = $m['lng'];
			}
		}
		/**
		 * Filters the subject that related listings are matched against.
		 *
		 * @param array<string, mixed> $s       Subject.
		 * @param int                  $post_id Post the block is on.
		 */
		return (array) apply_filters( 'axis_cre_related_subject', $s, $post_id );
	}

	/**
	 * The rules that can apply: switched on in the block (or forced by the context) and
	 * answerable from the subject.
	 *
	 * @param array<string, mixed> $a Attributes.
	 * @param array<string, mixed> $s Subject.
	 * @return array<string, mixed> Rule => parameter.
	 */
	public static function rules( $a, $s ) {
		$on    = function ( $key, $rule ) use ( $a, $s ) {
			return ! empty( $a[ $key ] ) || in_array( $rule, $s['forced'], true );
		};
		$rules = array();
		if ( $on( 'matchMarket', 'market' ) && $s['markets'] ) {
			$rules['market'] = $s['markets'];
		}
		if ( $on( 'matchType', 'type' ) && $s['type'] ) {
			$rules['type'] = $s['type'];
		}
		if ( $on( 'matchListing', 'listing' ) && $s['listing'] ) {
			$rules['listing'] = $s['listing'];
		}
		if ( $on( 'matchBroker', 'broker' ) && $s['experts'] ) {
			$rules['broker'] = $s['experts'];
		}
		$price = isset( $a['priceRange'] ) ? (int) $a['priceRange'] : 0;
		if ( $price > 0 && ( $s['price'] || $s['lease'] ) ) {
			$rules['price'] = $price / 100;
		}
		$size = isset( $a['sizeRange'] ) ? (int) $a['sizeRange'] : 0;
		if ( $size > 0 && $s['size'] ) {
			$rules['size'] = $size / 100;
		}
		$radius = isset( $a['radius'] ) ? (float) $a['radius'] : 0;
		if ( $radius > 0 && null !== $s['lat'] && null !== $s['lng'] ) {
			$rules['radius'] = $radius;
		}
		return $rules;
	}

	/**
	 * Great-circle distance.
	 *
	 * @param float  $lat1 Latitude.
	 * @param float  $lng1 Longitude.
	 * @param float  $lat2 Latitude.
	 * @param float  $lng2 Longitude.
	 * @param string $unit mi or km.
	 * @return float
	 */
	public static function distance( $lat1, $lng1, $lat2, $lng2, $unit = 'mi' ) {
		$r    = 'km' === $unit ? 6371.0 : 3958.8;
		$dlat = deg2rad( $lat2 - $lat1 );
		$dlng = deg2rad( $lng2 - $lng1 );
		$h    = sin( $dlat / 2 ) ** 2 + cos( deg2rad( $lat1 ) ) * cos( deg2rad( $lat2 ) ) * sin( $dlng / 2 ) ** 2;
		return 2 * $r * asin( min( 1, sqrt( $h ) ) );
	}

	/**
	 * Which rules a candidate meets.
	 *
	 * @param array<string, mixed> $p     Candidate property.
	 * @param array<string, mixed> $s     Subject.
	 * @param array<string, mixed> $rules Rules.
	 * @param float|null           $dist  Distance to the subject.
	 * @return string[] Rules met.
	 */
	private static function met( $p, $s, $rules, $dist ) {
		$met = array();
		foreach ( $rules as $rule => $arg ) {
			switch ( $rule ) {
				case 'market':
					$ok = in_array( (int) $p['market'], $arg, true );
					break;
				case 'type':
					$ok = $p['type'] === $arg;
					break;
				case 'listing':
					$ok = $p['status_slug'] === $arg;
					break;
				case 'broker':
					$ok = (bool) array_intersect( $p['experts'], $arg );
					break;
				case 'price':
					// Compare sale price with sale price, rent with rent.
					if ( $s['price'] && $p['price'] ) {
						$ok = abs( $p['price'] - $s['price'] ) <= $s['price'] * $arg;
					} elseif ( $s['lease'] && $p['lease'] ) {
						$ok = abs( $p['lease'] - $s['lease'] ) <= $s['lease'] * $arg;
					} else {
						$ok = false;
					}
					break;
				case 'size':
					$ok = $p['size'] && abs( $p['size'] - $s['size'] ) <= $s['size'] * $arg;
					break;
				case 'radius':
					$ok = null !== $dist && $dist <= $arg;
					break;
				default:
					$ok = false;
			}
			if ( $ok ) {
				$met[] = $rule;
			}
		}
		return $met;
	}

	/**
	 * Closeness for ordering within a tier: 0 is identical, larger is further.
	 *
	 * @param array<string, mixed> $p    Candidate.
	 * @param array<string, mixed> $s    Subject.
	 * @param float|null           $dist Distance.
	 * @return float
	 */
	private static function closeness( $p, $s, $dist ) {
		$d = 0.0;
		if ( $s['price'] && $p['price'] ) {
			$d += abs( log( $p['price'] / $s['price'] ) );
		} elseif ( $s['lease'] && $p['lease'] ) {
			$d += abs( log( $p['lease'] / $s['lease'] ) );
		} else {
			++$d;
		}
		if ( $s['size'] && $p['size'] ) {
			$d += abs( log( $p['size'] / $s['size'] ) );
		}
		if ( null !== $dist ) {
			$d += min( 2, $dist / 50 );
		}
		return $d;
	}

	/**
	 * Find related properties.
	 *
	 * @param array<string, mixed> $a       Attributes.
	 * @param int                  $post_id Post the block is on.
	 * @return array{items: array<int, array<string, mixed>>, rules: array<string, mixed>, subject: array<string, mixed>}
	 */
	public static function find( $a, $post_id ) {
		$s        = self::subject( $post_id );
		$rules    = self::rules( $a, $s );
		$per      = max( 1, min( 24, (int) ( isset( $a['perPage'] ) ? $a['perPage'] : 3 ) ) );
		$unit     = isset( $a['unit'] ) && 'km' === $a['unit'] ? 'km' : 'mi';
		$fallback = ! isset( $a['fallback'] ) || ! empty( $a['fallback'] );
		$order    = isset( $a['orderBy'] ) ? (string) $a['orderBy'] : 'match';

		// Without fallback, let the database do the strict part.
		$query = array(
			'per_page' => (int) apply_filters( 'axis_cre_related_pool_size', 300 ),
			'exclude'  => $s['exclude'],
		);
		if ( ! $fallback ) {
			if ( isset( $rules['type'] ) ) {
				$query['type'] = $rules['type'];
			}
			if ( isset( $rules['listing'] ) ) {
				$query['listing'] = $rules['listing'];
			}
			if ( isset( $rules['market'] ) && 1 === count( $rules['market'] ) ) {
				$query['market'] = $rules['market'][0];
			}
		}
		$pool = Repository::properties( $query )['items'];

		// Score every candidate once.
		$scored = array();
		foreach ( $pool as $p ) {
			$dist = ( null !== $s['lat'] && null !== $p['lat'] && null !== $p['lng'] ) ? self::distance( $s['lat'], $s['lng'], $p['lat'], $p['lng'], $unit ) : null;
			$met  = self::met( $p, $s, $rules, $dist );
			// Tier: how many rules had to be relaxed before this candidate qualifies.
			$tier  = count( self::RELAX ) + 1;
			$avail = array_keys( $rules );
			$level = 0;
			foreach ( array_merge( array( '' ), self::RELAX ) as $drop ) {
				if ( '' !== $drop ) {
					if ( in_array( $drop, $s['forced'], true ) ) {
						continue;
					}
					$avail = array_values( array_diff( $avail, array( $drop ) ) );
					++$level;
				}
				if ( ! array_diff( $avail, $met ) ) {
					$tier = $level;
					break;
				}
			}
			if ( $tier > 0 && ! $fallback ) {
				continue;
			}
			// Forced rules are never relaxed.
			if ( array_diff( array_intersect( $s['forced'], array_keys( $rules ) ), $met ) ) {
				continue;
			}
			$p['distance']  = $dist;
			$p['met']       = $met;
			$p['tier']      = $tier;
			$p['closeness'] = self::closeness( $p, $s, $dist );
			$p['date']      = (int) get_post_time( 'U', true, $p['id'] );
			$scored[]       = $p;
		}

		usort(
			$scored,
			function ( $x, $y ) use ( $order ) {
				if ( 'nearest' === $order ) {
					$dx = null === $x['distance'] ? INF : $x['distance'];
					$dy = null === $y['distance'] ? INF : $y['distance'];
					return array( $x['tier'], $dx ) <=> array( $y['tier'], $dy );
				}
				if ( 'newest' === $order ) {
					return array( $x['tier'], -$x['date'] ) <=> array( $y['tier'], -$y['date'] );
				}
				// Best match: fewest rules relaxed, then the closest in price, size and place, featured first on a tie.
				return array( $x['tier'], $x['closeness'], (int) ! $x['featured'] ) <=> array( $y['tier'], $y['closeness'], (int) ! $y['featured'] );
			}
		);

		return array(
			'items'   => array_slice( $scored, 0, $per ),
			'rules'   => $rules,
			'subject' => $s,
		);
	}

	/**
	 * Distance as text, for example "2.4 mi away".
	 *
	 * @param float|null $d    Distance.
	 * @param string     $unit mi or km.
	 * @return string
	 */
	public static function distance_label( $d, $unit ) {
		if ( null === $d ) {
			return '';
		}
		$n = $d < 10 ? number_format_i18n( $d, 1 ) : number_format_i18n( round( $d ) );
		return 'km' === $unit
			/* translators: %s: distance in kilometres. */
			? sprintf( __( '%s km away', 'axis-cre' ), $n )
			/* translators: %s: distance in miles. */
			: sprintf( __( '%s mi away', 'axis-cre' ), $n );
	}

	/**
	 * Why a listing was picked, in words, for screen readers and the card.
	 *
	 * @param string[]             $met   Rules met.
	 * @param array<string, mixed> $rules Rules in play.
	 * @return string
	 */
	public static function reason( $met, $rules ) {
		$words = array(
			'market'  => __( 'same market', 'axis-cre' ),
			'type'    => __( 'same property type', 'axis-cre' ),
			'listing' => __( 'same listing type', 'axis-cre' ),
			'broker'  => __( 'same listing team', 'axis-cre' ),
			/* translators: %d: percent. */
			'price'   => isset( $rules['price'] ) ? sprintf( __( 'price within %d%%', 'axis-cre' ), round( $rules['price'] * 100 ) ) : '',
			/* translators: %d: percent. */
			'size'    => isset( $rules['size'] ) ? sprintf( __( 'size within %d%%', 'axis-cre' ), round( $rules['size'] * 100 ) ) : '',
			'radius'  => __( 'nearby', 'axis-cre' ),
		);
		$out   = array();
		foreach ( array_keys( $words ) as $k ) {
			if ( in_array( $k, $met, true ) && '' !== $words[ $k ] ) {
				$out[] = $words[ $k ];
			}
		}
		if ( ! $out ) {
			return '';
		}
		/* translators: %s: list of reasons, for example "same market, price within 25%". */
		return ucfirst( sprintf( __( 'Matched on %s', 'axis-cre' ), implode( ', ', $out ) ) );
	}
}
