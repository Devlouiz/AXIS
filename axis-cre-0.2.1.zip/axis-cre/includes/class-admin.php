<?php
/**
 * Editing screens: details box, list columns, and settings.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Admin UI built from Fields::definitions().
 */
class Admin {

	const NONCE = 'axis_cre_fields';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'meta_boxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'settings' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( AXIS_CRE_FILE ), array( __CLASS__, 'action_links' ) );
		foreach ( Post_Types::all() as $type ) {
			add_filter( 'manage_' . $type . '_posts_columns', array( __CLASS__, 'columns' ) );
			add_action( 'manage_' . $type . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		}
	}

	/**
	 * Section names for field groups.
	 *
	 * @return array<string, string>
	 */
	private static function groups() {
		return array(
			'identity'   => __( 'Identifier', 'axis-cre' ),
			'location'   => __( 'Location', 'axis-cre' ),
			'building'   => __( 'Building', 'axis-cre' ),
			'financials' => __( 'Financials', 'axis-cre' ),
			'listing'    => __( 'Listing', 'axis-cre' ),
			'media'      => __( 'Photos and documents', 'axis-cre' ),
			'data'       => __( 'Market data', 'axis-cre' ),
			'deal'       => __( 'Deal', 'axis-cre' ),
			'story'      => __( 'Story', 'axis-cre' ),
			'profile'    => __( 'Profile', 'axis-cre' ),
			'contact'    => __( 'Contact', 'axis-cre' ),
			'record'     => __( 'Track record', 'axis-cre' ),
			'report'     => __( 'Report', 'axis-cre' ),
		);
	}

	/**
	 * Add the details box to each AXIS post type.
	 */
	public static function meta_boxes() {
		$titles = array(
			Post_Types::PROPERTY    => __( 'Property details', 'axis-cre' ),
			Post_Types::MARKET      => __( 'Market details', 'axis-cre' ),
			Post_Types::TRANSACTION => __( 'Transaction details', 'axis-cre' ),
			Post_Types::EXPERT      => __( 'Expert details', 'axis-cre' ),
			Post_Types::RESEARCH    => __( 'Report details', 'axis-cre' ),
		);
		foreach ( $titles as $type => $title ) {
			add_meta_box( 'axis-cre-details', $title, array( __CLASS__, 'box' ), $type, 'normal', 'high' );
		}
	}

	/**
	 * Scripts and styles for AXIS edit screens and settings.
	 *
	 * @param string $hook Admin page hook.
	 */
	public static function assets( $hook ) {
		$screen = get_current_screen();
		$is_cpt = $screen && in_array( $screen->post_type, Post_Types::all(), true ) && in_array( $hook, array( 'post.php', 'post-new.php' ), true );
		if ( ! $is_cpt && 'settings_page_axis-cre' !== $hook && 'tools_page_axis-cre-sample' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'axis-cre-admin', AXIS_CRE_URL . 'assets/css/admin.css', array(), AXIS_CRE_VERSION );
		if ( $is_cpt ) {
			wp_enqueue_media();
			wp_enqueue_script( 'axis-cre-admin', AXIS_CRE_URL . 'assets/js/admin.js', array( 'jquery', 'wp-i18n' ), AXIS_CRE_VERSION, true );
			wp_set_script_translations( 'axis-cre-admin', 'axis-cre', AXIS_CRE_DIR . 'languages' );
		}
	}

	/**
	 * Render the details box.
	 *
	 * @param \WP_Post $post Post.
	 */
	public static function box( $post ) {
		$defs = Fields::definitions();
		if ( empty( $defs[ $post->post_type ] ) ) {
			return;
		}
		wp_nonce_field( self::NONCE, self::NONCE );

		$by_group = array();
		foreach ( $defs[ $post->post_type ] as $key => $field ) {
			$by_group[ $field['group'] ][ $key ] = $field;
		}
		$names = self::groups();

		echo '<div class="axis-cre-admin">';
		foreach ( $by_group as $group => $fields ) {
			echo '<fieldset class="axis-cre-admin__group"><legend>' . esc_html( isset( $names[ $group ] ) ? $names[ $group ] : $group ) . '</legend><div class="axis-cre-admin__fields">';
			foreach ( $fields as $key => $field ) {
				self::field( $post->ID, $key, $field );
			}
			echo '</div></fieldset>';
		}
		echo '</div>';
	}

	/**
	 * One field.
	 *
	 * @param int                  $post_id Post ID.
	 * @param string               $key     Field key.
	 * @param array<string, mixed> $field   Definition.
	 */
	private static function field( $post_id, $key, $field ) {
		$id    = 'axis-cre-' . $key;
		$name  = 'axis_cre[' . $key . ']';
		$value = Fields::get( $post_id, $key );
		$type  = $field['type'];
		$wide  = in_array( $type, array( 'textarea', 'lines', 'media', 'documents', 'posts' ), true );
		$help  = $field['help'] ? '<p class="description" id="' . esc_attr( $id ) . '-help">' . esc_html( $field['help'] ) . '</p>' : '';
		$desc  = $field['help'] ? ' aria-describedby="' . esc_attr( $id ) . '-help"' : '';

		echo '<div class="axis-cre-admin__field' . ( $wide ? ' is-wide' : '' ) . '">';

		switch ( $type ) {
			case 'boolean':
				echo '<label class="axis-cre-admin__check"><input type="checkbox" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="1"' . checked( (bool) $value, true, false ) . $desc . '> ' . esc_html( $field['label'] ) . '</label>' . $help; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $desc and $help are escaped above.
				break;

			case 'textarea':
			case 'lines':
				echo '<label for="' . esc_attr( $id ) . '">' . esc_html( $field['label'] ) . '</label>';
				echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="' . ( 'lines' === $type ? 5 : 3 ) . '" class="' . ( 'lines' === $type ? 'code' : '' ) . '"' . $desc . '>' . esc_textarea( (string) $value ) . '</textarea>' . $help; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- As above.
				break;

			case 'post':
				echo '<label for="' . esc_attr( $id ) . '">' . esc_html( $field['label'] ) . '</label>';
				echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '"' . $desc . '><option value="">' . esc_html__( 'None', 'axis-cre' ) . '</option>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- As above.
				foreach ( self::choices( $field['target'] ) as $pid => $title ) {
					echo '<option value="' . esc_attr( (string) $pid ) . '"' . selected( (int) $value, $pid, false ) . '>' . esc_html( $title ) . '</option>';
				}
				echo '</select>' . $help; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- As above.
				break;

			case 'posts':
				$current = array_map( 'intval', (array) $value );
				$choices = self::choices( $field['target'] );
				// Keep the saved order first, so "the first expert" stays first.
				$ordered = array();
				foreach ( $current as $pid ) {
					if ( isset( $choices[ $pid ] ) ) {
						$ordered[ $pid ] = $choices[ $pid ];
					}
				}
				$ordered += $choices;
				echo '<fieldset class="axis-cre-admin__choices"' . $desc . '><legend>' . esc_html( $field['label'] ) . '</legend>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- As above.
				echo '<input type="hidden" name="' . esc_attr( $name ) . '[]" value="0">';
				if ( ! $ordered ) {
					echo '<p class="description">' . esc_html__( 'Nothing to choose from yet.', 'axis-cre' ) . '</p>';
				}
				foreach ( $ordered as $pid => $title ) {
					echo '<label><input type="checkbox" name="' . esc_attr( $name ) . '[]" value="' . esc_attr( (string) $pid ) . '"' . checked( in_array( $pid, $current, true ), true, false ) . '> ' . esc_html( $title ) . '</label>';
				}
				echo '</fieldset>' . $help; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- As above.
				break;

			case 'media':
				$ids      = array_map( 'intval', (array) $value );
				$multiple = 'gallery' === $key;
				$mime     = 'pdf' === $key ? 'application/pdf' : ( 'data' === $key ? 'text/csv' : 'image' );
				echo '<div class="axis-cre-media" data-multiple="' . ( $multiple ? '1' : '0' ) . '" data-mime="' . esc_attr( $mime ) . '">';
				echo '<p class="axis-cre-admin__label" id="' . esc_attr( $id ) . '-label">' . esc_html( $field['label'] ) . '</p>';
				echo '<input type="hidden" class="axis-cre-media__ids" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( implode( ',', $ids ) ) . '">';
				echo '<ul class="axis-cre-media__list">';
				foreach ( $ids as $aid ) {
					echo self::media_item( $aid ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in media_item().
				}
				echo '</ul><p><button type="button" class="button axis-cre-media__add" aria-describedby="' . esc_attr( $id ) . '-label">' . esc_html( $multiple ? __( 'Add images', 'axis-cre' ) : __( 'Choose file', 'axis-cre' ) ) . '</button></p>' . $help . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- As above.
				break;

			case 'documents':
				$docs = (array) $value;
				echo '<div class="axis-cre-docs-field" data-name="' . esc_attr( $name ) . '">';
				echo '<p class="axis-cre-admin__label">' . esc_html( $field['label'] ) . '</p>';
				echo '<table class="widefat striped axis-cre-docs-field__table"><thead><tr><th scope="col">' . esc_html__( 'Document', 'axis-cre' ) . '</th><th scope="col">' . esc_html__( 'Gated', 'axis-cre' ) . '</th><th scope="col"><span class="screen-reader-text">' . esc_html__( 'Actions', 'axis-cre' ) . '</span></th></tr></thead><tbody>';
				foreach ( array_values( $docs ) as $i => $doc ) {
					$aid = isset( $doc['id'] ) ? (int) $doc['id'] : 0;
					if ( ! $aid ) {
						continue;
					}
					echo self::doc_row( $name, $i, $aid, ! empty( $doc['gated'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in doc_row().
				}
				echo '</tbody></table><p><button type="button" class="button axis-cre-docs-field__add">' . esc_html__( 'Add documents', 'axis-cre' ) . '</button></p>' . $help . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- As above.
				break;

			default:
				$input   = array(
					'date'  => 'date',
					'email' => 'email',
					'url'   => 'url',
				);
				$numeric = in_array( $type, array( 'number', 'money', 'percent', 'integer' ), true );
				echo '<label for="' . esc_attr( $id ) . '">' . esc_html( $field['label'] ) . '</label>';
				echo '<input type="' . esc_attr( isset( $input[ $type ] ) ? $input[ $type ] : 'text' ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( is_scalar( $value ) ? (string) $value : '' ) . '"' . ( $numeric ? ' inputmode="decimal"' : '' ) . ( 'number' === $key ? ' readonly' : '' ) . ' class="' . ( $numeric ? 'small-text' : 'regular-text' ) . '"' . $desc . '>' . $help; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- As above.
		}

		echo '</div>';
	}

	/**
	 * Media list item.
	 *
	 * @param int $aid Attachment ID.
	 * @return string
	 */
	private static function media_item( $aid ) {
		if ( ! get_post( $aid ) ) {
			return '';
		}
		$thumb = wp_attachment_is_image( $aid ) ? wp_get_attachment_image( $aid, 'thumbnail', false, array( 'alt' => '' ) ) : '<span class="dashicons dashicons-media-default" aria-hidden="true"></span>';
		$title = get_the_title( $aid );
		/* translators: %s: file name. */
		return '<li data-id="' . (int) $aid . '">' . $thumb . '<span class="axis-cre-media__name">' . esc_html( $title ) . '</span><button type="button" class="button-link axis-cre-media__remove">' . esc_html__( 'Remove', 'axis-cre' ) . '<span class="screen-reader-text"> ' . esc_html( $title ) . '</span></button></li>';
	}

	/**
	 * Document table row.
	 *
	 * @param string $name  Field name.
	 * @param int    $i     Row index.
	 * @param int    $aid   Attachment ID.
	 * @param bool   $gated Gated.
	 * @return string
	 */
	private static function doc_row( $name, $i, $aid, $gated ) {
		$title = get_the_title( $aid );
		$base  = $name . '[' . $i . ']';
		return '<tr><td><input type="hidden" name="' . esc_attr( $base . '[id]' ) . '" value="' . (int) $aid . '">' . esc_html( $title ) . '</td>'
			. '<td><label><input type="checkbox" name="' . esc_attr( $base . '[gated]' ) . '" value="1"' . checked( $gated, true, false ) . '><span class="screen-reader-text">' . esc_html(
				/* translators: %s: document name. */
				sprintf( __( 'Gate %s', 'axis-cre' ), $title )
			) . '</span></label></td>'
			. '<td><button type="button" class="button-link axis-cre-docs-field__remove">' . esc_html__( 'Remove', 'axis-cre' ) . '<span class="screen-reader-text"> ' . esc_html( $title ) . '</span></button></td></tr>';
	}

	/**
	 * Post choices for a relationship field.
	 *
	 * @param string $type Post type.
	 * @return array<int, string>
	 */
	private static function choices( $type ) {
		static $cache = array();
		if ( isset( $cache[ $type ] ) ) {
			return $cache[ $type ];
		}
		$posts = get_posts(
			array(
				'post_type'      => $type,
				'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
				'posts_per_page' => 500,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		$out   = array();
		foreach ( $posts as $p ) {
			$out[ (int) $p->ID ] = $p->post_title ? $p->post_title : __( '(no title)', 'axis-cre' );
		}
		$cache[ $type ] = $out;
		return $out;
	}

	/**
	 * Save the details box.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post.
	 */
	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST[ self::NONCE ] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST[ self::NONCE ] ) ), self::NONCE ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$defs = Fields::definitions();
		if ( empty( $defs[ $post->post_type ] ) ) {
			return;
		}
		// Each value is sanitised by type in Fields::sanitize().
		$input = isset( $_POST['axis_cre'] ) && is_array( $_POST['axis_cre'] ) ? wp_unslash( $_POST['axis_cre'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		foreach ( $defs[ $post->post_type ] as $key => $field ) {
			if ( 'number' === $key ) {
				continue;
			}
			$type = $field['type'];
			if ( 'boolean' === $type ) {
				$value = ! empty( $input[ $key ] );
			} elseif ( 'documents' === $type ) {
				$value = isset( $input[ $key ] ) ? array_values( (array) $input[ $key ] ) : array();
			} elseif ( ! array_key_exists( $key, $input ) ) {
				continue;
			} else {
				$value = $input[ $key ];
			}
			$clean = Fields::sanitize( $type, $value );
			$meta  = Fields::meta_key( $key );
			if ( '' === $clean || array() === $clean || false === $clean ) {
				delete_post_meta( $post_id, $meta );
			} else {
				update_post_meta( $post_id, $meta, $clean );
			}
		}
	}

	/**
	 * Identifier column on list screens.
	 *
	 * @param array<string, string> $cols Columns.
	 * @return array<string, string>
	 */
	public static function columns( $cols ) {
		$out = array();
		foreach ( $cols as $k => $v ) {
			if ( 'title' === $k ) {
				$out['axis_id'] = __( 'ID', 'axis-cre' );
			}
			$out[ $k ] = $v;
		}
		return $out;
	}

	/**
	 * Column content.
	 *
	 * @param string $col     Column.
	 * @param int    $post_id Post ID.
	 */
	public static function column( $col, $post_id ) {
		if ( 'axis_id' === $col ) {
			echo esc_html( Format::id( get_post_type( $post_id ), Fields::get( $post_id, 'number' ) ) );
		}
	}

	/**
	 * Settings and tools pages.
	 */
	public static function menu() {
		add_options_page( __( 'AXIS CRE', 'axis-cre' ), __( 'AXIS CRE', 'axis-cre' ), 'manage_options', 'axis-cre', array( __CLASS__, 'settings_page' ) );
	}

	/**
	 * Register the setting.
	 */
	public static function settings() {
		register_setting(
			'axis_cre',
			'axis_cre_settings',
			array(
				'type'              => 'object',
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
				'default'           => array(
					'currency' => '$',
					'area'     => 'sf',
				),
			)
		);
	}

	/**
	 * Sanitise settings.
	 *
	 * @param mixed $value Raw.
	 * @return array{currency: string, area: string, shortlist: int}
	 */
	public static function sanitize_settings( $value ) {
		$value = (array) $value;
		$cur   = isset( $value['currency'] ) ? mb_substr( sanitize_text_field( $value['currency'] ), 0, 4 ) : '$';
		$page  = isset( $value['shortlist'] ) ? absint( $value['shortlist'] ) : 0;
		return array(
			'currency'  => '' === $cur ? '$' : $cur,
			'area'      => isset( $value['area'] ) && 'sqm' === $value['area'] ? 'sqm' : 'sf',
			'shortlist' => $page && 'page' === get_post_type( $page ) ? $page : 0,
		);
	}

	/**
	 * Settings page.
	 */
	public static function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s = Format::settings();
		echo '<div class="wrap axis-cre-settings"><h1>' . esc_html__( 'AXIS CRE settings', 'axis-cre' ) . '</h1>';
		echo '<form method="post" action="options.php">';
		settings_fields( 'axis_cre' );
		echo '<table class="form-table" role="presentation"><tbody>';
		echo '<tr><th scope="row"><label for="axis-cre-currency">' . esc_html__( 'Currency symbol', 'axis-cre' ) . '</label></th><td><input id="axis-cre-currency" name="axis_cre_settings[currency]" type="text" class="small-text" maxlength="4" value="' . esc_attr( $s['currency'] ) . '" aria-describedby="axis-cre-currency-help"><p class="description" id="axis-cre-currency-help">' . esc_html__( 'Shown before prices and rents, for example $ or €.', 'axis-cre' ) . '</p></td></tr>';
		echo '<tr><th scope="row">' . esc_html__( 'Area unit', 'axis-cre' ) . '</th><td><fieldset><legend class="screen-reader-text">' . esc_html__( 'Area unit', 'axis-cre' ) . '</legend>';
		echo '<label><input type="radio" name="axis_cre_settings[area]" value="sf"' . checked( $s['area'], 'sf', false ) . '> ' . esc_html__( 'Square feet', 'axis-cre' ) . '</label><br>';
		echo '<label><input type="radio" name="axis_cre_settings[area]" value="sqm"' . checked( $s['area'], 'sqm', false ) . '> ' . esc_html__( 'Square metres', 'axis-cre' ) . '</label>';
		echo '<p class="description">' . esc_html__( 'Changes the label only. Enter building areas and rents in the unit you choose here.', 'axis-cre' ) . '</p></fieldset></td></tr>';
		echo '<tr><th scope="row"><label for="axis-cre-shortlist">' . esc_html__( 'Shortlist page', 'axis-cre' ) . '</label></th><td>';
		wp_dropdown_pages(
			array(
				'name'              => 'axis_cre_settings[shortlist]',
				'id'                => 'axis-cre-shortlist',
				'selected'          => (int) $s['shortlist'],
				'show_option_none'  => esc_html__( 'None', 'axis-cre' ),
				'option_none_value' => '0',
			)
		);
		echo '<p class="description" id="axis-cre-shortlist-help">' . esc_html__( 'The page that holds the Shortlist block. Saved listings and the compare tray link here.', 'axis-cre' ) . '</p></td></tr>';
		echo '</tbody></table>';
		submit_button();
		echo '</form>';
		echo '<h2>' . esc_html__( 'Sample content', 'axis-cre' ) . '</h2><p>' . esc_html__( 'Create six markets with properties, transactions, experts and research to see every template filled in.', 'axis-cre' ) . ' <a href="' . esc_url( admin_url( 'tools.php?page=axis-cre-sample' ) ) . '">' . esc_html__( 'Go to sample content', 'axis-cre' ) . '</a></p>';
		echo '</div>';
	}

	/**
	 * Settings link on the Plugins screen.
	 *
	 * @param string[] $links Links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=axis-cre' ) ) . '">' . esc_html__( 'Settings', 'axis-cre' ) . '</a>' );
		return $links;
	}
}
