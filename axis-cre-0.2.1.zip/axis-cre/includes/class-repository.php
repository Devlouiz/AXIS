<?php
/**
 * Data access: queries and shaped records for rendering.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Reads AXIS content and shapes it for templates, blocks and REST.
 */
class Repository {

	/**
	 * Per-request cache of shaped records.
	 *
	 * @var array<string, array<string, mixed>>
	 */
	private static $cache = array();

	/**
	 * Load posts, their meta and terms in a few queries instead of one per post,
	 * then the images and people they point to.
	 *
	 * @param int[] $ids Post IDs.
	 */
	public static function prime( $ids ) {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', (array) $ids ) ) ) );
		if ( ! $ids ) {
			return;
		}
		_prime_post_caches( $ids, true, true );
		$linked = array();
		foreach ( $ids as $id ) {
			$linked[] = (int) get_post_meta( $id, '_thumbnail_id', true );
			foreach ( array( 'gallery', 'experts' ) as $key ) {
				$linked = array_merge( $linked, array_map( 'intval', (array) get_post_meta( $id, Fields::meta_key( $key ), true ) ) );
			}
		}
		$linked = array_values( array_diff( array_unique( array_filter( $linked ) ), $ids ) );
		if ( $linked ) {
			_prime_post_caches( $linked, false, true );
			$faces = array();
			foreach ( $linked as $id ) {
				$faces[] = (int) get_post_meta( $id, '_thumbnail_id', true );
			}
			$faces = array_values( array_diff( array_unique( array_filter( $faces ) ), $linked, $ids ) );
			if ( $faces ) {
				_prime_post_caches( $faces, false, true );
			}
		}
	}

	/**
	 * First term of a taxonomy on a post.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $taxonomy Taxonomy.
	 * @return \WP_Term|null
	 */
	public static function term( $post_id, $taxonomy ) {
		$terms = get_the_terms( $post_id, $taxonomy );
		return ( $terms && ! is_wp_error( $terms ) ) ? $terms[0] : null;
	}

	/**
	 * Shaped property record.
	 *
	 * @param int $id Post ID.
	 * @return array<string, mixed>|null
	 */
	public static function property( $id ) {
		$key = 'p' . $id;
		if ( isset( self::$cache[ $key ] ) ) {
			return self::$cache[ $key ];
		}
		$post = get_post( $id );
		if ( ! $post || Post_Types::PROPERTY !== $post->post_type ) {
			return null;
		}
		$f       = function ( $k ) use ( $id ) {
			return Fields::get( $id, $k );
		};
		$type    = self::term( $id, 'axis_property_type' );
		$listing = self::term( $id, 'axis_listing_type' );
		$size    = $f( 'size' );
		$price   = $f( 'sale_price' );
		$lease   = $f( 'lease_rate' );
		$city    = trim( implode( ', ', array_filter( array( $f( 'city' ), $f( 'region' ) ) ) ) );
		$class   = $f( 'asset_class' );
		$type_nm = $type ? $type->name : '';

		$line = $type_nm;
		if ( $class ) {
			$line = $line ? $line . ', ' . $class : $class;
		}
		if ( $city ) {
			$line = $line ? $line . '. ' . $city : $city;
		}

		$record = array(
			'id'          => $id,
			'title'       => get_the_title( $id ),
			'url'         => get_permalink( $id ),
			'number'      => (int) $f( 'number' ),
			'label'       => Format::id( Post_Types::PROPERTY, $f( 'number' ) ),
			'type'        => $type ? $type->slug : '',
			'type_name'   => $type_nm,
			'status'      => $listing ? $listing->name : '',
			'status_slug' => $listing ? $listing->slug : '',
			'class'       => $class,
			'class_line'  => $line,
			'city'        => $city,
			'address'     => $f( 'address' ),
			'lat'         => is_numeric( $f( 'lat' ) ) ? (float) $f( 'lat' ) : null,
			'lng'         => is_numeric( $f( 'lng' ) ) ? (float) $f( 'lng' ) : null,
			'market'      => (int) $f( 'market' ),
			'size'        => is_numeric( $size ) ? (float) $size : null,
			'occupancy'   => is_numeric( $f( 'occupancy' ) ) ? (float) $f( 'occupancy' ) : null,
			'price'       => is_numeric( $price ) ? (float) $price : null,
			'lease'       => is_numeric( $lease ) ? (float) $lease : null,
			'cap'         => is_numeric( $f( 'cap_rate' ) ) ? (float) $f( 'cap_rate' ) : null,
			'featured'    => (bool) $f( 'featured' ),
			'listed'      => $f( 'listed' ),
			'image'       => (int) get_post_thumbnail_id( $id ),
			'floor'       => is_numeric( $f( 'typical_floor' ) ) ? (float) $f( 'typical_floor' ) : null,
			'units'       => (int) $f( 'units' ),
			'year'        => (int) $f( 'year_built' ),
			'experts'     => array_values( array_filter( array_map( 'intval', (array) $f( 'experts' ) ) ) ),
		);

		// Photos for the card: featured image first, then the gallery, five at most.
		$photos           = array_merge( array( $record['image'] ), array_map( 'intval', (array) $f( 'gallery' ) ) );
		$photos           = array_values( array_unique( array_filter( $photos, 'wp_attachment_is_image' ) ) );
		$record['photos'] = array_slice( $photos, 0, 5 );
		if ( ! $record['image'] && $record['photos'] ) {
			$record['image'] = $record['photos'][0];
		}

		// Listing broker: the first expert, kept light to avoid computing a track record here.
		$record['broker'] = null;
		if ( $record['experts'] && get_post( $record['experts'][0] ) ) {
			$bid              = $record['experts'][0];
			$record['broker'] = array(
				'id'    => $bid,
				'title' => get_the_title( $bid ),
				'url'   => get_permalink( $bid ),
				'image' => (int) get_post_thumbnail_id( $bid ),
			);
		}

		// Market name, for the location line and search.
		$record['market_name'] = $record['market'] ? get_the_title( $record['market'] ) : '';
		$record['search']      = strtolower( implode( ' ', array_filter( array( $record['title'], $record['address'], $record['city'], $record['market_name'], $type_nm ) ) ) );

		$record['metrics'] = array_values(
			array_filter(
				array(
					array( Format::area( $record['size'] ), __( 'Building', 'axis-cre' ) ),
					array( Format::percent( $record['occupancy'] ), __( 'Occupied', 'axis-cre' ) ),
					$record['price'] ? array( Format::money( $record['price'] ), __( 'Asking', 'axis-cre' ) ) : array( Format::rent( $record['lease'] ), __( 'Lease rate', 'axis-cre' ) ),
					array( Format::percent( $record['cap'] ), __( 'Cap rate', 'axis-cre' ) ),
				),
				function ( $m ) {
					return '' !== $m[0];
				}
			)
		);

		self::$cache[ $key ] = $record;
		return $record;
	}

	/**
	 * Query properties.
	 *
	 * @param array<string, mixed> $args Filters: type, market, listing, min_size, max_size, min_price, max_price, min_cap, featured, per_page, page, exclude, ids.
	 * @return array{items: array<int, array<string, mixed>>, total: int, pages: int}
	 */
	public static function properties( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'type'      => '',
				'market'    => 0,
				'listing'   => '',
				'min_size'  => '',
				'max_size'  => '',
				'min_price' => '',
				'max_price' => '',
				'min_cap'   => '',
				'min_rent'  => '',
				'max_rent'  => '',
				'q'         => '',
				'featured'  => false,
				'per_page'  => 12,
				'page'      => 1,
				'exclude'   => array(),
				'ids'       => array(),
			)
		);

		$query = array(
			'post_type'      => Post_Types::PROPERTY,
			'post_status'    => 'publish',
			'posts_per_page' => (int) $args['per_page'],
			'paged'          => max( 1, (int) $args['page'] ),
			'post__not_in'   => array_map( 'absint', (array) $args['exclude'] ),
			'orderby'        => array(
				'menu_order' => 'ASC',
				'date'       => 'DESC',
			),
			'fields'         => 'ids',
		);
		if ( $args['ids'] ) {
			$query['post__in'] = array_map( 'absint', (array) $args['ids'] );
			$query['orderby']  = 'post__in';
		}
		if ( '' !== $args['q'] ) {
			$found             = self::search_properties( $args['q'] );
			$query['post__in'] = $args['ids'] ? array_values( array_intersect( $query['post__in'], $found ) ) : $found;
			if ( ! $query['post__in'] ) {
				$query['post__in'] = array( 0 );
			}
		}

		$tax = array();
		if ( $args['type'] ) {
			$tax[] = array(
				'taxonomy' => 'axis_property_type',
				'field'    => 'slug',
				'terms'    => (array) $args['type'],
			);
		}
		if ( $args['listing'] ) {
			$tax[] = array(
				'taxonomy' => 'axis_listing_type',
				'field'    => 'slug',
				'terms'    => (array) $args['listing'],
			);
		}
		if ( $tax ) {
			$query['tax_query'] = $tax; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Filtered listing query.
		}

		$meta = array();
		if ( $args['market'] ) {
			$meta[] = array(
				'key'   => Fields::meta_key( 'market' ),
				'value' => absint( $args['market'] ),
			);
		}
		$ranges = array(
			'min_size'  => array( 'size', '>=' ),
			'max_size'  => array( 'size', '<=' ),
			'min_price' => array( 'sale_price', '>=' ),
			'max_price' => array( 'sale_price', '<=' ),
			'min_cap'   => array( 'cap_rate', '>=' ),
			'min_rent'  => array( 'lease_rate', '>=' ),
			'max_rent'  => array( 'lease_rate', '<=' ),
		);
		foreach ( $ranges as $arg => $spec ) {
			if ( '' !== $args[ $arg ] && is_numeric( $args[ $arg ] ) ) {
				$meta[] = array(
					'key'     => Fields::meta_key( $spec[0] ),
					'value'   => (float) $args[ $arg ],
					'compare' => $spec[1],
					'type'    => 'DECIMAL(20,4)',
				);
			}
		}
		if ( $args['featured'] ) {
			$meta[] = array(
				'key'   => Fields::meta_key( 'featured' ),
				'value' => '1',
			);
		}
		if ( $meta ) {
			$query['meta_query'] = $meta; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Filtered listing query.
		}

		$q = new \WP_Query( $query );
		self::prime( $q->posts );
		$items = array_values( array_filter( array_map( array( __CLASS__, 'property' ), $q->posts ) ) );

		return array(
			'items' => $items,
			'total' => (int) $q->found_posts,
			'pages' => (int) $q->max_num_pages,
		);
	}

	/**
	 * Property IDs whose title, address, city or market matches a phrase.
	 *
	 * @param string $q Phrase.
	 * @return int[]
	 */
	public static function search_properties( $q ) {
		$q = strtolower( trim( (string) $q ) );
		if ( '' === $q ) {
			return array();
		}
		$ids = get_posts(
			array(
				'post_type'      => Post_Types::PROPERTY,
				'post_status'    => 'publish',
				'posts_per_page' => 500,
				'fields'         => 'ids',
			)
		);
		self::prime( $ids );
		$out = array();
		foreach ( $ids as $id ) {
			$p = self::property( $id );
			if ( $p && false !== strpos( $p['search'], $q ) ) {
				$out[] = (int) $id;
			}
		}
		return $out;
	}

	/**
	 * Shaped market record, including parsed data lines.
	 *
	 * @param int $id Post ID.
	 * @return array<string, mixed>|null
	 */
	public static function market( $id ) {
		$key = 'm' . $id;
		if ( isset( self::$cache[ $key ] ) ) {
			return self::$cache[ $key ];
		}
		$post = $id ? get_post( $id ) : null;
		if ( ! $post || Post_Types::MARKET !== $post->post_type ) {
			return null;
		}

		$sectors = array();
		foreach ( Fields::parse_lines( Fields::get( $id, 'sectors' ) ) as $row ) {
			$sectors[] = array(
				'name'    => $row[0],
				'slug'    => sanitize_title( $row[0] ),
				'rent'    => isset( $row[1] ) && is_numeric( $row[1] ) ? (float) $row[1] : null,
				'unit'    => isset( $row[2] ) ? $row[2] : '',
				'vacancy' => isset( $row[3] ) && is_numeric( $row[3] ) ? (float) $row[3] : null,
				'change'  => isset( $row[4] ) && is_numeric( $row[4] ) ? (float) $row[4] : null,
			);
		}
		$submarkets = array();
		foreach ( Fields::parse_lines( Fields::get( $id, 'submarkets' ) ) as $row ) {
			$submarkets[] = array(
				'name'    => $row[0],
				'vacancy' => isset( $row[1] ) && is_numeric( $row[1] ) ? (float) $row[1] : null,
				'lat'     => isset( $row[2] ) && is_numeric( $row[2] ) ? (float) $row[2] : null,
				'lng'     => isset( $row[3] ) && is_numeric( $row[3] ) ? (float) $row[3] : null,
			);
		}
		$trend = array();
		foreach ( Fields::parse_lines( Fields::get( $id, 'rent_trend' ) ) as $row ) {
			if ( isset( $row[1] ) && is_numeric( $row[1] ) ) {
				$trend[] = array( $row[0], (float) $row[1] );
			}
		}

		$record = array(
			'id'         => $id,
			'title'      => get_the_title( $id ),
			'url'        => get_permalink( $id ),
			'label'      => Format::id( Post_Types::MARKET, Fields::get( $id, 'number' ) ),
			'country'    => Fields::get( $id, 'country' ),
			'lat'        => is_numeric( Fields::get( $id, 'lat' ) ) ? (float) Fields::get( $id, 'lat' ) : null,
			'lng'        => is_numeric( Fields::get( $id, 'lng' ) ) ? (float) Fields::get( $id, 'lng' ) : null,
			'quarter'    => Fields::get( $id, 'quarter' ),
			'sectors'    => $sectors,
			'submarkets' => $submarkets,
			'trend'      => $trend,
			'trend_name' => Fields::get( $id, 'trend_label' ),
			'volume'     => Fields::get( $id, 'volume' ),
			'since'      => (int) Fields::get( $id, 'since_year' ),
		);

		self::$cache[ $key ] = $record;
		return $record;
	}

	/**
	 * All published markets, in menu order.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function markets() {
		$ids = get_posts(
			array(
				'post_type'      => Post_Types::MARKET,
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'orderby'        => array(
					'menu_order' => 'ASC',
					'title'      => 'ASC',
				),
				'fields'         => 'ids',
			)
		);
		self::prime( $ids );
		return array_values( array_filter( array_map( array( __CLASS__, 'market' ), $ids ) ) );
	}

	/**
	 * The market that applies to a post: itself, its linked market, or the first market.
	 *
	 * @param int $post_id Post ID, or 0 for the default market.
	 * @return array<string, mixed>|null
	 */
	public static function market_for( $post_id ) {
		$type = $post_id ? get_post_type( $post_id ) : '';
		if ( Post_Types::MARKET === $type ) {
			return self::market( $post_id );
		}
		if ( in_array( $type, array( Post_Types::PROPERTY, Post_Types::TRANSACTION ), true ) ) {
			$m = (int) Fields::get( $post_id, 'market' );
			if ( $m ) {
				return self::market( $m );
			}
		}
		if ( in_array( $type, array( Post_Types::EXPERT, Post_Types::RESEARCH ), true ) ) {
			$ms = (array) Fields::get( $post_id, 'markets' );
			if ( ! empty( $ms[0] ) ) {
				return self::market( (int) $ms[0] );
			}
		}
		$all = self::markets();
		return $all ? $all[0] : null;
	}

	/**
	 * Shaped transaction record.
	 *
	 * @param int $id Post ID.
	 * @return array<string, mixed>|null
	 */
	public static function transaction( $id ) {
		$post = get_post( $id );
		if ( ! $post || Post_Types::TRANSACTION !== $post->post_type ) {
			return null;
		}
		$deal  = self::term( $id, 'axis_transaction_type' );
		$type  = self::term( $id, 'axis_property_type' );
		$year  = Fields::get( $id, 'year' );
		$city  = Fields::get( $id, 'city' );
		$parts = array_filter( array( $deal ? $deal->name : '', $city, $year ? (string) $year : '' ) );
		return array(
			'id'        => $id,
			'title'     => get_the_title( $id ),
			'url'       => get_permalink( $id ),
			'label'     => Format::id( Post_Types::TRANSACTION, Fields::get( $id, 'number' ) ),
			'value'     => Fields::get( $id, 'value' ),
			'value_fmt' => Format::money( Fields::get( $id, 'value' ) ),
			'deal'      => $deal ? $deal->name : '',
			'deal_slug' => $deal ? $deal->slug : '',
			'type'      => $type ? $type->slug : '',
			'type_name' => $type ? $type->name : '',
			'city'      => $city,
			'year'      => $year,
			'line'      => implode( '. ', $parts ),
			'client'    => Fields::get( $id, 'client' ),
			'role'      => Fields::get( $id, 'role' ),
			'market'    => (int) Fields::get( $id, 'market' ),
			'property'  => (int) Fields::get( $id, 'property' ),
			'experts'   => array_map( 'intval', (array) Fields::get( $id, 'experts' ) ),
			'story'     => array_filter(
				array(
					__( 'The asset', 'axis-cre' )       => Fields::get( $id, 'story_asset' ),
					__( 'The transaction', 'axis-cre' ) => Fields::get( $id, 'story_deal' ),
					__( 'The strategy', 'axis-cre' )    => Fields::get( $id, 'story_plan' ),
					__( 'The outcome', 'axis-cre' )     => Fields::get( $id, 'story_result' ),
				)
			),
		);
	}

	/**
	 * Query transactions.
	 *
	 * @param array<string, mixed> $args Filters: expert, market, year, deal, type, per_page, page, exclude.
	 * @return array{items: array<int, array<string, mixed>>, total: int, pages: int}
	 */
	public static function transactions( $args = array() ) {
		$args  = wp_parse_args(
			$args,
			array(
				'expert'   => 0,
				'market'   => 0,
				'year'     => 0,
				'deal'     => '',
				'type'     => '',
				'per_page' => 3,
				'page'     => 1,
				'exclude'  => array(),
			)
		);
		$query = array(
			'post_type'      => Post_Types::TRANSACTION,
			'post_status'    => 'publish',
			'posts_per_page' => (int) $args['per_page'],
			'paged'          => max( 1, (int) $args['page'] ),
			'post__not_in'   => array_map( 'absint', (array) $args['exclude'] ),
			'fields'         => 'ids',
		);
		$meta  = array();
		if ( $args['market'] ) {
			$meta[] = array(
				'key'   => Fields::meta_key( 'market' ),
				'value' => absint( $args['market'] ),
			);
		}
		if ( $args['year'] ) {
			$meta[] = array(
				'key'   => Fields::meta_key( 'year' ),
				'value' => absint( $args['year'] ),
			);
		}
		if ( $meta ) {
			$query['meta_query'] = $meta; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Filtered listing query.
		}
		$tax = array();
		if ( $args['deal'] ) {
			$tax[] = array(
				'taxonomy' => 'axis_transaction_type',
				'field'    => 'slug',
				'terms'    => (array) $args['deal'],
			);
		}
		if ( $args['type'] ) {
			$tax[] = array(
				'taxonomy' => 'axis_property_type',
				'field'    => 'slug',
				'terms'    => (array) $args['type'],
			);
		}
		if ( $tax ) {
			$query['tax_query'] = $tax; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Filtered listing query.
		}

		if ( $args['expert'] ) {
			// Experts are stored as a serialised list; filter in PHP rather than LIKE on meta.
			$all = get_posts(
				array_merge(
					$query,
					array(
						'posts_per_page' => 500,
						'paged'          => 1,
					)
				)
			);
			self::prime( $all );
			$ids   = array_values(
				array_filter(
					$all,
					function ( $tid ) use ( $args ) {
						return in_array( (int) $args['expert'], array_map( 'intval', (array) Fields::get( $tid, 'experts' ) ), true );
					}
				)
			);
			$total = count( $ids );
			$ids   = array_slice( $ids, ( max( 1, (int) $args['page'] ) - 1 ) * (int) $args['per_page'], (int) $args['per_page'] );
			return array(
				'items' => array_values( array_filter( array_map( array( __CLASS__, 'transaction' ), $ids ) ) ),
				'total' => $total,
				'pages' => (int) ceil( $total / max( 1, (int) $args['per_page'] ) ),
			);
		}

		$q = new \WP_Query( $query );
		self::prime( $q->posts );
		return array(
			'items' => array_values( array_filter( array_map( array( __CLASS__, 'transaction' ), $q->posts ) ) ),
			'total' => (int) $q->found_posts,
			'pages' => (int) $q->max_num_pages,
		);
	}

	/**
	 * Shaped expert record with a computed track record.
	 *
	 * @param int $id Post ID.
	 * @return array<string, mixed>|null
	 */
	public static function expert( $id ) {
		$key = 'e' . $id;
		if ( isset( self::$cache[ $key ] ) ) {
			return self::$cache[ $key ];
		}
		$post = get_post( $id );
		if ( ! $post || Post_Types::EXPERT !== $post->post_type ) {
			return null;
		}
		$markets = array_filter( array_map( array( __CLASS__, 'market' ), array_map( 'intval', (array) Fields::get( $id, 'markets' ) ) ) );
		$title   = Fields::get( $id, 'title' );
		$mnames  = implode( ', ', wp_list_pluck( $markets, 'title' ) );
		$deals   = Fields::get( $id, 'deals' );
		$volume  = Fields::get( $id, 'volume' );

		if ( '' === $deals || '' === $volume ) {
			$tx = self::transactions(
				array(
					'expert'   => $id,
					'per_page' => 500,
				)
			);
			if ( '' === $deals ) {
				$deals = $tx['total'];
			}
			if ( '' === $volume ) {
				$volume = array_sum( array_map( 'floatval', wp_list_pluck( $tx['items'], 'value' ) ) );
			}
		}

		$types  = get_the_terms( $id, 'axis_property_type' );
		$record = array(
			'id'          => $id,
			'title'       => get_the_title( $id ),
			'url'         => get_permalink( $id ),
			'label'       => Format::id( Post_Types::EXPERT, Fields::get( $id, 'number' ) ),
			'job'         => $title,
			'role_line'   => implode( '. ', array_filter( array( $title, $mnames ) ) ),
			'markets'     => $markets,
			'specialties' => array_filter( array_map( 'trim', explode( ',', (string) Fields::get( $id, 'specialties' ) ) ) ),
			'types'       => ( $types && ! is_wp_error( $types ) ) ? wp_list_pluck( $types, 'name' ) : array(),
			'phone'       => Fields::get( $id, 'phone' ),
			'email'       => Fields::get( $id, 'email' ),
			'linkedin'    => Fields::get( $id, 'linkedin' ),
			'since'       => (int) Fields::get( $id, 'since' ),
			'deals'       => (int) $deals,
			'volume'      => (float) $volume,
			'image'       => (int) get_post_thumbnail_id( $id ),
		);

		self::$cache[ $key ] = $record;
		return $record;
	}

	/**
	 * Query experts.
	 *
	 * @param array<string, mixed> $args Filters: market, type, service, per_page, page, ids.
	 * @return array{items: array<int, array<string, mixed>>, total: int, pages: int}
	 */
	public static function experts( $args = array() ) {
		$args  = wp_parse_args(
			$args,
			array(
				'market'   => 0,
				'type'     => '',
				'service'  => '',
				'per_page' => 4,
				'page'     => 1,
				'ids'      => array(),
			)
		);
		$query = array(
			'post_type'      => Post_Types::EXPERT,
			'post_status'    => 'publish',
			'posts_per_page' => 500,
			'orderby'        => array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			),
			'fields'         => 'ids',
		);
		if ( $args['ids'] ) {
			$query['post__in'] = array_map( 'absint', (array) $args['ids'] );
			$query['orderby']  = 'post__in';
		}
		$tax = array();
		foreach ( array(
			'type'    => 'axis_property_type',
			'service' => 'axis_service',
		) as $arg => $taxonomy ) {
			if ( $args[ $arg ] ) {
				$tax[] = array(
					'taxonomy' => $taxonomy,
					'field'    => 'slug',
					'terms'    => (array) $args[ $arg ],
				);
			}
		}
		if ( $tax ) {
			$query['tax_query'] = $tax; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Filtered directory query.
		}
		$ids = get_posts( $query );
		self::prime( $ids );
		if ( $args['market'] ) {
			$ids = array_values(
				array_filter(
					$ids,
					function ( $eid ) use ( $args ) {
						return in_array( (int) $args['market'], array_map( 'intval', (array) Fields::get( $eid, 'markets' ) ), true );
					}
				)
			);
		}
		$total = count( $ids );
		$per   = max( 1, (int) $args['per_page'] );
		$ids   = array_slice( $ids, ( max( 1, (int) $args['page'] ) - 1 ) * $per, $per );
		return array(
			'items' => array_values( array_filter( array_map( array( __CLASS__, 'expert' ), $ids ) ) ),
			'total' => $total,
			'pages' => (int) ceil( $total / $per ),
		);
	}

	/**
	 * Shaped research record.
	 *
	 * @param int $id Post ID.
	 * @return array<string, mixed>|null
	 */
	public static function research( $id ) {
		$post = get_post( $id );
		if ( ! $post || Post_Types::RESEARCH !== $post->post_type ) {
			return null;
		}
		$type    = self::term( $id, 'axis_research_type' );
		$markets = array_filter( array_map( array( __CLASS__, 'market' ), array_map( 'intval', (array) Fields::get( $id, 'markets' ) ) ) );
		$pdf     = (array) Fields::get( $id, 'pdf' );
		$data    = (array) Fields::get( $id, 'data' );
		$pages   = (int) Fields::get( $id, 'pages' );
		$figures = array();
		foreach ( Fields::parse_lines( Fields::get( $id, 'figures' ) ) as $row ) {
			$figures[] = array(
				'value' => $row[0],
				'label' => isset( $row[1] ) ? $row[1] : '',
				'note'  => isset( $row[2] ) ? $row[2] : '',
			);
		}
		$context = implode( ', ', wp_list_pluck( $markets, 'title' ) );
		$date    = get_the_date( _x( 'F Y', 'research card date', 'axis-cre' ), $id );

		return array(
			'id'      => $id,
			'title'   => get_the_title( $id ),
			'url'     => get_permalink( $id ),
			'label'   => Format::id( Post_Types::RESEARCH, Fields::get( $id, 'number' ) ),
			'type'    => $type ? $type->name : '',
			'brief'   => $type && in_array( $type->slug, array( 'data-brief', 'perspective' ), true ),
			'context' => implode( '. ', array_filter( array( $context, $date ) ) ),
			/* translators: 1: publication date, 2: number of pages. */
			'meta'    => $pages ? sprintf( __( 'Published %1$s. %2$d pages', 'axis-cre' ), get_the_date( '', $id ), $pages ) : sprintf(
				/* translators: %s: publication date. */
				__( 'Published %s', 'axis-cre' ),
				get_the_date( '', $id )
			),
			'pages'   => $pages,
			'pdf'     => ! empty( $pdf[0] ) ? (int) $pdf[0] : 0,
			'data'    => ! empty( $data[0] ) ? (int) $data[0] : 0,
			'figures' => $figures,
			'markets' => $markets,
			'experts' => array_map( 'intval', (array) Fields::get( $id, 'experts' ) ),
		);
	}

	/**
	 * Query research.
	 *
	 * @param array<string, mixed> $args Filters: type, market, expert, year, per_page, page, exclude.
	 * @return array{items: array<int, array<string, mixed>>, total: int, pages: int}
	 */
	public static function research_items( $args = array() ) {
		$args  = wp_parse_args(
			$args,
			array(
				'type'     => '',
				'market'   => 0,
				'expert'   => 0,
				'year'     => 0,
				'per_page' => 3,
				'page'     => 1,
				'exclude'  => array(),
			)
		);
		$query = array(
			'post_type'      => Post_Types::RESEARCH,
			'post_status'    => 'publish',
			'posts_per_page' => 500,
			'post__not_in'   => array_map( 'absint', (array) $args['exclude'] ),
			'fields'         => 'ids',
		);
		if ( $args['type'] ) {
			$query['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Filtered archive query.
				array(
					'taxonomy' => 'axis_research_type',
					'field'    => 'slug',
					'terms'    => (array) $args['type'],
				),
			);
		}
		if ( $args['year'] ) {
			$query['year'] = absint( $args['year'] );
		}
		$ids = get_posts( $query );
		self::prime( $ids );
		foreach ( array(
			'market' => 'markets',
			'expert' => 'experts',
		) as $arg => $field ) {
			if ( $args[ $arg ] ) {
				$ids = array_values(
					array_filter(
						$ids,
						function ( $rid ) use ( $args, $arg, $field ) {
							return in_array( (int) $args[ $arg ], array_map( 'intval', (array) Fields::get( $rid, $field ) ), true );
						}
					)
				);
			}
		}
		$total = count( $ids );
		$per   = max( 1, (int) $args['per_page'] );
		$ids   = array_slice( $ids, ( max( 1, (int) $args['page'] ) - 1 ) * $per, $per );
		return array(
			'items' => array_values( array_filter( array_map( array( __CLASS__, 'research' ), $ids ) ) ),
			'total' => $total,
			'pages' => (int) ceil( $total / $per ),
		);
	}

	/**
	 * Count of published items of a type linked to a market.
	 *
	 * @param string $type   Post type.
	 * @param int    $market Market ID.
	 * @param string $field  Meta field linking to the market.
	 * @return int
	 */
	public static function count_in_market( $type, $market, $field = 'market' ) {
		static $counts = array();
		$key           = $type . '|' . $field;
		if ( ! isset( $counts[ $key ] ) ) {
			// Count every market once per request; maps and tables ask for each market in turn.
			$ids = get_posts(
				array(
					'post_type'      => $type,
					'post_status'    => 'publish',
					'posts_per_page' => 1000, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- IDs only, counted once per request.
					'fields'         => 'ids',
				)
			);
			self::prime( $ids );
			$counts[ $key ] = array();
			foreach ( $ids as $id ) {
				foreach ( array_unique( array_map( 'intval', (array) Fields::get( $id, $field ) ) ) as $m ) {
					$counts[ $key ][ $m ] = isset( $counts[ $key ][ $m ] ) ? $counts[ $key ][ $m ] + 1 : 1;
				}
			}
		}
		return isset( $counts[ $key ][ (int) $market ] ) ? $counts[ $key ][ (int) $market ] : 0;
	}
}
