<?php
/**
 * Server-rendered charts with table equivalents.
 *
 * Single series, one ink, direct labels; every chart has a table with the same numbers.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * SVG charts.
 */
class Charts {

	/**
	 * Unique id per request.
	 *
	 * @param string $prefix Prefix.
	 * @return string
	 */
	private static function uid( $prefix ) {
		static $n = 0;
		++$n;
		return $prefix . '-' . $n;
	}

	/**
	 * Horizontal bars, for example vacancy by submarket.
	 *
	 * @param string                                 $title  Chart title.
	 * @param string                                 $sub    Subtitle with units and period.
	 * @param array<int, array{0: string, 1: float}> $rows   Label and value pairs.
	 * @param string                                 $suffix Value suffix, for example %.
	 * @return string
	 */
	public static function bars( $title, $sub, $rows, $suffix = '%' ) {
		$rows = array_values(
			array_filter(
				$rows,
				function ( $r ) {
					return null !== $r[1];
				}
			)
		);
		if ( ! $rows ) {
			return '';
		}
		$id    = self::uid( 'axis-bars' );
		$max   = max( array_map( 'floatval', wp_list_pluck( $rows, 1 ) ) );
		$scale = $max > 0 ? ceil( $max / 5 ) * 5 : 1;
		$lw    = 150;
		$pw    = 330;
		$row_h = 34;
		$h     = count( $rows ) * $row_h + 28;

		$svg = '<svg class="axis-cre-chart__svg" viewBox="0 0 ' . ( $lw + $pw + 70 ) . ' ' . $h . '" role="img" aria-labelledby="' . esc_attr( $id ) . '-t" preserveAspectRatio="xMinYMin meet">';
		for ( $g = 0; $g <= $scale; $g += $scale / 5 ) {
			$x    = $lw + $pw * ( $g / $scale );
			$svg .= '<line class="grid" x1="' . esc_attr( (string) $x ) . '" y1="0" x2="' . esc_attr( (string) $x ) . '" y2="' . esc_attr( (string) ( $h - 22 ) ) . '"/>';
			$svg .= '<text class="axis" x="' . esc_attr( (string) $x ) . '" y="' . esc_attr( (string) ( $h - 6 ) ) . '" text-anchor="middle">' . esc_html( Format::trim( $g, 1 ) . $suffix ) . '</text>';
		}
		foreach ( $rows as $i => $r ) {
			$y    = $i * $row_h + 6;
			$w    = max( 2, $pw * ( (float) $r[1] / $scale ) );
			$svg .= '<g class="bar"><title>' . esc_html( $r[0] . ': ' . Format::trim( (float) $r[1], 1 ) . $suffix ) . '</title>';
			$svg .= '<text class="label" x="0" y="' . esc_attr( (string) ( $y + 14 ) ) . '">' . esc_html( $r[0] ) . '</text>';
			$svg .= '<path class="mark" d="M' . $lw . ' ' . $y . ' h' . ( $w - 4 ) . ' a4 4 0 0 1 4 4 v12 a4 4 0 0 1 -4 4 h-' . ( $w - 4 ) . ' z"/>';
			$svg .= '<text class="value" x="' . esc_attr( (string) ( $lw + $w + 8 ) ) . '" y="' . esc_attr( (string) ( $y + 14 ) ) . '">' . esc_html( Format::trim( (float) $r[1], 1 ) . $suffix ) . '</text></g>';
		}
		$svg .= '</svg>';

		return self::frame( $id, $title, $sub, $svg, array( __( 'Name', 'axis-cre' ), $title ), $rows, $suffix );
	}

	/**
	 * Line over time, for example asking rent by quarter.
	 *
	 * @param string                                 $title  Chart title.
	 * @param string                                 $sub    Subtitle.
	 * @param array<int, array{0: string, 1: float}> $points Label and value pairs, oldest first.
	 * @param string                                 $prefix Value prefix, for example $.
	 * @return string
	 */
	public static function trend( $title, $sub, $points, $prefix = '' ) {
		if ( count( $points ) < 2 ) {
			return '';
		}
		$id     = self::uid( 'axis-trend' );
		$values = array_map( 'floatval', wp_list_pluck( $points, 1 ) );
		$lo     = floor( min( $values ) / 5 ) * 5;
		$hi     = ceil( max( $values ) / 5 ) * 5;
		if ( $hi <= $lo ) {
			$hi = $lo + 5;
		}
		$w  = 520;
		$h  = 220;
		$l  = 48;
		$r  = 72;
		$t  = 10;
		$b  = 30;
		$pw = $w - $l - $r;
		$ph = $h - $t - $b;
		$n  = count( $points );
		$xy = array();
		foreach ( $points as $i => $p ) {
			$xy[] = array( $l + $pw * $i / ( $n - 1 ), $t + $ph * ( 1 - ( (float) $p[1] - $lo ) / ( $hi - $lo ) ) );
		}
		$svg = '<svg class="axis-cre-chart__svg" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-labelledby="' . esc_attr( $id ) . '-t">';
		foreach ( array( $lo, ( $lo + $hi ) / 2, $hi ) as $g ) {
			$y    = $t + $ph * ( 1 - ( $g - $lo ) / ( $hi - $lo ) );
			$svg .= '<line class="grid" x1="' . $l . '" y1="' . esc_attr( (string) $y ) . '" x2="' . ( $w - $r ) . '" y2="' . esc_attr( (string) $y ) . '"/>';
			$svg .= '<text class="axis" x="' . ( $l - 8 ) . '" y="' . esc_attr( (string) ( $y + 4 ) ) . '" text-anchor="end">' . esc_html( $prefix . Format::trim( $g, 0 ) ) . '</text>';
		}
		$path = '';
		foreach ( $xy as $i => $c ) {
			$path .= ( $i ? ' L' : 'M' ) . round( $c[0], 1 ) . ' ' . round( $c[1], 1 );
		}
		$svg .= '<path class="line" d="' . esc_attr( $path ) . '"/>';
		foreach ( $xy as $i => $c ) {
			$svg .= '<g class="point"><title>' . esc_html( $points[ $i ][0] . ': ' . $prefix . number_format_i18n( (float) $points[ $i ][1], 2 ) ) . '</title><circle cx="' . round( $c[0], 1 ) . '" cy="' . round( $c[1], 1 ) . '" r="' . ( $i === $n - 1 ? 5 : 3 ) . '"/></g>';
		}
		$last = end( $xy );
		$svg .= '<text class="value" x="' . round( $last[0] + 10, 1 ) . '" y="' . round( $last[1] + 4, 1 ) . '">' . esc_html( $prefix . number_format_i18n( (float) $points[ $n - 1 ][1], 2 ) ) . '</text>';
		foreach ( array_unique( array( 0, (int) floor( ( $n - 1 ) / 2 ), $n - 1 ) ) as $i ) {
			$svg .= '<text class="axis" x="' . round( $xy[ $i ][0], 1 ) . '" y="' . ( $h - 8 ) . '" text-anchor="middle">' . esc_html( $points[ $i ][0] ) . '</text>';
		}
		$svg .= '</svg>';

		return self::frame( $id, $title, $sub, $svg, array( __( 'Period', 'axis-cre' ), $title ), $points, '', $prefix );
	}

	/**
	 * Figure wrapper with title, chart and a table of the same numbers.
	 *
	 * @param string                                 $id      Element id.
	 * @param string                                 $title   Title.
	 * @param string                                 $sub     Subtitle.
	 * @param string                                 $svg     Chart markup, already escaped.
	 * @param array{0: string, 1: string}            $heads   Table headings.
	 * @param array<int, array{0: string, 1: float}> $rows    Data.
	 * @param string                                 $suffix  Value suffix.
	 * @param string                                 $prefix  Value prefix.
	 * @return string
	 */
	private static function frame( $id, $title, $sub, $svg, $heads, $rows, $suffix = '', $prefix = '' ) {
		$out  = '<figure class="axis-cre-chart">';
		$out .= '<figcaption><span class="axis-cre-chart__title" id="' . esc_attr( $id ) . '-t">' . esc_html( $title ) . '</span><span class="axis-cre-chart__sub">' . esc_html( $sub ) . '</span></figcaption>';
		$out .= $svg; // Built from escaped parts above.
		$out .= '<details class="axis-cre-chart__table"><summary>' . esc_html__( 'View as table', 'axis-cre' ) . '</summary><table><thead><tr><th scope="col">' . esc_html( $heads[0] ) . '</th><th scope="col" class="num">' . esc_html( $sub ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$out .= '<tr><th scope="row">' . esc_html( $r[0] ) . '</th><td class="num">' . esc_html( $prefix . Format::trim( (float) $r[1], 2 ) . $suffix ) . '</td></tr>';
		}
		return $out . '</tbody></table></details></figure>';
	}
}
