<?php
/**
 * Read-only REST routes: property search, markets, and expert contact cards.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Routes under /wp-json/axis-cre/v1.
 */
class Rest {

	const NS = 'axis-cre/v1';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_filter( 'rest_pre_serve_request', array( __CLASS__, 'serve_vcard' ), 10, 4 );
	}

	/**
	 * Register routes.
	 */
	public static function routes() {
		register_rest_route(
			self::NS,
			'/properties',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'properties' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'q'         => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'type'      => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
					),
					'market'    => array(
						'type'    => 'integer',
						'minimum' => 0,
					),
					'listing'   => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
					),
					'min_size'  => array( 'type' => 'number' ),
					'max_size'  => array( 'type' => 'number' ),
					'min_price' => array( 'type' => 'number' ),
					'max_price' => array( 'type' => 'number' ),
					'min_cap'   => array( 'type' => 'number' ),
					'min_rent'  => array( 'type' => 'number' ),
					'max_rent'  => array( 'type' => 'number' ),
					'featured'  => array( 'type' => 'boolean' ),
					'per_page'  => array(
						'type'    => 'integer',
						'default' => 12,
						'minimum' => 1,
						'maximum' => 100,
					),
					'page'      => array(
						'type'    => 'integer',
						'default' => 1,
						'minimum' => 1,
					),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/markets',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'markets' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NS,
			'/experts/(?P<id>\d+)/vcard',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'vcard' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'id' => array(
						'type'    => 'integer',
						'minimum' => 1,
					),
				),
			)
		);
	}

	/**
	 * Public fields of a property record.
	 *
	 * @param array<string, mixed> $p Property record.
	 * @return array<string, mixed>
	 */
	private static function public_property( $p ) {
		return array(
			'id'         => $p['id'],
			'label'      => $p['label'],
			'title'      => $p['title'],
			'url'        => $p['url'],
			'type'       => $p['type'],
			'type_name'  => $p['type_name'],
			'status'     => $p['status'],
			'class_line' => $p['class_line'],
			'market'     => $p['market'],
			'lat'        => $p['lat'],
			'lng'        => $p['lng'],
			'size'       => $p['size'],
			'occupancy'  => $p['occupancy'],
			'price'      => $p['price'],
			'lease_rate' => $p['lease'],
			'cap_rate'   => $p['cap'],
			'metrics'    => array_map(
				function ( $m ) {
					return array(
						'value' => $m[0],
						'label' => $m[1],
					);
				},
				$p['metrics']
			),
			'image'      => $p['image'] ? wp_get_attachment_image_url( $p['image'], 'large' ) : null,
		);
	}

	/**
	 * GET /properties.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function properties( $request ) {
		$args = array();
		foreach ( array( 'q', 'type', 'market', 'listing', 'min_size', 'max_size', 'min_price', 'max_price', 'min_cap', 'min_rent', 'max_rent', 'featured', 'per_page', 'page' ) as $key ) {
			if ( null !== $request->get_param( $key ) ) {
				$args[ $key ] = $request->get_param( $key );
			}
		}
		$res      = Repository::properties( $args );
		$response = rest_ensure_response( array_map( array( __CLASS__, 'public_property' ), $res['items'] ) );
		$response->header( 'X-WP-Total', (string) $res['total'] );
		$response->header( 'X-WP-TotalPages', (string) $res['pages'] );
		return $response;
	}

	/**
	 * GET /markets.
	 *
	 * @return \WP_REST_Response
	 */
	public static function markets() {
		$out = array();
		foreach ( Repository::markets() as $m ) {
			$out[] = array(
				'id'         => $m['id'],
				'label'      => $m['label'],
				'title'      => $m['title'],
				'url'        => $m['url'],
				'country'    => $m['country'],
				'lat'        => $m['lat'],
				'lng'        => $m['lng'],
				'quarter'    => $m['quarter'],
				'sectors'    => $m['sectors'],
				'submarkets' => $m['submarkets'],
				'assets'     => Repository::count_in_market( Post_Types::PROPERTY, $m['id'] ),
			);
		}
		return rest_ensure_response( $out );
	}

	/**
	 * GET /experts/{id}/vcard.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function vcard( $request ) {
		$id = (int) $request['id'];
		$e  = Repository::expert( $id );
		if ( ! $e || 'publish' !== get_post_status( $id ) ) {
			return new \WP_Error( 'axis_cre_not_found', __( 'No expert with that ID.', 'axis-cre' ), array( 'status' => 404 ) );
		}
		$esc   = function ( $s ) {
			return str_replace( array( '\\', ',', ';', "\n" ), array( '\\\\', '\,', '\;', '\n' ), wp_strip_all_tags( (string) $s ) );
		};
		$names = explode( ' ', $e['title'] );
		$last  = count( $names ) > 1 ? array_pop( $names ) : '';
		$lines = array(
			'BEGIN:VCARD',
			'VERSION:3.0',
			'N:' . $esc( $last ) . ';' . $esc( implode( ' ', $names ) ) . ';;;',
			'FN:' . $esc( $e['title'] ),
			'ORG:' . $esc( get_bloginfo( 'name' ) ),
		);
		if ( $e['job'] ) {
			$lines[] = 'TITLE:' . $esc( $e['job'] );
		}
		if ( $e['phone'] ) {
			$lines[] = 'TEL;TYPE=WORK,VOICE:' . $esc( $e['phone'] );
		}
		if ( $e['email'] ) {
			$lines[] = 'EMAIL;TYPE=INTERNET,WORK:' . $esc( $e['email'] );
		}
		$lines[] = 'URL:' . $esc( $e['url'] );
		$lines[] = 'END:VCARD';

		$response = new \WP_REST_Response( implode( "\r\n", $lines ) . "\r\n" );
		$response->header( 'Content-Type', 'text/vcard; charset=utf-8' );
		$response->header( 'Content-Disposition', 'attachment; filename="' . sanitize_file_name( $e['title'] ) . '.vcf"' );
		return $response;
	}

	/**
	 * Send the vCard as plain text rather than a JSON string.
	 *
	 * @param bool              $served  Whether the request was served.
	 * @param \WP_HTTP_Response $result  Result.
	 * @param \WP_REST_Request  $request Request.
	 * @return bool
	 */
	public static function serve_vcard( $served, $result, $request ) {
		if ( $served || ! preg_match( '#^/' . preg_quote( self::NS, '#' ) . '/experts/\d+/vcard$#', $request->get_route() ) || $result->is_error() ) {
			return $served;
		}
		echo $result->get_data(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- text/vcard body, built from stripped and escaped values.
		return true;
	}
}
