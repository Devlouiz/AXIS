<?php
/**
 * Sample content: six markets with properties, transactions, experts and research.
 *
 * Images are survey drawings generated on the server, so nothing is downloaded.
 * Everything created is tagged and can be removed in one step.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Tools page and WP-CLI command for sample content.
 */
class Sample {

	const META = '_axis_sample';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_axis_cre_sample', array( __CLASS__, 'handle' ) );
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'axis-cre seed', array( __CLASS__, 'cli_seed' ) );
			\WP_CLI::add_command( 'axis-cre remove-sample', array( __CLASS__, 'cli_remove' ) );
		}
	}

	/**
	 * Tools page.
	 */
	public static function menu() {
		add_management_page( __( 'AXIS sample content', 'axis-cre' ), __( 'AXIS sample content', 'axis-cre' ), 'manage_options', 'axis-cre-sample', array( __CLASS__, 'page' ) );
	}

	/**
	 * Number of sample items.
	 *
	 * @return int
	 */
	public static function count() {
		return count( self::ids( array_merge( Post_Types::all(), array( 'page', 'wp_navigation' ) ) ) );
	}

	/**
	 * IDs of sample posts of the given types.
	 *
	 * @param string[] $types Post types.
	 * @return int[]
	 */
	private static function ids( $types ) {
		return array_map(
			'intval',
			get_posts(
				array(
					'post_type'      => $types,
					'post_status'    => 'any',
					'posts_per_page' => -1,
					'fields'         => 'ids',
					'meta_key'       => self::META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Admin-only cleanup query.
				)
			)
		);
	}

	/**
	 * Render the Tools page.
	 */
	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$n = self::count();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only notice after a redirect.
		$done = isset( $_GET['axis_done'] ) ? sanitize_key( wp_unslash( $_GET['axis_done'] ) ) : '';

		echo '<div class="wrap axis-cre-settings"><h1>' . esc_html__( 'AXIS sample content', 'axis-cre' ) . '</h1>';
		if ( 'created' === $done ) {
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Sample content created. Open Properties or Markets to see it.', 'axis-cre' ) . '</p></div>';
		} elseif ( 'removed' === $done ) {
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Sample content removed.', 'axis-cre' ) . '</p></div>';
		} elseif ( 'error' === $done ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Sample content could not be created. The image library (GD) may be missing; ask your host.', 'axis-cre' ) . '</p></div>';
		}
		echo '<p>' . esc_html__( 'Fill every template with realistic, clearly fictional content: six markets, thirteen properties, six transactions, six experts and five research pieces. Photographs are replaced by generated survey drawings.', 'axis-cre' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'axis_cre_sample' );
		echo '<input type="hidden" name="action" value="axis_cre_sample">';
		if ( $n ) {
			/* translators: %d: number of sample items. */
			echo '<p>' . esc_html( sprintf( _n( '%d sample item is installed.', '%d sample items are installed.', $n, 'axis-cre' ), $n ) ) . '</p>';
			echo '<p><button type="submit" name="axis_do" value="remove" class="button">' . esc_html__( 'Remove sample content', 'axis-cre' ) . '</button></p>';
			echo '<p class="description">' . esc_html__( 'Removes only items created here, including their generated images. Your own content is not touched.', 'axis-cre' ) . '</p>';
		} else {
			echo '<p><button type="submit" name="axis_do" value="create" class="button button-primary">' . esc_html__( 'Create sample content', 'axis-cre' ) . '</button></p>';
			echo '<p class="description">' . esc_html__( 'Takes up to a minute while images are generated.', 'axis-cre' ) . '</p>';
		}
		echo '</form><p>' . esc_html__( 'From the command line:', 'axis-cre' ) . ' <code>wp axis-cre seed</code> <code>wp axis-cre remove-sample</code></p></div>';
	}

	/**
	 * Form handler.
	 */
	public static function handle() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'axis-cre' ), 403 );
		}
		check_admin_referer( 'axis_cre_sample' );
		$do   = isset( $_POST['axis_do'] ) ? sanitize_key( wp_unslash( $_POST['axis_do'] ) ) : '';
		$done = 'removed';
		if ( 'create' === $do ) {
			$result = self::seed();
			$done   = is_wp_error( $result ) ? 'error' : 'created';
		} elseif ( 'remove' === $do ) {
			self::remove();
		}
		wp_safe_redirect( add_query_arg( 'axis_done', $done, admin_url( 'tools.php?page=axis-cre-sample' ) ) );
		exit;
	}

	/**
	 * Create sample content.
	 *
	 * ## EXAMPLES
	 *
	 *     wp axis-cre seed
	 */
	public static function cli_seed() {
		$result = self::seed();
		if ( is_wp_error( $result ) ) {
			\WP_CLI::error( $result->get_error_message() );
		}
		/* translators: %d: number of items. */
		\WP_CLI::success( sprintf( __( 'Created %d sample items.', 'axis-cre' ), $result ) );
	}

	/**
	 * Remove sample content.
	 *
	 * ## EXAMPLES
	 *
	 *     wp axis-cre remove-sample
	 */
	public static function cli_remove() {
		/* translators: %d: number of items. */
		\WP_CLI::success( sprintf( __( 'Removed %d sample items.', 'axis-cre' ), self::remove() ) );
	}

	/**
	 * Remove everything tagged as sample content.
	 *
	 * @return int Items removed.
	 */
	public static function remove() {
		$n = 0;
		foreach ( self::ids( array_merge( Post_Types::all(), array( 'page', 'wp_navigation' ) ) ) as $id ) {
			wp_delete_post( $id, true );
			++$n;
		}
		foreach ( self::ids( array( 'attachment' ) ) as $id ) {
			wp_delete_attachment( $id, true );
		}
		$settings = (array) get_option( 'axis_cre_settings', array() );
		if ( ! empty( $settings['shortlist'] ) && ! get_post( (int) $settings['shortlist'] ) ) {
			$settings['shortlist'] = 0;
			update_option( 'axis_cre_settings', $settings );
		}
		return $n;
	}

	// ------------------------------------------------------------------ seeding

	/**
	 * Create sample content.
	 *
	 * @return int|\WP_Error Items created.
	 */
	public static function seed() {
		if ( self::count() ) {
			return new \WP_Error( 'axis_cre_sample_exists', __( 'Sample content is already installed. Remove it first.', 'axis-cre' ) );
		}
		$gd = function_exists( 'imagecreatetruecolor' );
		wp_raise_memory_limit( 'image' );
		require_once ABSPATH . 'wp-admin/includes/image.php';
		Post_Types::seed_terms();

		$created = 0;
		$author  = self::author();

		// Photos shared by property type; floor plans drawn when GD is available.
		$photo   = self::photos();
		$by_type = array(
			'office'      => array( 'office-a', 'office-b', 'office-c' ),
			'industrial'  => array( 'industrial-a', 'industrial-b' ),
			'multifamily' => array( 'multifamily', 'mixed' ),
			'retail'      => array( 'retail', 'mixed' ),
			'mixed-use'   => array( 'mixed', 'retail' ),
			'land'        => array( 'industrial-b', 'industrial-a' ),
		);
		$types   = array( 'office', 'industrial', 'multifamily', 'retail', 'mixed-use' );
		$plan    = array();
		foreach ( $types as $i => $t ) {
			$name       = str_replace( '-', ' ', $t );
			$plan[ $t ] = $gd ? self::attach_png( 'axis-sample-plan-' . $t . '.png', self::draw_plan( $t, $i ), 'Sample floor plan, ' . $name, 'Drawing of a typical ' . $name . ' floor plan', 'Typical floor plan. Sample drawing.' ) : 0;
		}
		$pick = function ( $type, $n ) use ( $photo, $by_type ) {
			$set = isset( $by_type[ $type ] ) ? $by_type[ $type ] : $by_type['office'];
			return $photo[ $set[ $n % count( $set ) ] ];
		};
		$docs = array(
			'om'    => self::attach_bytes( 'axis-sample-offering-memorandum.pdf', self::pdf( 'Offering memorandum', array( 'Sample document created by AXIS CRE.', 'Replace with the real offering memorandum.' ) ), 'Offering memorandum' ),
			'roll'  => self::attach_bytes( 'axis-sample-rent-roll.pdf', self::pdf( 'Rent roll summary', array( 'Sample document created by AXIS CRE.', 'Replace with the current rent roll.' ) ), 'Rent roll summary' ),
			'plans' => self::attach_bytes( 'axis-sample-floor-plans.pdf', self::pdf( 'Stacking and floor plans', array( 'Sample document created by AXIS CRE.', 'Replace with measured floor plans.' ) ), 'Stacking and floor plans' ),
		);

		// Markets.
		$markets       = array();
		$market_photos = array( 'office-a', 'office-c', 'office-b', 'mixed', 'multifamily', 'industrial-a' );
		foreach ( self::markets() as $i => $m ) {
			$site                  = $photo[ $market_photos[ $i % count( $market_photos ) ] ];
			$markets[ $m['slug'] ] = array(
				'id'   => self::insert(
					Post_Types::MARKET,
					$m['title'],
					array(
						'post_name'    => $m['slug'],
						'menu_order'   => $i + 1,
						'post_excerpt' => $m['excerpt'],
						'post_content' => self::blocks( $m['content'] ),
						'post_author'  => $author,
					),
					array_merge( $m['meta'], array( 'number' => $i + 1 ) ),
					array(),
					$site
				),
				'site' => $site,
			);
			++$created;
		}

		// Experts.
		$experts = array();
		// No portraits: cards and profiles show initials until a real photograph is added.
		foreach ( self::experts() as $i => $e ) {
			$meta                    = $e['meta'];
			$meta['markets']         = array( $markets[ $e['market'] ]['id'] );
			$experts[ $e['number'] ] = self::insert(
				Post_Types::EXPERT,
				$e['title'],
				array(
					'menu_order'   => $i + 1,
					'post_excerpt' => $e['excerpt'],
					'post_content' => self::blocks( $e['content'] ),
					'post_author'  => $author,
				),
				array_merge( $meta, array( 'number' => $e['number'] ) ),
				$e['terms']
			);
			++$created;
		}

		// Properties.
		$properties = array();
		$seen       = array();
		foreach ( self::properties() as $i => $p ) {
			$k                          = isset( $seen[ $p['type'] ] ) ? $seen[ $p['type'] ] : 0;
			$seen[ $p['type'] ]         = $k + 1;
			$main                       = $pick( $p['type'], $k );
			$market                     = $markets[ $p['market'] ];
			$meta                       = $p['meta'];
			$meta['market']             = $market['id'];
			$meta['experts']            = array_map(
				function ( $n ) use ( $experts ) {
					return $experts[ $n ];
				},
				$p['experts']
			);
			$meta['gallery']            = array_values( array_unique( array_filter( array( $main, $pick( $p['type'], $k + 1 ), $market['site'], isset( $plan[ $p['type'] ] ) ? $plan[ $p['type'] ] : 0 ) ) ) );
			$meta['documents']          = array(
				array(
					'id'    => $docs['om'],
					'gated' => true,
				),
				array(
					'id'    => $docs['roll'],
					'gated' => true,
				),
				array(
					'id'    => $docs['plans'],
					'gated' => false,
				),
			);
			$properties[ $p['number'] ] = self::insert(
				Post_Types::PROPERTY,
				$p['title'],
				array(
					'menu_order'   => $i,
					'post_excerpt' => $p['excerpt'],
					'post_content' => self::blocks( $p['content'] ),
					'post_author'  => $author,
				),
				array_merge( $meta, array( 'number' => $p['number'] ) ),
				array(
					'axis_property_type' => array( $p['type'] ),
					'axis_listing_type'  => array( $p['listing'] ),
				),
				$main
			);
			++$created;
		}

		// Transactions.
		foreach ( self::transactions() as $t ) {
			$meta            = $t['meta'];
			$meta['market']  = $markets[ $t['market'] ]['id'];
			$meta['experts'] = array_map(
				function ( $n ) use ( $experts ) {
					return $experts[ $n ];
				},
				$t['experts']
			);
			if ( ! empty( $t['property'] ) ) {
				$meta['property'] = $properties[ $t['property'] ];
			}
			self::insert(
				Post_Types::TRANSACTION,
				$t['title'],
				array(
					'post_date'    => $t['date'],
					'post_excerpt' => $t['excerpt'],
					'post_content' => self::blocks( $t['content'] ),
					'post_author'  => $author,
				),
				array_merge( $meta, array( 'number' => $t['number'] ) ),
				array(
					'axis_transaction_type' => array( $t['deal'] ),
					'axis_property_type'    => array( $t['type'] ),
					'axis_service'          => array( $t['service'] ),
				),
				$pick( $t['type'], 1 )
			);
			++$created;
		}

		// Research.
		foreach ( self::research() as $r ) {
			$meta            = $r['meta'];
			$meta['markets'] = array_map(
				function ( $slug ) use ( $markets ) {
					return $markets[ $slug ]['id'];
				},
				$r['markets']
			);
			$meta['experts'] = array_map(
				function ( $n ) use ( $experts ) {
					return $experts[ $n ];
				},
				$r['experts']
			);
			if ( ! empty( $r['csv'] ) ) {
				$meta['data'] = array( self::attach_bytes( 'axis-sample-' . sanitize_title( $r['title'] ) . '.csv', $r['csv'], $r['title'] . ', data' ) );
			}
			if ( ! empty( $r['pages'] ) ) {
				$meta['pdf']   = array( self::attach_bytes( 'axis-sample-' . sanitize_title( $r['title'] ) . '.pdf', self::pdf( $r['title'], array( 'Sample report created by AXIS CRE.', 'Replace with the published PDF.' ) ), $r['title'] ) );
				$meta['pages'] = $r['pages'];
			}
			self::insert(
				Post_Types::RESEARCH,
				$r['title'],
				array(
					'post_date'    => $r['date'],
					'post_excerpt' => $r['excerpt'],
					'post_content' => self::blocks( $r['content'] ),
					'post_author'  => $author,
				),
				array_merge( $meta, array( 'number' => $r['number'] ) ),
				array(
					'axis_research_type' => array( $r['type'] ),
					'axis_property_type' => $r['types'],
				),
				! empty( $r['image'] ) ? $markets[ $r['markets'][0] ]['site'] : 0
			);
			++$created;
		}

		$created += self::pages( $author );

		// Keep numbering going from the highest sample number.
		$maxima = array(
			Post_Types::MARKET      => count( $markets ),
			Post_Types::EXPERT      => max( array_keys( $experts ) ),
			Post_Types::PROPERTY    => max( array_keys( $properties ) ),
			Post_Types::TRANSACTION => max( wp_list_pluck( self::transactions(), 'number' ) ),
			Post_Types::RESEARCH    => max( wp_list_pluck( self::research(), 'number' ) ),
		);
		foreach ( $maxima as $type => $max ) {
			$option = 'axis_cre_counter_' . $type;
			if ( (int) get_option( $option, 0 ) < $max ) {
				update_option( $option, $max, false );
			}
		}

		flush_rewrite_rules( false );
		return $created;
	}

	/**
	 * Pages for the theme's page patterns, when the AXIS theme is active and the page is missing.
	 *
	 * @param int $author Author ID.
	 * @return int Pages created.
	 */
	private static function pages( $author ) {
		$registry = \WP_Block_Patterns_Registry::get_instance();
		// Slug => title, pattern, and the page heading when the pattern does not start with one.
		$pages = array(
			'services' => array( 'Services', 'axis/services', __( 'Advisory for owners, occupiers and investors', 'axis-cre' ) ),
			'team'     => array( 'Team', 'axis/team', __( 'Our team', 'axis-cre' ) ),
			'contact'  => array( 'Contact', 'axis/contact', '' ),
		);
		$n     = 0;
		// Pattern pages are full-width compositions: use the theme's wide page template when it has one.
		$wide = get_block_template( get_stylesheet() . '//page-wide' ) ? array( '_wp_page_template' => 'page-wide' ) : array();
		foreach ( $pages as $slug => $page ) {
			if ( ! $registry->is_registered( $page[1] ) || get_page_by_path( $slug ) ) {
				continue;
			}
			self::insert(
				'page',
				$page[0],
				array(
					'post_name'    => $slug,
					'post_content' => ( $wide && $page[2] ? self::page_head( $page[2], '', 0 ) . "\n\n" : '' ) . '<!-- wp:pattern {"slug":"' . $page[1] . '"} /-->',
					'post_author'  => $author,
				),
				$wide,
				array()
			);
			++$n;
		}

		// A main menu, so block themes show these sections instead of listing every page.
		// Themes use the newest menu when their Navigation block has none chosen; removing
		// the sample content brings back whatever menu the site had before.
		$links = array(
			__( 'Properties', 'axis-cre' )   => get_post_type_archive_link( Post_Types::PROPERTY ),
			__( 'Markets', 'axis-cre' )      => get_post_type_archive_link( Post_Types::MARKET ),
			__( 'Transactions', 'axis-cre' ) => get_post_type_archive_link( Post_Types::TRANSACTION ),
			__( 'Experts', 'axis-cre' )      => get_post_type_archive_link( Post_Types::EXPERT ),
			__( 'Research', 'axis-cre' )     => get_post_type_archive_link( Post_Types::RESEARCH ),
			__( 'Contact', 'axis-cre' )      => get_page_by_path( 'contact' ) ? get_permalink( get_page_by_path( 'contact' ) ) : '',
		);
		$menu  = '';
		foreach ( array_filter( $links ) as $label => $url ) {
			$menu .= '<!-- wp:navigation-link ' . wp_json_encode(
				array(
					'label' => $label,
					'url'   => $url,
					'kind'  => 'custom',
				)
			) . ' /-->';
		}
		if ( self::insert(
			'wp_navigation',
			__( 'Main menu', 'axis-cre' ),
			array(
				'post_content' => $menu,
				'post_author'  => $author,
			),
			array(),
			array()
		) ) {
			++$n;
		}

		// The shortlist page that saved listings and the compare tray open.
		if ( ! get_page_by_path( 'shortlist' ) ) {
			$id = self::insert(
				'page',
				__( 'Shortlist', 'axis-cre' ),
				array(
					'post_name'    => 'shortlist',
					'post_content' => self::shortlist_content( (bool) $wide ),
					'post_author'  => $author,
				),
				$wide,
				array()
			);
			if ( $id ) {
				$settings              = (array) get_option( 'axis_cre_settings', array() );
				$settings['shortlist'] = $id;
				update_option( 'axis_cre_settings', $settings );
				++$n;
			}
		}
		return $n;
	}

	/**
	 * Shortlist page content. On a full-width template it carries its own title section;
	 * on a theme's ordinary page template the page title is already there.
	 *
	 * @param bool $wide Whether the page uses the theme's full-width template.
	 * @return string
	 */
	private static function shortlist_content( $wide ) {
		$help  = __( 'Listings you saved, and up to four side by side. Your lists stay in this browser.', 'axis-cre' );
		$block = '<!-- wp:axis/shortlist {"align":"wide"} /-->';
		if ( ! $wide ) {
			return '<!-- wp:paragraph --><p>' . esc_html( $help ) . '</p><!-- /wp:paragraph -->' . "\n\n" . $block;
		}
		return self::page_head( __( 'Your shortlist', 'axis-cre' ), $help, 90, $block );
	}

	/**
	 * A full-width section that opens a page: its one H1, an optional line of help, optional blocks after.
	 *
	 * @param string $title  Page heading.
	 * @param string $help   Line under the heading, or empty.
	 * @param int    $bottom Bottom padding step (0 for none).
	 * @param string $after  Block markup inside the section, after the heading.
	 * @return string
	 */
	private static function page_head( $title, $help, $bottom, $after = '' ) {
		$pad   = array( 'top' => 'var:preset|spacing|80' );
		$style = 'padding-top:var(--wp--preset--spacing--80)';
		if ( $bottom ) {
			$pad['bottom'] = 'var:preset|spacing|' . (int) $bottom;
			$style        .= ';padding-bottom:var(--wp--preset--spacing--' . (int) $bottom . ')';
		}
		$attrs = wp_json_encode(
			array(
				'align'  => 'full',
				'style'  => array( 'spacing' => array( 'padding' => $pad ) ),
				'layout' => array( 'type' => 'constrained' ),
			)
		);
		return '<!-- wp:group ' . $attrs . ' -->' . "\n"
			. '<div class="wp-block-group alignfull" style="' . esc_attr( $style ) . '">'
			. '<!-- wp:group {"align":"wide","layout":{"type":"default"}} --><div class="wp-block-group alignwide">'
			. '<!-- wp:heading {"level":1} --><h1 class="wp-block-heading">' . esc_html( $title ) . '</h1><!-- /wp:heading -->'
			. ( '' !== $help ? "\n" . '<!-- wp:paragraph --><p>' . esc_html( $help ) . '</p><!-- /wp:paragraph -->' : '' )
			. '</div><!-- /wp:group -->' . ( '' !== $after ? "\n" . $after : '' ) . '</div>' . "\n"
			. '<!-- /wp:group -->';
	}

	/**
	 * An administrator to own sample posts when run from the command line.
	 *
	 * @return int
	 */
	private static function author() {
		if ( get_current_user_id() ) {
			return get_current_user_id();
		}
		$admins = get_users(
			array(
				'role'   => 'administrator',
				'number' => 1,
				'fields' => 'ID',
			)
		);
		return $admins ? (int) $admins[0] : 0;
	}

	/**
	 * Insert a tagged post with fields, terms and a featured image.
	 *
	 * @param string                  $type  Post type.
	 * @param string                  $title Title.
	 * @param array<string, mixed>    $args  Extra post fields.
	 * @param array<string, mixed>    $meta  Field values by key (unprefixed).
	 * @param array<string, string[]> $terms Term slugs by taxonomy.
	 * @param int                     $thumb Featured image.
	 * @return int
	 */
	private static function insert( $type, $title, $args, $meta, $terms, $thumb = 0 ) {
		$input = array( self::META => 1 );
		foreach ( $meta as $k => $v ) {
			$input[ in_array( $type, array( 'page', 'wp_navigation' ), true ) ? $k : Fields::meta_key( $k ) ] = $v;
		}
		$id = wp_insert_post(
			wp_slash(
				array_merge(
					array(
						'post_type'   => $type,
						'post_title'  => $title,
						'post_status' => 'publish',
						'meta_input'  => $input,
					),
					$args
				)
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			return 0;
		}
		foreach ( $terms as $taxonomy => $slugs ) {
			$ids = array();
			foreach ( (array) $slugs as $slug ) {
				$term = get_term_by( 'slug', $slug, $taxonomy );
				if ( $term ) {
					$ids[] = (int) $term->term_id;
				}
			}
			wp_set_object_terms( $id, $ids, $taxonomy );
		}
		if ( $thumb ) {
			set_post_thumbnail( $id, $thumb );
		}
		return (int) $id;
	}

	/**
	 * Paragraph and heading blocks from lines; "## " starts a heading.
	 *
	 * @param string[] $lines Lines.
	 * @return string
	 */
	private static function blocks( $lines ) {
		$out = '';
		foreach ( $lines as $line ) {
			if ( 0 === strpos( $line, '## ' ) ) {
				$out .= '<!-- wp:heading -->' . "\n" . '<h2 class="wp-block-heading">' . esc_html( substr( $line, 3 ) ) . '</h2>' . "\n" . '<!-- /wp:heading -->' . "\n\n";
			} else {
				$out .= '<!-- wp:paragraph -->' . "\n" . '<p>' . esc_html( $line ) . '</p>' . "\n" . '<!-- /wp:paragraph -->' . "\n\n";
			}
		}
		return $out;
	}

	// ------------------------------------------------------------------ files

	/**
	 * Save bytes to uploads and create a tagged attachment.
	 *
	 * @param string $filename File name.
	 * @param string $bytes    Contents.
	 * @param string $title    Title.
	 * @param string $alt      Alt text, for images.
	 * @param string $caption  Caption.
	 * @return int Attachment ID, or 0.
	 */
	private static function attach_bytes( $filename, $bytes, $title, $alt = '', $caption = '' ) {
		if ( '' === $bytes ) {
			return 0;
		}
		$upload = wp_upload_bits( $filename, null, $bytes );
		if ( ! empty( $upload['error'] ) ) {
			return 0;
		}
		$check = wp_check_filetype( $upload['file'] );
		$id    = wp_insert_attachment(
			array(
				'post_mime_type' => $check['type'],
				'post_title'     => $title,
				'post_excerpt'   => $caption,
				'post_status'    => 'inherit',
			),
			$upload['file']
		);
		if ( ! $id || is_wp_error( $id ) ) {
			return 0;
		}
		wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $upload['file'] ) );
		update_post_meta( $id, self::META, 1 );
		if ( $alt ) {
			update_post_meta( $id, '_wp_attachment_image_alt', $alt );
		}
		return (int) $id;
	}

	/**
	 * Attach the bundled sample photographs once each.
	 *
	 * @return array<string, int> Short name => attachment ID.
	 */
	private static function photos() {
		$alts = array(
			'office-a'     => 'Glass office tower on a city street, sample illustration',
			'office-b'     => 'Stone and glass office building, sample illustration',
			'office-c'     => 'Office tower at dusk, sample illustration',
			'industrial-a' => 'Logistics warehouse with loading doors, sample illustration',
			'industrial-b' => 'Distribution building and yard, sample illustration',
			'multifamily'  => 'Apartment building with balconies, sample illustration',
			'retail'       => 'Shopfronts on a high street, sample illustration',
			'mixed'        => 'Mixed-use building with shops below homes, sample illustration',
		);
		$out  = array();
		foreach ( $alts as $name => $alt ) {
			$file         = AXIS_CRE_DIR . 'assets/sample/asset-' . $name . '.jpg';
			$bytes        = is_readable( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file bundled with the plugin.
			$out[ $name ] = self::attach_bytes( 'axis-sample-' . $name . '.jpg', $bytes, ucfirst( str_replace( '-', ' ', $name ) ) . ', sample photo', $alt, 'Sample image; replace with a photograph of the property.' );
		}
		return $out;
	}

	/**
	 * Encode a GD image as PNG and attach it.
	 *
	 * @param string            $filename File name.
	 * @param \GdImage|resource $im       Image.
	 * @param string            $title    Title.
	 * @param string            $alt      Alt text.
	 * @param string            $caption  Caption.
	 * @return int
	 */
	private static function attach_png( $filename, $im, $title, $alt, $caption ) {
		ob_start();
		imagepng( $im, null, 6 );
		$bytes = (string) ob_get_clean();
		if ( PHP_VERSION_ID < 80000 ) {
			// GD images are objects from PHP 8 and are freed automatically; imagedestroy() is deprecated in 8.5.
			imagedestroy( $im ); // phpcs:ignore PHPCompatibility.FunctionUse.RemovedFunctions.imagedestroyDeprecated -- Branch runs before PHP 8 only.
		}
		return self::attach_bytes( $filename, $bytes, $title, $alt, $caption );
	}

	/**
	 * A one-page PDF with a title and a few lines, in Helvetica.
	 *
	 * @param string   $title Title.
	 * @param string[] $lines Lines.
	 * @return string
	 */
	private static function pdf( $title, $lines ) {
		$esc    = function ( $s ) {
			return str_replace( array( '\\', '(', ')' ), array( '\\\\', '\\(', '\\)' ), remove_accents( $s ) );
		};
		$stream = 'BT /F1 22 Tf 72 700 Td (' . $esc( $title ) . ") Tj ET\n";
		$y      = 660;
		foreach ( $lines as $line ) {
			$stream .= 'BT /F1 12 Tf 72 ' . $y . ' Td (' . $esc( $line ) . ") Tj ET\n";
			$y      -= 20;
		}
		$stream .= "0.25 0.42 0.37 RG 2 w 72 730 m 540 730 l S\n";
		$objects = array(
			'<< /Type /Catalog /Pages 2 0 R >>',
			'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
			'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
			'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
			'<< /Length ' . strlen( $stream ) . " >>\nstream\n" . $stream . 'endstream',
		);
		$pdf     = "%PDF-1.4\n";
		$offsets = array();
		foreach ( $objects as $i => $obj ) {
			$offsets[] = strlen( $pdf );
			$pdf      .= ( $i + 1 ) . " 0 obj\n" . $obj . "\nendobj\n";
		}
		$xref = strlen( $pdf );
		$pdf .= "xref\n0 " . ( count( $objects ) + 1 ) . "\n0000000000 65535 f \n";
		foreach ( $offsets as $o ) {
			$pdf .= str_pad( (string) $o, 10, '0', STR_PAD_LEFT ) . " 00000 n \n";
		}
		$pdf .= 'trailer << /Size ' . ( count( $objects ) + 1 ) . " /Root 1 0 R >>\nstartxref\n" . $xref . "\n%%EOF\n";
		return $pdf;
	}

	// ------------------------------------------------------------------ survey drawings

	/**
	 * Canvas on concrete with the Axis Grid.
	 *
	 * @param int $w Width.
	 * @param int $h Height.
	 * @return array{0: \GdImage|resource, 1: array<string, int>}
	 */
	private static function canvas( $w, $h ) {
		$im = imagecreatetruecolor( $w, $h );
		imagealphablending( $im, true );
		$c = array(
			'base'   => imagecolorallocate( $im, 228, 228, 224 ),
			'panel'  => imagecolorallocate( $im, 245, 245, 242 ),
			'steel'  => imagecolorallocate( $im, 31, 35, 38 ),
			'slate'  => imagecolorallocate( $im, 92, 98, 102 ),
			'line'   => imagecolorallocate( $im, 185, 187, 181 ),
			'grid'   => imagecolorallocatealpha( $im, 31, 35, 38, 114 ),
			'marker' => imagecolorallocate( $im, 227, 178, 60 ),
			'green'  => imagecolorallocate( $im, 63, 107, 94 ),
		);
		imagefilledrectangle( $im, 0, 0, $w, $h, $c['base'] );
		for ( $x = 80; $x < $w; $x += 80 ) {
			imageline( $im, $x, 0, $x, $h, $c['grid'] );
		}
		for ( $y = 80; $y < $h; $y += 80 ) {
			imageline( $im, 0, $y, $w, $y, $c['grid'] );
		}
		return array( $im, $c );
	}

	/**
	 * Outlined, filled rectangle.
	 *
	 * @param \GdImage|resource $im     Image.
	 * @param int               $x1     Left.
	 * @param int               $y1     Top.
	 * @param int               $x2     Right.
	 * @param int               $y2     Bottom.
	 * @param int               $fill   Fill colour.
	 * @param int               $stroke Stroke colour.
	 * @param int               $weight Stroke width.
	 */
	private static function box( $im, $x1, $y1, $x2, $y2, $fill, $stroke, $weight = 3 ) {
		imagefilledrectangle( $im, $x1, $y1, $x2, $y2, $fill );
		imagesetthickness( $im, $weight );
		imagerectangle( $im, $x1, $y1, $x2, $y2, $stroke );
		imagesetthickness( $im, 1 );
	}

	/**
	 * Diagonal hatch inside a rectangle.
	 *
	 * @param \GdImage|resource $im    Image.
	 * @param int               $x1    Left.
	 * @param int               $y1    Top.
	 * @param int               $x2    Right.
	 * @param int               $y2    Bottom.
	 * @param int               $color Colour.
	 * @param int               $gap   Spacing.
	 */
	private static function hatch( $im, $x1, $y1, $x2, $y2, $color, $gap = 14 ) {
		imagesetclip( $im, $x1, $y1, $x2, $y2 );
		for ( $d = -( $y2 - $y1 ); $d < ( $x2 - $x1 ); $d += $gap ) {
			imageline( $im, $x1 + $d, $y2, $x1 + $d + ( $y2 - $y1 ), $y1, $color );
		}
		imagesetclip( $im, 0, 0, imagesx( $im ) - 1, imagesy( $im ) - 1 );
	}

	/**
	 * Scale bar in four alternating segments.
	 *
	 * @param \GdImage|resource  $im Image.
	 * @param int                $x  Left.
	 * @param int                $y  Top.
	 * @param array<string, int> $c  Colours.
	 */
	private static function scale_bar( $im, $x, $y, $c ) {
		for ( $i = 0; $i < 4; $i++ ) {
			self::box( $im, $x + $i * 60, $y, $x + ( $i + 1 ) * 60, $y + 10, $i % 2 ? $c['panel'] : $c['steel'], $c['steel'], 2 );
		}
	}

	/**
	 * North arrow.
	 *
	 * @param \GdImage|resource  $im Image.
	 * @param int                $x  Centre x.
	 * @param int                $y  Tip y.
	 * @param array<string, int> $c  Colours.
	 */
	private static function north( $im, $x, $y, $c ) {
		$right = array( $x, $y, $x + 18, $y + 54, $x, $y + 42 );
		$left  = array( $x, $y, $x - 18, $y + 54, $x, $y + 42 );
		// PHP 7.4 requires the point count; PHP 8.1 deprecates passing it.
		if ( PHP_VERSION_ID < 80000 ) {
			imagefilledpolygon( $im, $right, 3, $c['steel'] ); // phpcs:ignore PHPCompatibility.FunctionUse.RemovedFunctionParameters -- Branch runs before PHP 8 only.
			imagepolygon( $im, $left, 3, $c['steel'] ); // phpcs:ignore PHPCompatibility.FunctionUse.RemovedFunctionParameters -- Branch runs before PHP 8 only.
		} else {
			imagefilledpolygon( $im, $right, $c['steel'] ); // phpcs:ignore PHPCompatibility.FunctionUse.RequiredToOptionalFunctionParameters -- Branch runs on PHP 8 only.
			imagepolygon( $im, $left, $c['steel'] ); // phpcs:ignore PHPCompatibility.FunctionUse.RequiredToOptionalFunctionParameters -- Branch runs on PHP 8 only.
		}
	}

	/**
	 * Typical floor plan.
	 *
	 * @param string $type Property type slug.
	 * @param int    $seed Variation.
	 * @return \GdImage|resource
	 */
	private static function draw_plan( $type, $seed ) {
		list( $im, $c ) = self::canvas( 1440, 960 );
		if ( 'industrial' === $type ) {
			self::box( $im, 160, 240, 1280, 720, $c['panel'], $c['steel'], 5 );
			for ( $x = 220; $x < 1240; $x += 80 ) {
				self::box( $im, $x, 712, $x + 50, 740, $c['base'], $c['steel'], 2 );
			}
			for ( $x = 280; $x < 1280; $x += 160 ) {
				for ( $y = 320; $y < 720; $y += 160 ) {
					imagefilledrectangle( $im, $x - 5, $y - 5, $x + 5, $y + 5, $c['steel'] );
				}
			}
			self::box( $im, 160, 240, 360, 360, $c['base'], $c['steel'], 2 );
			self::hatch( $im, 162, 242, 358, 358, $c['line'] );
			$dim = array( 160, 1280, 190 );
		} else {
			self::box( $im, 240, 200, 1200, 760, $c['panel'], $c['steel'], 5 );
			self::box( $im, 620, 380, 820, 580, $c['base'], $c['steel'], 3 );
			self::hatch( $im, 622, 382, 818, 578, $c['slate'] );
			if ( in_array( $type, array( 'multifamily', 'mixed-use' ), true ) ) {
				imageline( $im, 240, 460, 620, 460, $c['steel'] );
				imageline( $im, 240, 500, 620, 500, $c['steel'] );
				imageline( $im, 820, 460, 1200, 460, $c['steel'] );
				imageline( $im, 820, 500, 1200, 500, $c['steel'] );
				for ( $x = 340 + ( $seed % 2 ) * 20; $x < 1200; $x += 140 ) {
					if ( $x > 600 && $x < 840 ) {
						continue;
					}
					imageline( $im, $x, 200, $x, 460, $c['slate'] );
					imageline( $im, $x, 500, $x, 760, $c['slate'] );
				}
			} else {
				for ( $x = 360; $x < 1200; $x += 120 ) {
					for ( $y = 320; $y < 760; $y += 120 ) {
						if ( $x > 600 && $x < 840 && $y > 360 && $y < 600 ) {
							continue;
						}
						imagefilledrectangle( $im, $x - 5, $y - 5, $x + 5, $y + 5, $c['steel'] );
					}
				}
			}
			$dim = array( 240, 1200, 150 );
		}
		// Dimension line with ticks.
		imageline( $im, $dim[0], $dim[2], $dim[1], $dim[2], $c['steel'] );
		foreach ( array( $dim[0], $dim[1] ) as $x ) {
			imageline( $im, $x - 8, $dim[2] + 8, $x + 8, $dim[2] - 8, $c['steel'] );
			imageline( $im, $x, $dim[2] - 14, $x, $dim[2] + 14, $c['steel'] );
		}
		self::north( $im, 1320, 80, $c );
		self::scale_bar( $im, 80, 880, $c );
		return $im;
	}

	/**
	 * Markets.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function markets() {
		$trend = function ( $start, $end ) {
			$labels = array( 'Q3 2024', 'Q4 2024', 'Q1 2025', 'Q2 2025', 'Q3 2025', 'Q4 2025', 'Q1 2026', 'Q2 2026' );
			$out    = array();
			foreach ( $labels as $i => $l ) {
				$wobble = ( 0 === $i % 3 && $i < 7 ) ? 0.1 : 0;
				$out[]  = $l . ', ' . number_format( $start + ( $end - $start ) * $i / 7 + $wobble, 2, '.', '' );
			}
			return implode( "\n", $out );
		};
		return array(
			array(
				'slug'    => 'new-york',
				'title'   => 'New York',
				'excerpt' => 'Manhattan office vacancy has levelled off at 14.2%, with Class A space in Midtown leasing faster than the rest of the island.',
				'content' => array( 'Manhattan office vacancy has levelled off after three years of increases. Leasing is concentrated in renovated Class A buildings near Grand Central and Hudson Yards; older Class B stock in Midtown South and Downtown is where availability remains.', 'Investment volume recovered in the first half of 2026, led by multifamily and by office recapitalisations rather than outright sales.' ),
				'meta'    => array(
					'country'     => 'United States',
					'region'      => 'NY',
					'lat'         => 40.7549,
					'lng'         => -73.984,
					'quarter'     => 'Q2 2026',
					'sectors'     => "Office, 78.40, sf, 14.2, 0.8\nIndustrial, 26.10, sf, 4.6, -0.3\nMultifamily, 71.20, sf, 2.9, -0.4\nRetail, 142.00, sf, 6.8, 0.2",
					'submarkets'  => "Midtown, 14.2, 40.7549, -73.9840\nMidtown South, 11.6, 40.7420, -73.9930\nDowntown, 16.9, 40.7075, -74.0113\nHudson Yards, 9.8, 40.7536, -74.0020",
					'rent_trend'  => $trend( 74.1, 78.4 ),
					'trend_label' => 'Midtown average asking rent',
					'volume'      => 21400000000,
					'since_year'  => 2020,
				),
			),
			array(
				'slug'    => 'chicago',
				'title'   => 'Chicago',
				'excerpt' => 'Fulton Market keeps pulling tenants west while the Central Loop works through the highest vacancy in the city.',
				'content' => array( 'Office demand in Chicago is moving west. Fulton Market and the West Loop account for most new leases, while the Central Loop carries the highest vacancy in the market.', 'Multifamily remains the most liquid sector, with institutional buyers returning to River North and the West Loop.' ),
				'meta'    => array(
					'country'     => 'United States',
					'region'      => 'IL',
					'lat'         => 41.8781,
					'lng'         => -87.6298,
					'quarter'     => 'Q2 2026',
					'sectors'     => "Office, 41.20, sf, 21.4, 0.6\nIndustrial, 9.10, sf, 5.2, 0.4\nMultifamily, 32.50, sf, 4.1, -0.6\nRetail, 38.00, sf, 9.3, -0.1",
					'submarkets'  => "Central Loop, 24.1, 41.8810, -87.6290\nWest Loop, 18.6, 41.8830, -87.6440\nRiver North, 19.2, 41.8920, -87.6340\nFulton Market, 12.4, 41.8866, -87.6487",
					'rent_trend'  => $trend( 39.9, 41.2 ),
					'trend_label' => 'Downtown average asking rent',
					'volume'      => 6200000000,
					'since_year'  => 2020,
				),
			),
			array(
				'slug'    => 'dallas',
				'title'   => 'Dallas',
				'excerpt' => 'New logistics supply has slowed, and Great Southwest vacancy is falling for the first time since 2022.',
				'content' => array( 'Dallas leads the country in new industrial deliveries, but the pipeline has thinned. Great Southwest vacancy is falling for the first time since 2022.', 'Uptown remains the strongest office submarket, with rents above the CBD for the sixth year.' ),
				'meta'    => array(
					'country'     => 'United States',
					'region'      => 'TX',
					'lat'         => 32.7767,
					'lng'         => -96.797,
					'quarter'     => 'Q2 2026',
					'sectors'     => "Office, 33.40, sf, 22.7, 0.3\nIndustrial, 6.70, sf, 7.8, 1.1\nMultifamily, 24.10, sf, 8.2, 0.4\nRetail, 24.60, sf, 6.1, -0.2",
					'submarkets'  => "Uptown, 17.4, 32.7990, -96.8010\nCBD, 27.8, 32.7810, -96.7990\nGreat Southwest, 8.9, 32.7450, -97.0310\nLas Colinas, 21.3, 32.8870, -96.9480",
					'rent_trend'  => $trend( 31.8, 33.4 ),
					'trend_label' => 'Average office asking rent',
					'volume'      => 7900000000,
					'since_year'  => 2020,
				),
			),
			array(
				'slug'    => 'atlanta',
				'title'   => 'Atlanta',
				'excerpt' => 'Logistics leasing around the airport is back above its ten-year average.',
				'content' => array( 'Atlanta logistics leasing is back above its ten-year average, led by the airport and I-20 West submarkets.', 'Office vacancy is high but stable; Midtown and Buckhead hold most of the leasing.' ),
				'meta'    => array(
					'country'     => 'United States',
					'region'      => 'GA',
					'lat'         => 33.749,
					'lng'         => -84.388,
					'quarter'     => 'Q2 2026',
					'sectors'     => "Office, 34.10, sf, 23.9, 0.9\nIndustrial, 6.20, sf, 8.4, 1.4\nMultifamily, 22.80, sf, 7.6, 0.3\nRetail, 22.40, sf, 4.9, -0.3",
					'submarkets'  => "Midtown, 25.1, 33.7840, -84.3830\nBuckhead, 22.6, 33.8480, -84.3730\nAirport, 9.2, 33.6400, -84.4300\nI-20 West, 7.8, 33.7400, -84.5500",
					'rent_trend'  => $trend( 5.4, 6.2 ),
					'trend_label' => 'Average industrial asking rent',
					'volume'      => 5100000000,
					'since_year'  => 2021,
				),
			),
			array(
				'slug'    => 'toronto',
				'title'   => 'Toronto',
				'excerpt' => 'The Financial Core is splitting in two: trophy towers are nearly full while older buildings wait for tenants.',
				'content' => array( 'Toronto office demand favours the newest towers in the Financial Core, where availability is under 10%. Older buildings account for most of the vacant space.', 'Industrial vacancy remains among the lowest in North America.' ),
				'meta'    => array(
					'country'     => 'Canada',
					'region'      => 'ON',
					'lat'         => 43.6532,
					'lng'         => -79.3832,
					'quarter'     => 'Q2 2026',
					'sectors'     => "Office, 52.30, sf, 18.6, 1.2\nIndustrial, 17.90, sf, 4.8, 0.9\nMultifamily, 48.00, sf, 2.1, 0.3\nRetail, 64.50, sf, 3.7, -0.4",
					'submarkets'  => "Financial Core, 17.9, 43.6480, -79.3810\nKing West, 15.2, 43.6440, -79.4000\nYonge and Eglinton, 12.8, 43.7060, -79.3980\nAirport, 6.1, 43.6900, -79.6200",
					'rent_trend'  => $trend( 49.6, 52.3 ),
					'trend_label' => 'Downtown average asking rent',
					'volume'      => 4300000000,
					'since_year'  => 2021,
				),
			),
			array(
				'slug'    => 'denver',
				'title'   => 'Denver',
				'excerpt' => 'Mixed-use blocks in LoDo are trading again as lenders return to the market.',
				'content' => array( 'Denver office vacancy remains high, but mixed-use buildings in LoDo with ground-floor retail are trading again as lenders return.', 'Industrial demand is strongest along the I-70 corridor.' ),
				'meta'    => array(
					'country'     => 'United States',
					'region'      => 'CO',
					'lat'         => 39.7392,
					'lng'         => -104.9903,
					'quarter'     => 'Q2 2026',
					'sectors'     => "Office, 31.60, sf, 26.0, 1.0\nIndustrial, 10.40, sf, 7.9, 0.8\nMultifamily, 26.90, sf, 6.4, 0.2\nRetail, 27.20, sf, 5.0, -0.1",
					'submarkets'  => "LoDo, 22.3, 39.7530, -105.0000\nCherry Creek, 16.4, 39.7180, -104.9530\nDenver Tech Center, 27.9, 39.6000, -104.8900\nI-70 Corridor, 8.7, 39.7800, -104.8700",
					'rent_trend'  => $trend( 30.4, 31.6 ),
					'trend_label' => 'Average office asking rent',
					'volume'      => 2800000000,
					'since_year'  => 2021,
				),
			),
		);
	}

	/**
	 * Experts.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function experts() {
		$e = function ( $number, $title, $market, $job, $spec, $phone, $since, $deals, $volume, $types, $service, $bio ) {
			$email = str_replace( '-', '.', sanitize_title( $title ) ) . '@axis.example';
			return array(
				'number'  => $number,
				'title'   => $title,
				'market'  => $market,
				'excerpt' => $bio[0],
				'content' => $bio,
				'terms'   => array(
					'axis_property_type' => $types,
					'axis_service'       => array( $service ),
				),
				'meta'    => array(
					'title'       => $job,
					'specialties' => $spec,
					'phone'       => $phone,
					'email'       => $email,
					'linkedin'    => 'https://www.linkedin.com/',
					'since'       => $since,
					'deals'       => $deals,
					'volume'      => $volume,
				),
			);
		};
		return array(
			$e( 17, 'David Morgan', 'new-york', 'Executive director, capital markets', 'Investment sales, Recapitalisations', '+1 212 555 0147', 2011, 142, 3800000000, array( 'office', 'multifamily' ), 'capital-markets', array( 'David advises owners on sales and recapitalisations of Manhattan office and multifamily buildings.', 'Before joining in 2011 he worked in acquisitions for a New York pension fund adviser.' ) ),
			$e( 23, 'Amara Okafor', 'chicago', 'Director, tenant representation', 'Office relocations, Lab space', '+1 312 555 0190', 2015, 96, 1100000000, array( 'office' ), 'tenant-representation', array( 'Amara represents occupiers relocating or consolidating in downtown Chicago, from law firms to life science companies.', 'She has worked on more than two million square feet of leases since 2015.' ) ),
			$e( 31, 'Lucía Fernández', 'dallas', 'Managing director, valuation and advisory', 'Portfolio valuation, Debt advisory', '+1 214 555 0123', 2009, 130, 5200000000, array( 'industrial', 'retail' ), 'valuation-and-advisory', array( 'Lucía leads valuation work across Texas, with a focus on industrial and retail portfolios.', 'She is a member of the Appraisal Institute and teaches valuation at a Dallas university.' ) ),
			$e( 38, 'Ben Hartley', 'atlanta', 'Senior vice president, industrial leasing', 'Logistics, Cold storage', '+1 404 555 0168', 2016, 88, 1400000000, array( 'industrial' ), 'landlord-representation', array( 'Ben leases logistics and cold storage buildings for owners across metro Atlanta.', 'He has leased more than four million square feet around the airport and along I-20.' ) ),
			$e( 42, 'Priya Raman', 'toronto', 'Executive vice president, capital markets', 'Office investment, Cross-border capital', '+1 416 555 0132', 2013, 74, 2600000000, array( 'office' ), 'capital-markets', array( 'Priya advises Canadian and international investors buying and selling office buildings in Toronto.', 'She previously worked in real estate investment banking in London.' ) ),
			$e( 45, 'Tom Becker', 'denver', 'Director, development advisory', 'Mixed use, Site selection', '+1 303 555 0176', 2018, 41, 900000000, array( 'mixed-use', 'retail' ), 'development', array( 'Tom works with developers and lenders on mixed-use projects in Denver and along the Front Range.', 'He trained as an architect before moving into advisory work.' ) ),
		);
	}

	/**
	 * Properties.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function properties() {
		$p = function ( $number, $title, $market, $type, $listing, $experts, $meta, $text ) {
			return array(
				'number'  => $number,
				'title'   => $title,
				'market'  => $market,
				'type'    => $type,
				'listing' => $listing,
				'experts' => $experts,
				'meta'    => $meta,
				'excerpt' => $text[0],
				'content' => $text,
			);
		};
		return array(
			$p(
				47,
				'330 Madison Avenue',
				'new-york',
				'office',
				'investment-sale',
				array( 17 ),
				array(
					'address'       => '330 Madison Avenue',
					'city'          => 'New York',
					'region'        => 'NY',
					'postcode'      => '10017',
					'country'       => 'United States',
					'lat'           => 40.7543,
					'lng'           => -73.9787,
					'asset_class'   => 'Class A',
					'size'          => 420000,
					'typical_floor' => 10200,
					'floors'        => 41,
					'year_built'    => 1966,
					'renovated'     => 2019,
					'zoning'        => 'C5-3',
					'occupancy'     => 92,
					'sale_price'    => 84500000,
					'cap_rate'      => 6.2,
					'noi'           => 5240000,
					'tenants'       => 38,
					'featured'      => true,
					'listed'        => '2026-09-12',
				),
				array( 'A 41-storey Class A tower one block from Grand Central, 92% leased to 38 tenants with a weighted average lease term of 6.4 years.', '## Location', 'The building sits on the east side of Madison Avenue between 42nd and 43rd Streets, with direct access to Grand Central Madison and the 4, 5, 6, 7 and S lines.', '## Building', 'The lobby, elevators and mechanical systems were replaced in 2019. Typical floors of 10,200 sf have column-free corners and 9 ft 6 in finished ceilings.' )
			),
			$p(
				51,
				'41 East 57th Street',
				'new-york',
				'retail',
				'investment-sale',
				array( 17 ),
				array(
					'address'     => '41 East 57th Street',
					'city'        => 'New York',
					'region'      => 'NY',
					'postcode'    => '10022',
					'country'     => 'United States',
					'lat'         => 40.7628,
					'lng'         => -73.9718,
					'asset_class' => 'Flagship retail',
					'size'        => 38000,
					'floors'      => 4,
					'year_built'  => 1931,
					'renovated'   => 2014,
					'occupancy'   => 100,
					'sale_price'  => 52000000,
					'cap_rate'    => 5.8,
					'tenants'     => 3,
					'listed'      => '2026-08-30',
				),
				array( 'Four floors of flagship retail on 57th Street, fully leased to three tenants on long leases.' )
			),
			$p(
				63,
				'520 West 28th Street',
				'new-york',
				'multifamily',
				'investment-sale',
				array( 17 ),
				array(
					'address'     => '520 West 28th Street',
					'city'        => 'New York',
					'region'      => 'NY',
					'postcode'    => '10001',
					'country'     => 'United States',
					'lat'         => 40.752,
					'lng'         => -74.0046,
					'asset_class' => '96 units',
					'size'        => 96000,
					'floors'      => 11,
					'units'       => 96,
					'year_built'  => 2017,
					'occupancy'   => 97,
					'sale_price'  => 71400000,
					'cap_rate'    => 4.9,
					'listed'      => '2026-09-02',
				),
				array( 'An eleven-storey rental building beside the High Line with 96 units, 97% occupied.' )
			),
			$p(
				70,
				'75 Varick Street',
				'new-york',
				'office',
				'investment-sale',
				array( 17 ),
				array(
					'address'     => '75 Varick Street',
					'city'        => 'New York',
					'region'      => 'NY',
					'postcode'    => '10013',
					'country'     => 'United States',
					'lat'         => 40.7231,
					'lng'         => -74.0063,
					'asset_class' => 'Class B',
					'size'        => 212000,
					'floors'      => 14,
					'year_built'  => 1930,
					'renovated'   => 2008,
					'occupancy'   => 81,
					'sale_price'  => 63500000,
					'cap_rate'    => 6.9,
					'tenants'     => 22,
					'featured'    => true,
					'listed'      => '2026-07-21',
				),
				array( 'A fourteen-storey loft office building in Hudson Square with large floors and room to raise rents on renewal.' )
			),
			$p(
				89,
				'211 West Kinzie Street',
				'chicago',
				'multifamily',
				'investment-sale',
				array( 23, 17 ),
				array(
					'address'     => '211 West Kinzie Street',
					'city'        => 'Chicago',
					'region'      => 'IL',
					'postcode'    => '60654',
					'country'     => 'United States',
					'lat'         => 41.8893,
					'lng'         => -87.6339,
					'asset_class' => '184 units',
					'size'        => 164000,
					'floors'      => 15,
					'units'       => 184,
					'year_built'  => 2004,
					'parking'     => 120,
					'occupancy'   => 96,
					'sale_price'  => 62300000,
					'cap_rate'    => 5.1,
					'featured'    => true,
					'listed'      => '2026-09-18',
				),
				array( 'A 184-unit River North apartment building with structured parking, 96% occupied.' )
			),
			$p(
				94,
				'180 North Franklin Street',
				'chicago',
				'office',
				'for-lease',
				array( 23 ),
				array(
					'address'       => '180 North Franklin Street',
					'city'          => 'Chicago',
					'region'        => 'IL',
					'postcode'      => '60606',
					'country'       => 'United States',
					'lat'           => 41.8853,
					'lng'           => -87.6355,
					'asset_class'   => 'Class A',
					'size'          => 310000,
					'typical_floor' => 18500,
					'floors'        => 26,
					'year_built'    => 2009,
					'occupancy'     => 84,
					'lease_rate'    => 44.5,
					'listed'        => '2026-06-04',
				),
				array( 'Full floors of 18,500 sf available in a 2009 tower on the river, five minutes from Union Station.' )
			),
			$p(
				112,
				'1400 Mill Race Road',
				'dallas',
				'industrial',
				'investment-sale',
				array( 31 ),
				array(
					'address'     => '1400 Mill Race Road',
					'city'        => 'Grand Prairie',
					'region'      => 'TX',
					'postcode'    => '75050',
					'country'     => 'United States',
					'lat'         => 32.7468,
					'lng'         => -97.026,
					'asset_class' => 'Logistics',
					'size'        => 286000,
					'year_built'  => 2021,
					'lot_size'    => 18.4,
					'parking'     => 140,
					'occupancy'   => 100,
					'sale_price'  => 41000000,
					'cap_rate'    => 5.4,
					'tenants'     => 1,
					'featured'    => true,
					'listed'      => '2026-08-11',
				),
				array( 'A 2021 cross-dock logistics building in Great Southwest, fully leased to a national retailer until 2033.' )
			),
			$p(
				118,
				'2500 Cedar Springs Road',
				'dallas',
				'office',
				'investment-sale',
				array( 31 ),
				array(
					'address'     => '2500 Cedar Springs Road',
					'city'        => 'Dallas',
					'region'      => 'TX',
					'postcode'    => '75201',
					'country'     => 'United States',
					'lat'         => 32.797,
					'lng'         => -96.804,
					'asset_class' => 'Class A',
					'size'        => 280000,
					'floors'      => 20,
					'year_built'  => 2015,
					'occupancy'   => 88,
					'sale_price'  => 96000000,
					'cap_rate'    => 6.4,
					'tenants'     => 24,
					'listed'      => '2026-09-25',
				),
				array( 'A twenty-storey Uptown office tower, 88% leased, with rents above the CBD average.' )
			),
			$p(
				124,
				'4800 Fulton Industrial Boulevard',
				'atlanta',
				'industrial',
				'investment-sale',
				array( 38 ),
				array(
					'address'     => '4800 Fulton Industrial Boulevard',
					'city'        => 'Atlanta',
					'region'      => 'GA',
					'postcode'    => '30336',
					'country'     => 'United States',
					'lat'         => 33.74,
					'lng'         => -84.552,
					'asset_class' => 'Logistics',
					'size'        => 412000,
					'year_built'  => 2018,
					'lot_size'    => 26,
					'occupancy'   => 94,
					'sale_price'  => 48700000,
					'cap_rate'    => 5.9,
					'tenants'     => 3,
					'listed'      => '2026-07-08',
				),
				array( 'A 412,000 sf logistics building on I-20 West with three tenants and 36 ft clear height.' )
			),
			$p(
				131,
				'3300 Peachtree Road',
				'atlanta',
				'office',
				'for-lease',
				array( 38 ),
				array(
					'address'     => '3300 Peachtree Road',
					'city'        => 'Atlanta',
					'region'      => 'GA',
					'postcode'    => '30326',
					'country'     => 'United States',
					'lat'         => 33.843,
					'lng'         => -84.373,
					'asset_class' => 'Class A',
					'size'        => 240000,
					'floors'      => 18,
					'year_built'  => 2001,
					'renovated'   => 2022,
					'occupancy'   => 79,
					'lease_rate'  => 38.5,
					'listed'      => '2026-05-19',
				),
				array( 'Renovated Buckhead office floors with a new amenity level and direct MARTA access.' )
			),
			$p(
				137,
				'88 Wellington Street West',
				'toronto',
				'office',
				'investment-sale',
				array( 42 ),
				array(
					'address'     => '88 Wellington Street West',
					'city'        => 'Toronto',
					'region'      => 'ON',
					'postcode'    => 'M5J 2N7',
					'country'     => 'Canada',
					'lat'         => 43.647,
					'lng'         => -79.383,
					'asset_class' => 'Class A',
					'size'        => 365000,
					'floors'      => 32,
					'year_built'  => 2012,
					'occupancy'   => 91,
					'sale_price'  => 142000000,
					'cap_rate'    => 5.6,
					'tenants'     => 19,
					'featured'    => true,
					'listed'      => '2026-09-08',
				),
				array( 'A 32-storey Financial Core tower connected to the PATH, 91% leased.' )
			),
			$p(
				142,
				'1700 Wynkoop Street',
				'denver',
				'mixed-use',
				'investment-sale',
				array( 45 ),
				array(
					'address'     => '1700 Wynkoop Street',
					'city'        => 'Denver',
					'region'      => 'CO',
					'postcode'    => '80202',
					'country'     => 'United States',
					'lat'         => 39.753,
					'lng'         => -104.999,
					'asset_class' => 'Office over retail',
					'size'        => 128000,
					'floors'      => 7,
					'year_built'  => 1906,
					'renovated'   => 2016,
					'occupancy'   => 89,
					'sale_price'  => 46200000,
					'cap_rate'    => 6.1,
					'tenants'     => 14,
					'listed'      => '2026-08-19',
				),
				array( 'A restored 1906 warehouse in LoDo with offices above street-level restaurants, opposite Union Station.' )
			),
			$p(
				146,
				'4600 Smith Road',
				'denver',
				'industrial',
				'under-offer',
				array( 45 ),
				array(
					'address'     => '4600 Smith Road',
					'city'        => 'Denver',
					'region'      => 'CO',
					'postcode'    => '80216',
					'country'     => 'United States',
					'lat'         => 39.778,
					'lng'         => -104.93,
					'asset_class' => 'Light industrial',
					'size'        => 180000,
					'year_built'  => 1998,
					'lot_size'    => 11.2,
					'occupancy'   => 72,
					'sale_price'  => 22400000,
					'cap_rate'    => 6.8,
					'tenants'     => 6,
					'listed'      => '2026-06-23',
				),
				array( 'A multi-tenant light industrial building on the I-70 corridor with vacancy to lease up.' )
			),
		);
	}

	/**
	 * Transactions.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function transactions() {
		$t = function ( $number, $title, $market, $deal, $type, $service, $date, $experts, $meta, $story, $property = 0 ) {
			return array(
				'number'   => $number,
				'title'    => $title,
				'market'   => $market,
				'deal'     => $deal,
				'type'     => $type,
				'service'  => $service,
				'date'     => $date,
				'experts'  => $experts,
				'property' => $property,
				'excerpt'  => $story[3],
				'content'  => array(),
				'meta'     => array_merge(
					$meta,
					array(
						'story_asset'  => $story[0],
						'story_deal'   => $story[1],
						'story_plan'   => $story[2],
						'story_result' => $story[3],
					)
				),
			);
		};
		return array(
			$t(
				18,
				'Mid-rise apartments on West Kinzie Street',
				'chicago',
				'sale',
				'multifamily',
				'capital-markets',
				'2026-05-14 09:00:00',
				array( 17, 23 ),
				array(
					'value'  => 125000000,
					'year'   => 2026,
					'city'   => 'Chicago, IL',
					'client' => 'Private owner',
					'role'   => 'Seller’s advisor',
				),
				array( 'A 184-unit mid-rise built in 2004, 81% occupied when the owner engaged us, with units below market after a decade without upgrades.', 'A marketed sale to 46 qualified buyers, with eleven first-round bids and three in the final round.', 'We priced on the upgraded rent roll, backed by a unit renovation plan and comparable leasing within half a mile.', 'Closed at $125M, 6% above the initial guidance, in 94 days from launch.' )
			),
			$t(
				21,
				'Recapitalising a Midtown office tower',
				'new-york',
				'recapitalisation',
				'office',
				'capital-markets',
				'2026-03-02 09:00:00',
				array( 17 ),
				array(
					'value'  => 86000000,
					'year'   => 2026,
					'city'   => 'New York, NY',
					'client' => 'Family office',
					'role'   => 'Capital advisor',
				),
				array( 'A 1960s Midtown tower, 74% leased, with a loan maturing in nine months.', 'A preferred equity raise from a field of 14 investors, closed alongside a loan extension.', 'We showed investors the leasing already signed in the renovated lobby floors rather than the vacancy.', 'Raised $86M of preferred equity and extended the senior loan by three years.' )
			),
			$t(
				24,
				'A 286,000 sf logistics lease in Great Southwest',
				'dallas',
				'lease',
				'industrial',
				'landlord-representation',
				'2026-02-10 09:00:00',
				array( 31 ),
				array(
					'value'  => 41000000,
					'year'   => 2026,
					'city'   => 'Dallas, TX',
					'client' => 'National retailer',
					'role'   => 'Landlord representation',
				),
				array( 'A newly delivered cross-dock building, vacant at completion in a market with record new supply.', 'A ten-year lease to a national retailer for the whole building.', 'We marketed the building to occupiers needing cross-dock capacity near DFW Airport before it was finished.', 'Fully leased four months after completion, at a rent 4% above the pro forma.' ),
				112
			),
			$t(
				27,
				'Cross-dock facility off I-20',
				'atlanta',
				'sale',
				'industrial',
				'capital-markets',
				'2025-10-22 09:00:00',
				array( 38 ),
				array(
					'value'  => 58000000,
					'year'   => 2025,
					'city'   => 'Atlanta, GA',
					'client' => 'Private developer',
					'role'   => 'Seller’s advisor',
				),
				array( 'A 520,000 sf cross-dock building, 100% leased to two tenants.', 'A targeted sale to eight core-plus buyers.', 'We split the offering to show each tenant lease separately so buyers could price the credit.', 'Sold for $58M at a 5.6% cap rate.' )
			),
			$t(
				29,
				'Three-tower office portfolio in the Financial Core',
				'toronto',
				'portfolio-sale',
				'office',
				'capital-markets',
				'2025-12-03 09:00:00',
				array( 42 ),
				array(
					'value'  => 210000000,
					'year'   => 2025,
					'city'   => 'Toronto, ON',
					'client' => 'Pension fund',
					'role'   => 'Seller’s advisor',
				),
				array( 'Three older towers in the Financial Core with 1.1 million sf combined, averaging 83% occupancy.', 'A portfolio sale with the option to bid on individual buildings.', 'Offering each tower separately brought in buyers who would not take the whole portfolio.', 'All three buildings sold to two buyers for a combined $210M.' )
			),
			$t(
				31,
				'Refinancing a LoDo mixed-use block',
				'denver',
				'debt-placement',
				'mixed-use',
				'development',
				'2026-06-18 09:00:00',
				array( 45 ),
				array(
					'value'  => 33000000,
					'year'   => 2026,
					'city'   => 'Denver, CO',
					'client' => 'Local owner',
					'role'   => 'Debt advisor',
				),
				array( 'A restored warehouse with offices above restaurants, 89% leased, with a construction loan coming due.', 'A five-year fixed-rate loan from a regional bank.', 'We showed lenders the retail sales figures to support the ground-floor rents.', 'Placed $33M of debt at 62% loan to value.' )
			),
		);
	}

	/**
	 * Research.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function research() {
		return array(
			array(
				'number'  => 26,
				'title'   => 'Midtown office: vacancy has stopped rising',
				'type'    => 'market-report',
				'types'   => array( 'office' ),
				'date'    => '2026-07-15 09:00:00',
				'markets' => array( 'new-york' ),
				'experts' => array( 17 ),
				'pages'   => 32,
				'image'   => true,
				'excerpt' => 'Midtown vacancy held at 14.2% in the second quarter, the first quarter without an increase since 2022.',
				'content' => array( 'Midtown vacancy held at 14.2% in the second quarter, the first quarter without an increase since 2022.', '## What changed', 'Tenants signed 4.1 million sf of leases in Midtown in the first half, 60% of it in buildings renovated since 2018.', '## What to watch', 'Older buildings without a renovation plan still account for most available space.' ),
				'meta'    => array( 'figures' => "14.2%, Midtown vacancy, Up 0.8 pts on a year\n$78.40, Average asking rent per sf, Up 3.1% on a year\n$21.4B, Capital volume, first half 2026" ),
				'csv'     => "submarket,vacancy_pct,asking_rent_sf\nMidtown,14.2,78.40\nMidtown South,11.6,72.10\nDowntown,16.9,61.30\nHudson Yards,9.8,104.50\n",
			),
			array(
				'number'  => 28,
				'title'   => 'Chicago multifamily: institutional buyers are back',
				'type'    => 'outlook',
				'types'   => array( 'multifamily' ),
				'date'    => '2026-06-02 09:00:00',
				'markets' => array( 'chicago' ),
				'experts' => array( 23, 17 ),
				'pages'   => 18,
				'excerpt' => 'Institutional buyers accounted for 58% of downtown apartment sales in the first half.',
				'content' => array( 'Institutional buyers accounted for 58% of downtown apartment sales in the first half, up from 31% a year earlier.' ),
				'meta'    => array( 'figures' => "58%, Share of sales to institutions, Up 27 pts on a year\n4.1%, Multifamily vacancy, Down 0.6 pts on a year" ),
			),
			array(
				'number'  => 30,
				'title'   => 'Sun Belt logistics vacancy has peaked',
				'type'    => 'data-brief',
				'types'   => array( 'industrial' ),
				'date'    => '2026-08-20 09:00:00',
				'markets' => array( 'dallas', 'atlanta' ),
				'experts' => array( 31, 38 ),
				'pages'   => 6,
				'excerpt' => 'New supply in Dallas and Atlanta has fallen by half since 2024, and vacancy is turning.',
				'content' => array( 'New logistics supply in Dallas and Atlanta has fallen by half since 2024. Vacancy rose by less than a tenth of a point in the second quarter in both markets.' ),
				'meta'    => array( 'figures' => "7.8%, Dallas industrial vacancy, Up 1.1 pts on a year\n8.4%, Atlanta industrial vacancy, Up 1.4 pts on a year" ),
			),
			array(
				'number'  => 31,
				'title'   => 'What a recapitalisation buys an office owner',
				'type'    => 'perspective',
				'types'   => array( 'office' ),
				'date'    => '2026-09-09 09:00:00',
				'markets' => array( 'new-york' ),
				'experts' => array( 17 ),
				'excerpt' => 'Time, mostly. Why owners with good buildings and bad loans are raising equity instead of selling.',
				'content' => array( 'Owners with good buildings and maturing loans are raising preferred equity instead of selling into a thin market.', '## The trade', 'Preferred equity costs more than senior debt but less than selling at today’s pricing. It buys the time to finish leasing.' ),
				'meta'    => array(),
			),
			array(
				'number'  => 33,
				'title'   => 'Toronto office: the flight to quality in numbers',
				'type'    => 'market-report',
				'types'   => array( 'office' ),
				'date'    => '2026-08-05 09:00:00',
				'markets' => array( 'toronto' ),
				'experts' => array( 42 ),
				'pages'   => 24,
				'image'   => true,
				'excerpt' => 'Towers built since 2010 are 92% leased; older buildings in the same blocks are 76% leased.',
				'content' => array( 'Towers built since 2010 are 92% leased. Older buildings in the same blocks are 76% leased.' ),
				'meta'    => array( 'figures' => "92%, Leased, towers built since 2010\n76%, Leased, towers built before 2000" ),
			),
		);
	}
}
