<?php
/**
 * Shared markup: cards, tables, figures, filters, empty states, pagination.
 *
 * Every function returns escaped HTML.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Render helpers used by the blocks.
 */
class Render {

	/**
	 * Read a GET filter. Filters are read-only listing parameters, so no nonce is involved.
	 *
	 * @param string $key  Parameter.
	 * @param string $type One of key, int, float, text.
	 * @return mixed
	 */
	public static function query_var( $key, $type = 'key' ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public, read-only filter parameters.
		if ( ! isset( $_GET[ $key ] ) || '' === $_GET[ $key ] ) {
			return '';
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- As above.
		$raw = wp_unslash( $_GET[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Recommended -- Sanitised below by type; read-only filter.
		if ( is_array( $raw ) ) {
			return '';
		}
		switch ( $type ) {
			case 'int':
				return absint( $raw );
			case 'float':
				$raw = str_replace( array( ',', '$', '%', ' ' ), '', (string) $raw );
				return is_numeric( $raw ) ? (float) $raw : '';
			case 'text':
				return sanitize_text_field( (string) $raw );
			default:
				return sanitize_key( (string) $raw );
		}
	}

	/**
	 * Photograph or a survey-grid placeholder.
	 *
	 * @param int    $attachment_id Attachment ID.
	 * @param string $size          Image size.
	 * @param string $extra_class   Extra class.
	 * @return string
	 */
	public static function image( $attachment_id, $size = 'large', $extra_class = '' ) {
		if ( $attachment_id ) {
			$img = wp_get_attachment_image(
				$attachment_id,
				$size,
				false,
				array(
					'class' => trim( 'axis-cre-image ' . $extra_class ),
				)
			);
			if ( $img ) {
				return $img;
			}
		}
		return '<div class="axis-cre-placeholder ' . esc_attr( $extra_class ) . '" aria-hidden="true"></div>';
	}

	/**
	 * Asset class with its hatch.
	 *
	 * @param string $slug Property type slug.
	 * @param string $text Label.
	 * @return string
	 */
	public static function asset_class( $slug, $text ) {
		if ( '' === $text ) {
			return '';
		}
		return '<span class="axis-class axis-class--' . esc_attr( $slug ) . '">' . esc_html( $text ) . '</span>';
	}

	/**
	 * Status chip.
	 *
	 * @param string $text Status.
	 * @return string
	 */
	public static function status( $text ) {
		return '' === $text ? '' : '<span class="axis-status">' . esc_html( $text ) . '</span>';
	}

	/**
	 * Value and label pairs as a definition list.
	 *
	 * @param array<int, array{0: string, 1: string}> $metrics Pairs of value and label.
	 * @param string                                  $extra_class   Extra class.
	 * @return string
	 */
	public static function metrics( $metrics, $extra_class = '' ) {
		if ( ! $metrics ) {
			return '';
		}
		$out = '<dl class="axis-cre-metrics ' . esc_attr( $extra_class ) . '">';
		foreach ( $metrics as $m ) {
			$out .= '<div><dt>' . esc_html( $m[1] ) . '</dt><dd>' . esc_html( $m[0] ) . '</dd></div>';
		}
		return $out . '</dl>';
	}

	/**
	 * Large figures under steel rules: value, label, optional note.
	 *
	 * @param array<int, array{value: string, label: string, note?: string}> $figures Figures.
	 * @return string
	 */
	public static function figures( $figures ) {
		$figures = array_values(
			array_filter(
				$figures,
				function ( $f ) {
					return '' !== (string) $f['value'];
				}
			)
		);
		if ( ! $figures ) {
			return '';
		}
		$out = '<dl class="axis-cre-figures">';
		foreach ( $figures as $f ) {
			$out .= '<div class="axis-metric"><dt>' . esc_html( $f['label'] ) . '</dt><dd class="axis-cre-figure">' . esc_html( $f['value'] ) . '</dd>';
			if ( ! empty( $f['note'] ) ) {
				$out .= '<dd class="axis-cre-note">' . esc_html( $f['note'] ) . '</dd>';
			}
			$out .= '</div>';
		}
		return $out . '</dl>';
	}

	/**
	 * Inline stroke icon. Decorative unless a label is given.
	 *
	 * @param string $name  Icon name.
	 * @param string $label Accessible name, or empty for decorative.
	 * @return string
	 */
	public static function icon( $name, $label = '' ) {
		$paths = array(
			'heart'    => '<path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7Z"/>',
			'compare'  => '<path d="m16 3 4 4-4 4"/><path d="M20 7H4"/><path d="m8 21-4-4 4-4"/><path d="M4 17h16"/>',
			'camera'   => '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3Z"/><circle cx="12" cy="13" r="3"/>',
			'building' => '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01M16 6h.01M12 6h.01M12 10h.01M12 14h.01M16 10h.01M16 14h.01M8 10h.01M8 14h.01"/>',
			'pin'      => '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
			'area'     => '<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/>',
			'pie'      => '<path d="M21.2 15.9A10 10 0 1 1 8 2.8"/><path d="M22 12A10 10 0 0 0 12 2v10Z"/>',
			'percent'  => '<path d="M19 5 5 19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
			'layers'   => '<path d="m12 2 10 5-10 5L2 7Z"/><path d="m2 17 10 5 10-5"/><path d="m2 12 10 5 10-5"/>',
			'left'     => '<path d="m15 18-6-6 6-6"/>',
			'right'    => '<path d="m9 18 6-6-6-6"/>',
			'arrow'    => '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
			'phone'    => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z"/>',
			'mail'     => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
			'card'     => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M15 8h2M15 12h2M7 16h10"/>',
			'calendar' => '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
			'file'     => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/>',
			'search'   => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
			'close'    => '<path d="M18 6 6 18M6 6l12 12"/>',
		);
		if ( ! isset( $paths[ $name ] ) ) {
			return '';
		}
		$a11y = '' === $label ? 'aria-hidden="true" focusable="false"' : 'role="img" aria-label="' . esc_attr( $label ) . '"';
		return '<svg class="axis-cre-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ' . $a11y . '>' . $paths[ $name ] . '</svg>';
	}

	/**
	 * Initials for an avatar.
	 *
	 * @param string $name Name.
	 * @return string
	 */
	public static function initials( $name ) {
		$parts = preg_split( '/\s+/', trim( remove_accents( $name ) ) );
		$out   = '';
		foreach ( array_slice( $parts, 0, 2 ) as $w ) {
			$out .= mb_strtoupper( mb_substr( $w, 0, 1 ) );
		}
		return $out;
	}

	/**
	 * Listing card assets: the card script is printed once, in the footer, when a card is on the page.
	 */
	public static function card_assets() {
		static $done = false;
		if ( $done ) {
			return;
		}
		$done = true;
		wp_enqueue_script( 'axis-cre-cards' );
		wp_localize_script( 'axis-cre-cards', 'axisCreCards', Blocks::card_strings() );
	}

	/**
	 * URL of the shortlist page: the page set in Settings, else a page with the slug "shortlist".
	 *
	 * @return string Empty when there is no shortlist page.
	 */
	public static function shortlist_url() {
		$id = Format::settings()['shortlist'];
		if ( ! $id || 'publish' !== get_post_status( $id ) ) {
			$page = get_page_by_path( 'shortlist' );
			$id   = $page && 'publish' === $page->post_status ? $page->ID : 0;
		}
		$url = $id ? (string) get_permalink( $id ) : '';
		/**
		 * Filters the shortlist page URL used by save, compare and the header counters.
		 *
		 * @param string $url Shortlist URL, or empty for none.
		 */
		return (string) apply_filters( 'axis_cre_shortlist_url', $url );
	}

	/**
	 * Price line on the photo: price or rent, with a per-unit note.
	 *
	 * @param array<string, mixed> $p Property record.
	 * @return array{0: string, 1: string}
	 */
	public static function price_parts( $p ) {
		if ( $p['price'] ) {
			$note = '';
			if ( $p['units'] ) {
				/* translators: %s: price per unit, for example $339K. */
				$note = sprintf( __( '%s / unit', 'axis-cre' ), Format::money( $p['price'] / $p['units'] ) );
			} elseif ( $p['size'] ) {
				$note = Format::rent( round( $p['price'] / $p['size'] ) );
				$note = preg_replace( '/\.00 /', ' ', $note );
			}
			return array( Format::money( $p['price'] ), $note );
		}
		if ( $p['lease'] ) {
			/* translators: %s: area unit, for example sf. */
			return array( Format::settings()['currency'] . number_format_i18n( $p['lease'], 2 ), sprintf( __( 'per %s, per year', 'axis-cre' ), Format::area_unit() ) );
		}
		return array( __( 'Price on request', 'axis-cre' ), '' );
	}

	/**
	 * Status badge class from the listing type.
	 *
	 * @param string $slug Listing type slug.
	 * @return string
	 */
	public static function status_class( $slug ) {
		$map = array(
			'for-lease'   => 'is-lease',
			'leased'      => 'is-closed',
			'sold'        => 'is-closed',
			'under-offer' => 'is-offer',
		);
		return isset( $map[ $slug ] ) ? $map[ $slug ] : 'is-sale';
	}

	/**
	 * Listing card: photo first, status and price on the photo, save and compare,
	 * photos you can step through, three commercial figures and the listing broker.
	 * The title link covers the card; the buttons sit above it.
	 *
	 * @param array<string, mixed> $p      Property record.
	 * @param string               $layout grid, list or compact.
	 * @param array<string, mixed> $extra  Extra wrapper attributes (already safe keys).
	 * @return string
	 */
	public static function asset_card( $p, $layout = 'grid', $extra = array() ) {
		self::card_assets();
		$attrs = '';
		foreach ( $extra as $k => $v ) {
			$attrs .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
		}
		list( $price, $note ) = self::price_parts( $p );
		$photos               = $p['photos'] ? $p['photos'] : array( 0 );
		$n                    = count( $photos );
		$size                 = 'compact' === $layout ? 'medium_large' : 'large';
		$data                 = array(
			'id'    => $p['id'],
			'title' => $p['title'],
			'url'   => $p['url'],
			'price' => $price,
			'photo' => $p['image'] ? (string) wp_get_attachment_image_url( $p['image'], 'thumbnail' ) : '',
		);

		$out  = '<article class="axis-cre-card axis-cre-asset is-' . esc_attr( $layout ) . '" data-axis-listing="' . esc_attr( wp_json_encode( $data ) ) . '"' . $attrs . '>';
		$out .= '<div class="axis-cre-card__media" data-count="' . (int) $n . '">';
		$out .= '<div class="axis-cre-card__photos">';
		foreach ( $photos as $i => $id ) {
			$alt = $id ? (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) : '';
			/* translators: 1: listing name, 2: photo number, 3: number of photos. */
			$alt  = $alt ? $alt : sprintf( __( '%1$s, photo %2$d of %3$d', 'axis-cre' ), $p['title'], $i + 1, $n );
			$out .= '<figure class="axis-cre-card__photo' . ( 0 === $i ? ' is-active' : '' ) . '"' . ( 0 === $i ? '' : ' hidden' ) . '>';
			$out .= $id ? wp_get_attachment_image(
				$id,
				$size,
				false,
				array(
					'alt'     => $alt,
					'loading' => 'lazy',
				)
			) : '<div class="axis-cre-placeholder" aria-hidden="true"></div>';
			$out .= '</figure>';
		}
		$out .= '</div>';

		// Badges: status in words, and Featured.
		$out .= '<p class="axis-cre-card__badges">';
		if ( $p['status'] ) {
			$out .= '<span class="axis-cre-badge ' . esc_attr( self::status_class( $p['status_slug'] ) ) . '">' . esc_html( $p['status'] ) . '</span>';
		}
		if ( $p['featured'] && 'compact' !== $layout ) {
			$out .= '<span class="axis-cre-badge is-featured">' . esc_html__( 'Featured', 'axis-cre' ) . '</span>';
		}
		$out .= '</p>';

		// Save and compare; labels are completed by the card script.
		/* translators: %s: listing name. */
		$save = sprintf( __( 'Save %s', 'axis-cre' ), $p['title'] );
		/* translators: %s: listing name. */
		$cmp  = sprintf( __( 'Compare %s', 'axis-cre' ), $p['title'] );
		$out .= '<div class="axis-cre-card__actions">';
		$out .= '<button type="button" class="axis-cre-action" data-axis-action="save" aria-pressed="false" aria-label="' . esc_attr( $save ) . '">' . self::icon( 'heart' ) . '</button>';
		$out .= '<button type="button" class="axis-cre-action" data-axis-action="compare" aria-pressed="false" aria-label="' . esc_attr( $cmp ) . '">' . self::icon( 'compare' ) . '</button>';
		$out .= '</div>';

		if ( $n > 1 ) {
			$out .= '<div class="axis-cre-card__nav">';
			$out .= '<button type="button" class="axis-cre-photo-btn" data-axis-photo="-1" aria-label="' . esc_attr__( 'Previous photo', 'axis-cre' ) . '">' . self::icon( 'left' ) . '</button>';
			$out .= '<button type="button" class="axis-cre-photo-btn" data-axis-photo="1" aria-label="' . esc_attr__( 'Next photo', 'axis-cre' ) . '">' . self::icon( 'right' ) . '</button>';
			$out .= '</div><p class="axis-cre-card__dots" aria-hidden="true">';
			for ( $i = 0; $i < $n; $i++ ) {
				$out .= '<span' . ( 0 === $i ? ' class="is-on"' : '' ) . '></span>';
			}
			$out .= '</p>';
		}
		if ( 'compact' !== $layout ) {
			$out .= '<p class="axis-cre-card__price"><span class="axis-cre-card__amount">' . esc_html( $price ) . '</span>' . ( $note ? '<span class="axis-cre-card__per">' . esc_html( $note ) . '</span>' : '' ) . '</p>';
		}
		if ( $p['photos'] ) {
			$out .= '<p class="axis-cre-card__count">' . self::icon( 'camera' ) . '<span><span class="axis-cre-card__index">1</span>&thinsp;/&thinsp;' . (int) $n . '<span class="screen-reader-text"> ' . esc_html__( 'photos', 'axis-cre' ) . '</span></span></p>';
		}
		$out .= '</div>';

		// Body.
		$type_line = trim( implode( ', ', array_filter( array( $p['type_name'], $p['class'] ) ) ) );
		$place     = trim( implode( ', ', array_filter( array( $p['address'] && 'list' === $layout ? $p['address'] : '', $p['city'] ) ) ) );
		$out      .= '<div class="axis-cre-card__body">';
		if ( $type_line ) {
			$out .= '<p class="axis-cre-card__type axis-class axis-class--' . esc_attr( $p['type'] ) . '">' . self::icon( 'building' ) . esc_html( $type_line ) . '</p>';
		}
		$out .= '<h3 class="axis-cre-card__title"><a href="' . esc_url( $p['url'] ) . '">' . esc_html( $p['title'] ) . '</a></h3>';
		if ( $place || ! empty( $p['distance_label'] ) ) {
			$out .= '<p class="axis-cre-card__place">' . self::icon( 'pin' ) . '<span>' . esc_html( $place ) . '</span>';
			if ( ! empty( $p['distance_label'] ) ) {
				$out .= '<span class="axis-cre-card__distance">' . esc_html( $p['distance_label'] ) . '</span>';
			}
			$out .= '</p>';
		}
		if ( ! empty( $p['reason'] ) ) {
			$out .= '<p class="axis-cre-card__reason">' . esc_html( $p['reason'] ) . '</p>';
		}
		if ( 'compact' === $layout ) {
			$out .= '<p class="axis-cre-card__compact-price">' . esc_html( $price ) . ( $note ? ' <span>' . esc_html( $note ) . '</span>' : '' ) . '</p>';
		}

		$figs = array(
			array( 'area', 'list' === $layout ? Format::area( $p['size'] ) : Format::area_short( $p['size'] ), __( 'Building', 'axis-cre' ) ),
			array( 'pie', Format::percent( $p['occupancy'] ), __( 'Occupied', 'axis-cre' ) ),
		);
		if ( $p['lease'] && ! $p['price'] ) {
			$figs[] = array( 'layers', 'list' === $layout ? Format::area( $p['floor'] ) : Format::area_short( $p['floor'] ), __( 'Floors from', 'axis-cre' ) );
		} else {
			$figs[] = array( 'percent', Format::percent( $p['cap'] ), __( 'Cap rate', 'axis-cre' ) );
		}
		if ( 'list' === $layout && $p['year'] ) {
			$figs[] = array( 'calendar', (string) $p['year'], __( 'Built', 'axis-cre' ) );
		}
		$figs = array_values(
			array_filter(
				$figs,
				function ( $f ) {
					return '' !== $f[1];
				}
			)
		);
		if ( $figs ) {
			$out .= '<dl class="axis-cre-card__figures">';
			foreach ( $figs as $f ) {
				$out .= '<div><dd>' . self::icon( $f[0] ) . '<span>' . esc_html( $f[1] ) . '</span></dd><dt>' . esc_html( $f[2] ) . '</dt></div>';
			}
			$out .= '</dl>';
		}
		$out .= '</div>';

		if ( 'compact' !== $layout ) {
			$out .= '<div class="axis-cre-card__foot">';
			if ( $p['broker'] ) {
				$b    = $p['broker'];
				$face = $b['image'] ? wp_get_attachment_image(
					$b['image'],
					'thumbnail',
					false,
					array(
						'alt'     => '',
						'class'   => 'axis-cre-avatar',
						'loading' => 'lazy',
					)
				) : '<span class="axis-cre-avatar" aria-hidden="true">' . esc_html( self::initials( $b['title'] ) ) . '</span>';
				$out .= '<p class="axis-cre-card__broker">' . $face . '<span>' . esc_html( $b['title'] ) . '</span></p>';
			} else {
				$out .= '<p class="axis-cre-card__broker"><span>' . esc_html( $p['label'] ) . '</span></p>';
			}
			$out .= '<span class="axis-cre-card__cta" aria-hidden="true">' . esc_html__( 'Details', 'axis-cre' ) . self::icon( 'arrow' ) . '</span>';
			$out .= '</div>';
		}
		return $out . '</article>';
	}

	/**
	 * Comparable rows of assets.
	 *
	 * @param array<int, array<string, mixed>> $items   Property records.
	 * @param string                           $caption Accessible caption.
	 * @return string
	 */
	public static function asset_table( $items, $caption ) {
		$out  = '<section class="axis-cre-table-wrap" aria-label="' . esc_attr( $caption ) . '" tabindex="0"><table class="axis-cre-table">';
		$out .= '<caption class="screen-reader-text">' . esc_html( $caption ) . '</caption><thead><tr>';
		$cols = array(
			__( 'Asset', 'axis-cre' )    => '',
			__( 'Type', 'axis-cre' )     => '',
			__( 'Size', 'axis-cre' )     => 'num',
			__( 'Occupied', 'axis-cre' ) => 'num',
			__( 'Asking', 'axis-cre' )   => 'num',
			__( 'Cap rate', 'axis-cre' ) => 'num',
			__( 'Status', 'axis-cre' )   => '',
		);
		foreach ( $cols as $label => $cls ) {
			$out .= '<th scope="col" class="' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</th>';
		}
		$out .= '</tr></thead><tbody>';
		foreach ( $items as $p ) {
			$out .= '<tr>';
			$out .= '<th scope="row"><span class="is-style-technical-label">' . esc_html( $p['label'] ) . '</span><a href="' . esc_url( $p['url'] ) . '">' . esc_html( $p['title'] ) . '</a></th>';
			$out .= '<td>' . self::asset_class( $p['type'], $p['type_name'] ) . '</td>';
			$out .= '<td class="num">' . esc_html( Format::area( $p['size'] ) ) . '</td>';
			$out .= '<td class="num">' . esc_html( Format::percent( $p['occupancy'] ) ) . '</td>';
			$out .= '<td class="num">' . esc_html( $p['price'] ? Format::money( $p['price'] ) : Format::rent( $p['lease'] ) ) . '</td>';
			$out .= '<td class="num">' . esc_html( Format::percent( $p['cap'] ) ) . '</td>';
			$out .= '<td>' . esc_html( $p['status'] ) . '</td>';
			$out .= '</tr>';
		}
		return $out . '</tbody></table></section>';
	}

	/**
	 * Photo for a card, from a post's featured image or a fallback.
	 *
	 * @param int    $id    Attachment ID.
	 * @param string $size  Size.
	 * @return string
	 */
	private static function card_photo( $id, $size = 'large' ) {
		return '<div class="axis-cre-card__media"><div class="axis-cre-card__photos"><figure class="axis-cre-card__photo is-active">' . self::image( $id, $size ) . '</figure></div>';
	}

	/**
	 * Transaction card: photo, value and deal type on the photo, title, place, client and role.
	 *
	 * @param array<string, mixed> $t Transaction record.
	 * @return string
	 */
	public static function transaction_card( $t ) {
		$thumb = (int) get_post_thumbnail_id( $t['id'] );
		$out   = '<article class="axis-cre-card axis-cre-transaction">';
		$out  .= self::card_photo( $thumb );
		$out  .= '<p class="axis-cre-card__badges"><span class="axis-cre-badge is-sale">' . esc_html( $t['deal'] ) . '</span></p>';
		$out  .= '<p class="axis-cre-card__price"><span class="axis-cre-card__amount">' . esc_html( $t['value_fmt'] ) . '</span><span class="axis-cre-card__per">' . esc_html( trim( $t['type_name'] . ( $t['year'] ? ', ' . $t['year'] : '' ), ', ' ) ) . '</span></p></div>';
		$out  .= '<div class="axis-cre-card__body">';
		$out  .= '<p class="axis-cre-card__type">' . self::icon( 'building' ) . esc_html( $t['label'] ) . '</p>';
		$out  .= '<h3 class="axis-cre-card__title"><a href="' . esc_url( $t['url'] ) . '">' . esc_html( $t['title'] ) . '</a></h3>';
		if ( $t['city'] ) {
			$out .= '<p class="axis-cre-card__place">' . self::icon( 'pin' ) . esc_html( $t['city'] ) . '</p>';
		}
		$rows = array_filter(
			array(
				__( 'Client', 'axis-cre' )   => $t['client'],
				__( 'Our role', 'axis-cre' ) => $t['role'],
			)
		);
		if ( $rows ) {
			$out .= '<dl class="axis-cre-card__facts">';
			foreach ( $rows as $k => $v ) {
				$out .= '<div><dt>' . esc_html( $k ) . '</dt><dd>' . esc_html( $v ) . '</dd></div>';
			}
			$out .= '</dl>';
		}
		return $out . '</div></article>';
	}

	/**
	 * Expert card: portrait or initials, market, name, role, track record and quick contact.
	 *
	 * @param array<string, mixed> $e Expert record.
	 * @return string
	 */
	public static function expert_card( $e ) {
		$market = $e['markets'] ? $e['markets'][0]['title'] : '';
		$out    = '<article class="axis-cre-card axis-cre-expert">';
		$out   .= '<div class="axis-cre-card__media is-portrait">';
		$out   .= $e['image'] ? self::image( $e['image'], 'medium_large' ) : '<span class="axis-cre-expert__initials" aria-hidden="true">' . esc_html( self::initials( $e['title'] ) ) . '</span>';
		if ( $market ) {
			$out .= '<p class="axis-cre-card__badges"><span class="axis-cre-badge is-light">' . esc_html( $market ) . '</span></p>';
		}
		$links = '';
		if ( $e['phone'] ) {
			/* translators: %s: expert name. */
			$links .= '<a class="axis-cre-action" href="' . esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $e['phone'] ), array( 'tel' ) ) . '" aria-label="' . esc_attr( sprintf( __( 'Call %s', 'axis-cre' ), $e['title'] ) ) . '">' . self::icon( 'phone' ) . '</a>';
		}
		if ( $e['email'] ) {
			/* translators: %s: expert name. */
			$links .= '<a class="axis-cre-action" href="' . esc_url( 'mailto:' . antispambot( $e['email'] ), array( 'mailto' ) ) . '" aria-label="' . esc_attr( sprintf( __( 'Email %s', 'axis-cre' ), $e['title'] ) ) . '">' . self::icon( 'mail' ) . '</a>';
		}
		/* translators: %s: expert name. */
		$links .= '<a class="axis-cre-action" href="' . esc_url( rest_url( 'axis-cre/v1/experts/' . $e['id'] . '/vcard' ) ) . '" download aria-label="' . esc_attr( sprintf( __( 'Download contact card for %s', 'axis-cre' ), $e['title'] ) ) . '">' . self::icon( 'card' ) . '</a>';
		$out   .= '<p class="axis-cre-expert__contact">' . $links . '</p></div>';
		$out   .= '<div class="axis-cre-card__body is-centered">';
		$out   .= '<h3 class="axis-cre-card__title"><a href="' . esc_url( $e['url'] ) . '">' . esc_html( $e['title'] ) . '</a></h3>';
		$out   .= '<p class="axis-cre-card__role">' . esc_html( $e['job'] ? $e['job'] : $e['role_line'] ) . '</p>';
		$figs   = array_filter(
			array(
				$e['deals'] ? array( number_format_i18n( $e['deals'] ), __( 'Transactions', 'axis-cre' ) ) : null,
				$e['volume'] ? array( Format::money( $e['volume'] ), __( 'Volume', 'axis-cre' ) ) : null,
			)
		);
		if ( $figs ) {
			$out .= '<dl class="axis-cre-card__record">';
			foreach ( $figs as $f ) {
				$out .= '<div><dd>' . esc_html( $f[0] ) . '</dd><dt>' . esc_html( $f[1] ) . '</dt></div>';
			}
			$out .= '</dl>';
		}
		return $out . '</div></article>';
	}

	/**
	 * Research card: photo, type and date, title, excerpt, download note.
	 *
	 * @param array<string, mixed> $r Research record.
	 * @return string
	 */
	public static function research_card( $r ) {
		$thumb = (int) get_post_thumbnail_id( $r['id'] );
		if ( ! $thumb && $r['markets'] ) {
			$thumb = (int) get_post_thumbnail_id( $r['markets'][0]['id'] );
		}
		$out  = '<article class="axis-cre-card axis-cre-research">';
		$out .= self::card_photo( $thumb, 'medium_large' ) . '</div>';
		$out .= '<div class="axis-cre-card__body">';
		$out .= '<p class="axis-cre-card__meta"><span class="axis-cre-badge is-soft">' . esc_html( $r['type'] ) . '</span><span>' . esc_html( get_the_date( _x( 'F Y', 'research card date', 'axis-cre' ), $r['id'] ) ) . '</span></p>';
		$out .= '<h3 class="axis-cre-card__title"><a href="' . esc_url( $r['url'] ) . '">' . esc_html( $r['title'] ) . '</a></h3>';
		$ex   = wp_strip_all_tags( get_the_excerpt( $r['id'] ) );
		if ( $ex ) {
			$out .= '<p class="axis-cre-card__excerpt">' . esc_html( wp_trim_words( $ex, 22 ) ) . '</p>';
		}
		$foot = $r['pdf'] ? __( 'Download report', 'axis-cre' ) : __( 'Read the brief', 'axis-cre' );
		$meta = $r['pages'] ? sprintf( /* translators: %d: number of pages. */ _n( 'PDF, %d page', 'PDF, %d pages', $r['pages'], 'axis-cre' ), $r['pages'] ) : '';
		$out .= '<p class="axis-cre-card__foot is-plain"><span class="axis-cre-card__cta" aria-hidden="true">' . esc_html( $foot ) . self::icon( 'arrow' ) . '</span><span>' . esc_html( $meta ) . '</span></p>';
		return $out . '</div></article>';
	}

	/**
	 * Grid of cards.
	 *
	 * @param string[] $cards  Card HTML.
	 * @param string   $label  Accessible list name.
	 * @param string   $extra_class  Extra class.
	 * @return string
	 */
	public static function grid( $cards, $label, $extra_class = '' ) {
		if ( ! $cards ) {
			return '';
		}
		$out = '<ul class="axis-cre-grid ' . esc_attr( $extra_class ) . '" aria-label="' . esc_attr( $label ) . '">';
		foreach ( $cards as $card ) {
			$out .= '<li>' . $card . '</li>'; // Card HTML is built from escaped parts.
		}
		return $out . '</ul>';
	}

	/**
	 * Empty state: what happened and what to do.
	 *
	 * @param string $title        Headline.
	 * @param string $text         Explanation.
	 * @param string $action_url   Optional action URL.
	 * @param string $action_label Optional action label.
	 * @return string
	 */
	public static function empty_state( $title, $text, $action_url = '', $action_label = '' ) {
		$out = '<div class="axis-cre-empty" role="status"><p class="axis-cre-empty__title">' . esc_html( $title ) . '</p><p>' . esc_html( $text ) . '</p>';
		if ( $action_url ) {
			$out .= '<p><a class="wp-element-button axis-cre-button is-secondary" href="' . esc_url( $action_url ) . '">' . esc_html( $action_label ) . '</a></p>';
		}
		return $out . '</div>';
	}

	/**
	 * Previous and next pagination that states the page count.
	 *
	 * @param int    $page  Current page.
	 * @param int    $pages Total pages.
	 * @param string $param Query parameter.
	 * @return string
	 */
	public static function pagination( $page, $pages, $param = 'axis_page' ) {
		if ( $pages < 2 ) {
			return '';
		}
		$out  = '<nav class="axis-cre-pagination" aria-label="' . esc_attr__( 'Pages', 'axis-cre' ) . '">';
		$out .= $page > 1 ? '<a class="axis-cre-button is-secondary" href="' . esc_url( add_query_arg( $param, $page - 1 ) ) . '">' . esc_html__( 'Previous page', 'axis-cre' ) . '</a>' : '<span></span>';
		/* translators: 1: current page, 2: total pages. */
		$out .= '<span class="axis-cre-pagination__count">' . esc_html( sprintf( __( 'Page %1$d of %2$d', 'axis-cre' ), $page, $pages ) ) . '</span>';
		$out .= $page < $pages ? '<a class="axis-cre-button is-secondary" href="' . esc_url( add_query_arg( $param, $page + 1 ) ) . '">' . esc_html__( 'Next page', 'axis-cre' ) . '</a>' : '<span></span>';
		return $out . '</nav>';
	}

	/**
	 * A GET filter form. Works without JavaScript.
	 *
	 * @param array<int, array<string, mixed>> $fields Field specs: name, label, type (select|number|text), options, placeholder.
	 * @param string                           $submit Submit label.
	 * @param string                           $layout row or sidebar.
	 * @param string                           $action Form action URL.
	 * @return string
	 */
	public static function filter_form( $fields, $submit, $layout = 'row', $action = '' ) {
		static $n = 0;
		++$n;
		$out = '<form class="axis-cre-filters is-' . esc_attr( $layout ) . '" method="get" action="' . esc_url( $action ? $action : remove_query_arg( 'axis_page' ) ) . '" role="search">';
		foreach ( $fields as $f ) {
			$id    = 'axis-f' . $n . '-' . $f['name'];
			$value = self::query_var( $f['name'], 'select' === $f['type'] ? 'key' : ( 'text' === $f['type'] ? 'text' : 'float' ) );
			$out  .= '<div class="axis-cre-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $f['label'] ) . '</label>';
			if ( 'select' === $f['type'] ) {
				$out .= '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $f['name'] ) . '">';
				foreach ( $f['options'] as $val => $label ) {
					$out .= '<option value="' . esc_attr( (string) $val ) . '"' . selected( (string) $value, (string) $val, false ) . '>' . esc_html( $label ) . '</option>';
				}
				$out .= '</select>';
			} else {
				$out .= '<input id="' . esc_attr( $id ) . '" name="' . esc_attr( $f['name'] ) . '" type="' . ( 'text' === $f['type'] ? 'search' : 'text' ) . '"' . ( 'text' === $f['type'] ? '' : ' inputmode="decimal"' ) . ' autocomplete="off" value="' . esc_attr( (string) $value ) . '" placeholder="' . esc_attr( isset( $f['placeholder'] ) ? $f['placeholder'] : '' ) . '">';
			}
			$out .= '</div>';
		}
		$out .= '<div class="axis-cre-field is-actions"><button type="submit" class="wp-element-button axis-cre-button">' . esc_html( $submit ) . '</button>';
		$out .= '<a class="axis-cre-reset" href="' . esc_url( remove_query_arg( array_merge( wp_list_pluck( $fields, 'name' ), array( 'axis_page' ) ) ) ) . '">' . esc_html__( 'Clear filters', 'axis-cre' ) . '</a></div>';
		return $out . '</form>';
	}

	/**
	 * Term options for a select: slug => name, with an "All" first option.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param string $all      Label for the empty option.
	 * @return array<string, string>
	 */
	public static function term_options( $taxonomy, $all ) {
		$options = array( '' => $all );
		$terms   = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => true,
			)
		);
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$options[ $t->slug ] = $t->name;
			}
		}
		return $options;
	}

	/**
	 * Market options for a select: ID => title.
	 *
	 * @param string $all Label for the empty option.
	 * @return array<int|string, string>
	 */
	public static function market_options( $all ) {
		$options = array( '' => $all );
		foreach ( Repository::markets() as $m ) {
			$options[ $m['id'] ] = $m['title'];
		}
		return $options;
	}
}
