<?php
/**
 * Field definitions: one source for registration, admin UI, sanitising and REST.
 *
 * @package Axis_CRE
 */

namespace Axis_CRE;

defined( 'ABSPATH' ) || exit;

/**
 * Post meta fields for the AXIS content types.
 */
class Fields {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_meta' ), 6 );
		add_action( 'save_post', array( __CLASS__, 'assign_number' ), 20, 2 );
	}

	/**
	 * Field definitions per post type.
	 *
	 * Types: text, textarea, number, integer, money, percent, boolean, date, post, posts, media, documents, lines.
	 *
	 * @return array<string, array<string, array<string, mixed>>>
	 */
	public static function definitions() {
		static $defs = null;
		if ( null !== $defs ) {
			return $defs;
		}

		$defs = array(
			Post_Types::PROPERTY    => array(
				'number'        => array( 'integer', __( 'Asset number', 'axis-cre' ), 'identity', __( 'Assigned automatically. Shown as Asset 0047.', 'axis-cre' ) ),
				'address'       => array( 'text', __( 'Street address', 'axis-cre' ), 'location' ),
				'city'          => array( 'text', __( 'City', 'axis-cre' ), 'location' ),
				'region'        => array( 'text', __( 'State or region', 'axis-cre' ), 'location', __( 'Short form, for example NY.', 'axis-cre' ) ),
				'postcode'      => array( 'text', __( 'Postcode', 'axis-cre' ), 'location' ),
				'country'       => array( 'text', __( 'Country', 'axis-cre' ), 'location' ),
				'lat'           => array( 'number', __( 'Latitude', 'axis-cre' ), 'location', __( 'Decimal degrees, for example 40.7543.', 'axis-cre' ) ),
				'lng'           => array( 'number', __( 'Longitude', 'axis-cre' ), 'location', __( 'Decimal degrees, for example -73.9787.', 'axis-cre' ) ),
				'market'        => array( 'post', __( 'Market', 'axis-cre' ), 'location', '', Post_Types::MARKET ),
				'asset_class'   => array( 'text', __( 'Asset class', 'axis-cre' ), 'building', __( 'For example Class A, Logistics, 184 units.', 'axis-cre' ) ),
				'size'          => array( 'number', __( 'Building area', 'axis-cre' ), 'building', __( 'In square feet, or square metres if set in Settings.', 'axis-cre' ) ),
				'typical_floor' => array( 'number', __( 'Typical floor', 'axis-cre' ), 'building' ),
				'floors'        => array( 'integer', __( 'Floors', 'axis-cre' ), 'building' ),
				'units'         => array( 'integer', __( 'Units', 'axis-cre' ), 'building' ),
				'year_built'    => array( 'integer', __( 'Year built', 'axis-cre' ), 'building' ),
				'renovated'     => array( 'integer', __( 'Year renovated', 'axis-cre' ), 'building' ),
				'lot_size'      => array( 'number', __( 'Lot size in acres', 'axis-cre' ), 'building' ),
				'parking'       => array( 'integer', __( 'Parking spaces', 'axis-cre' ), 'building' ),
				'zoning'        => array( 'text', __( 'Zoning', 'axis-cre' ), 'building' ),
				'occupancy'     => array( 'percent', __( 'Occupancy', 'axis-cre' ), 'financials', __( 'Percent, for example 92.', 'axis-cre' ) ),
				'sale_price'    => array( 'money', __( 'Asking price', 'axis-cre' ), 'financials', __( 'Whole currency units, for example 84500000.', 'axis-cre' ) ),
				'lease_rate'    => array( 'money', __( 'Lease rate per area unit per year', 'axis-cre' ), 'financials' ),
				'cap_rate'      => array( 'percent', __( 'Cap rate', 'axis-cre' ), 'financials', __( 'Percent, for example 6.2.', 'axis-cre' ) ),
				'noi'           => array( 'money', __( 'Net operating income', 'axis-cre' ), 'financials' ),
				'tenants'       => array( 'integer', __( 'Tenants', 'axis-cre' ), 'financials' ),
				'featured'      => array( 'boolean', __( 'Featured asset', 'axis-cre' ), 'listing' ),
				'listed'        => array( 'date', __( 'Date listed', 'axis-cre' ), 'listing' ),
				'gallery'       => array( 'media', __( 'Photos and plans', 'axis-cre' ), 'media', __( 'The first image leads the gallery. Image captions are shown under each photo.', 'axis-cre' ) ),
				'documents'     => array( 'documents', __( 'Documents', 'axis-cre' ), 'media', __( 'Tick "Gated" for documents that need a confidentiality agreement.', 'axis-cre' ) ),
				'experts'       => array( 'posts', __( 'Listing experts', 'axis-cre' ), 'listing', __( 'The first expert is shown as the listing broker.', 'axis-cre' ), Post_Types::EXPERT ),
			),
			Post_Types::MARKET      => array(
				'number'      => array( 'integer', __( 'Market number', 'axis-cre' ), 'identity', __( 'Assigned automatically. Shown as Market 01.', 'axis-cre' ) ),
				'country'     => array( 'text', __( 'Country', 'axis-cre' ), 'location' ),
				'region'      => array( 'text', __( 'Region', 'axis-cre' ), 'location' ),
				'lat'         => array( 'number', __( 'Latitude', 'axis-cre' ), 'location' ),
				'lng'         => array( 'number', __( 'Longitude', 'axis-cre' ), 'location' ),
				'quarter'     => array( 'text', __( 'Data period', 'axis-cre' ), 'data', __( 'For example Q2 2026.', 'axis-cre' ) ),
				'sectors'     => array( 'lines', __( 'Figures by property type', 'axis-cre' ), 'data', __( 'One line per property type: name, asking rent, rent unit, vacancy %, change in points. Example: Office, 78.40, sf, 14.2, 0.8', 'axis-cre' ) ),
				'submarkets'  => array( 'lines', __( 'Submarkets', 'axis-cre' ), 'data', __( 'One line per submarket: name, vacancy %, latitude, longitude. Example: Midtown, 14.2, 40.7549, -73.9840', 'axis-cre' ) ),
				'rent_trend'  => array( 'lines', __( 'Asking rent trend', 'axis-cre' ), 'data', __( 'One line per period: label, value. Example: Q2 2026, 78.40', 'axis-cre' ) ),
				'trend_label' => array( 'text', __( 'Trend chart title', 'axis-cre' ), 'data', __( 'For example Midtown average asking rent.', 'axis-cre' ) ),
				'volume'      => array( 'money', __( 'Capital volume, latest half year', 'axis-cre' ), 'data' ),
				'since_year'  => array( 'integer', __( 'Count transactions since', 'axis-cre' ), 'data', __( 'Year used in the market summary line.', 'axis-cre' ) ),
			),
			Post_Types::TRANSACTION => array(
				'number'       => array( 'integer', __( 'Transaction number', 'axis-cre' ), 'identity', __( 'Assigned automatically. Shown as Transaction 018.', 'axis-cre' ) ),
				'value'        => array( 'money', __( 'Transaction value', 'axis-cre' ), 'deal' ),
				'year'         => array( 'integer', __( 'Year closed', 'axis-cre' ), 'deal' ),
				'property'     => array( 'post', __( 'Property', 'axis-cre' ), 'deal', '', Post_Types::PROPERTY ),
				'market'       => array( 'post', __( 'Market', 'axis-cre' ), 'deal', '', Post_Types::MARKET ),
				'city'         => array( 'text', __( 'City', 'axis-cre' ), 'deal', __( 'For example Chicago, IL.', 'axis-cre' ) ),
				'client'       => array( 'text', __( 'Client', 'axis-cre' ), 'deal', __( 'Describe the client if you cannot name them, for example Institutional investor.', 'axis-cre' ) ),
				'role'         => array( 'text', __( 'Our role', 'axis-cre' ), 'deal' ),
				'story_asset'  => array( 'textarea', __( 'The asset', 'axis-cre' ), 'story' ),
				'story_deal'   => array( 'textarea', __( 'The transaction', 'axis-cre' ), 'story' ),
				'story_plan'   => array( 'textarea', __( 'The strategy', 'axis-cre' ), 'story' ),
				'story_result' => array( 'textarea', __( 'The outcome', 'axis-cre' ), 'story' ),
				'experts'      => array( 'posts', __( 'Team', 'axis-cre' ), 'deal', '', Post_Types::EXPERT ),
			),
			Post_Types::EXPERT      => array(
				'number'      => array( 'integer', __( 'Expert number', 'axis-cre' ), 'identity', __( 'Assigned automatically. Shown as Expert 017.', 'axis-cre' ) ),
				'title'       => array( 'text', __( 'Job title', 'axis-cre' ), 'profile' ),
				'markets'     => array( 'posts', __( 'Markets', 'axis-cre' ), 'profile', '', Post_Types::MARKET ),
				'specialties' => array( 'text', __( 'Specialties', 'axis-cre' ), 'profile', __( 'Comma separated, for example Investment sales, Recapitalisations.', 'axis-cre' ) ),
				'phone'       => array( 'text', __( 'Phone', 'axis-cre' ), 'contact' ),
				'email'       => array( 'email', __( 'Email', 'axis-cre' ), 'contact' ),
				'linkedin'    => array( 'url', __( 'LinkedIn URL', 'axis-cre' ), 'contact' ),
				'since'       => array( 'integer', __( 'With the firm since', 'axis-cre' ), 'profile', __( 'Year.', 'axis-cre' ) ),
				'deals'       => array( 'integer', __( 'Transactions to date', 'axis-cre' ), 'record', __( 'Leave empty to count linked transactions.', 'axis-cre' ) ),
				'volume'      => array( 'money', __( 'Volume to date', 'axis-cre' ), 'record', __( 'Leave empty to add up linked transactions.', 'axis-cre' ) ),
			),
			Post_Types::RESEARCH    => array(
				'number'  => array( 'integer', __( 'Research number', 'axis-cre' ), 'identity', __( 'Assigned automatically. Shown as Research 026.', 'axis-cre' ) ),
				'markets' => array( 'posts', __( 'Markets covered', 'axis-cre' ), 'report', '', Post_Types::MARKET ),
				'pages'   => array( 'integer', __( 'Pages', 'axis-cre' ), 'report' ),
				'pdf'     => array( 'media', __( 'Report PDF', 'axis-cre' ), 'report' ),
				'data'    => array( 'media', __( 'Data file (CSV)', 'axis-cre' ), 'report' ),
				'figures' => array( 'lines', __( 'Headline figures', 'axis-cre' ), 'report', __( 'One per line: value, label, note. Example: 14.2%, Midtown vacancy, Up 0.8 pts on a year', 'axis-cre' ) ),
				'experts' => array( 'posts', __( 'Authors', 'axis-cre' ), 'report', '', Post_Types::EXPERT ),
			),
		);

		foreach ( $defs as $type => $fields ) {
			foreach ( $fields as $key => $f ) {
				$defs[ $type ][ $key ] = array(
					'type'   => $f[0],
					'label'  => $f[1],
					'group'  => $f[2],
					'help'   => isset( $f[3] ) ? $f[3] : '',
					'target' => isset( $f[4] ) ? $f[4] : '',
				);
			}
		}

		return $defs;
	}

	/**
	 * Meta key for a field.
	 *
	 * @param string $key Field key.
	 * @return string
	 */
	public static function meta_key( $key ) {
		return '_axis_' . $key;
	}

	/**
	 * Read a field.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $key     Field key.
	 * @return mixed
	 */
	public static function get( $post_id, $key ) {
		return get_post_meta( $post_id, self::meta_key( $key ), true );
	}

	/**
	 * Register meta for REST and the editor.
	 */
	public static function register_meta() {
		foreach ( self::definitions() as $type => $fields ) {
			foreach ( $fields as $key => $field ) {
				$schema = self::rest_schema( $field['type'] );
				register_post_meta(
					$type,
					self::meta_key( $key ),
					array(
						'type'              => $schema['type'],
						'single'            => true,
						'description'       => $field['label'],
						'sanitize_callback' => function ( $value ) use ( $field ) {
							return Fields::sanitize( $field['type'], $value );
						},
						'auth_callback'     => function ( $allowed, $meta_key, $post_id ) {
							return current_user_can( 'edit_post', $post_id );
						},
						'show_in_rest'      => array( 'schema' => $schema ),
					)
				);
			}
		}
	}

	/**
	 * REST schema for a field type.
	 *
	 * @param string $type Field type.
	 * @return array<string, mixed>
	 */
	private static function rest_schema( $type ) {
		switch ( $type ) {
			case 'number':
			case 'money':
			case 'percent':
				return array( 'type' => 'number' );
			case 'integer':
			case 'post':
				return array( 'type' => 'integer' );
			case 'boolean':
				return array( 'type' => 'boolean' );
			case 'posts':
			case 'media':
				return array(
					'type'  => 'array',
					'items' => array( 'type' => 'integer' ),
				);
			case 'documents':
				return array(
					'type'  => 'array',
					'items' => array(
						'type'       => 'object',
						'properties' => array(
							'id'    => array( 'type' => 'integer' ),
							'gated' => array( 'type' => 'boolean' ),
						),
					),
				);
			default:
				return array( 'type' => 'string' );
		}
	}

	/**
	 * Sanitise a value for a field type.
	 *
	 * @param string $type  Field type.
	 * @param mixed  $value Raw value.
	 * @return mixed
	 */
	public static function sanitize( $type, $value ) {
		switch ( $type ) {
			case 'number':
			case 'money':
			case 'percent':
				if ( '' === $value || null === $value ) {
					return '';
				}
				$value = is_string( $value ) ? str_replace( array( ',', '$', '%', ' ' ), '', $value ) : $value;
				return is_numeric( $value ) ? (float) $value : '';
			case 'integer':
			case 'post':
				return ( '' === $value || null === $value ) ? '' : absint( $value );
			case 'boolean':
				return (bool) $value;
			case 'posts':
			case 'media':
				if ( is_string( $value ) ) {
					$value = explode( ',', $value );
				}
				return array_values( array_filter( array_map( 'absint', (array) $value ) ) );
			case 'documents':
				$out = array();
				foreach ( (array) $value as $doc ) {
					$id = isset( $doc['id'] ) ? absint( $doc['id'] ) : 0;
					if ( $id ) {
						$out[] = array(
							'id'    => $id,
							'gated' => ! empty( $doc['gated'] ),
						);
					}
				}
				return $out;
			case 'date':
				$value = sanitize_text_field( (string) $value );
				return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ? $value : '';
			case 'email':
				return sanitize_email( (string) $value );
			case 'url':
				return esc_url_raw( (string) $value );
			case 'textarea':
			case 'lines':
				return sanitize_textarea_field( (string) $value );
			default:
				return sanitize_text_field( (string) $value );
		}
	}

	/**
	 * Give new items the next sequential number (Asset 0047, Market 01).
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 */
	public static function assign_number( $post_id, $post ) {
		if ( wp_is_post_revision( $post_id ) || ! in_array( $post->post_type, Post_Types::all(), true ) || 'auto-draft' === $post->post_status ) {
			return;
		}
		if ( self::get( $post_id, 'number' ) ) {
			return;
		}
		$option = 'axis_cre_counter_' . $post->post_type;
		$next   = (int) get_option( $option, 0 ) + 1;
		update_option( $option, $next, false );
		update_post_meta( $post_id, self::meta_key( 'number' ), $next );
	}

	/**
	 * Parse a "lines" field into rows of trimmed columns.
	 *
	 * @param string $text Raw text.
	 * @return array<int, string[]>
	 */
	public static function parse_lines( $text ) {
		$rows = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			$rows[] = array_map( 'trim', str_getcsv( $line, ',', '"', '\\' ) );
		}
		return $rows;
	}
}
