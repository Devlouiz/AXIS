<?php
/**
 * Plugin Name:       AXIS CRE
 * Plugin URI:        https://axis.example/cre
 * Description:       Properties, markets, transactions, experts and research for commercial real estate sites, with a synced map and search. Designed for the AXIS theme; works with any block theme.
 * Version:           0.2.1
 * Requires at least: 6.6
 * Requires PHP:      7.4
 * Author:            Louis Okechukwu
 * Author URI:        https://github.com/Devlouiz
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       axis-cre
 * Domain Path:       /languages
 *
 * @package Axis_CRE
 */

defined( 'ABSPATH' ) || exit;

define( 'AXIS_CRE_VERSION', '0.2.1' );
define( 'AXIS_CRE_FILE', __FILE__ );
define( 'AXIS_CRE_DIR', plugin_dir_path( __FILE__ ) );
define( 'AXIS_CRE_URL', plugin_dir_url( __FILE__ ) );

require_once AXIS_CRE_DIR . 'includes/class-fields.php';
require_once AXIS_CRE_DIR . 'includes/class-format.php';
require_once AXIS_CRE_DIR . 'includes/class-post-types.php';
require_once AXIS_CRE_DIR . 'includes/class-repository.php';
require_once AXIS_CRE_DIR . 'includes/class-render.php';
require_once AXIS_CRE_DIR . 'includes/class-charts.php';
require_once AXIS_CRE_DIR . 'includes/class-map.php';
require_once AXIS_CRE_DIR . 'includes/class-related.php';
require_once AXIS_CRE_DIR . 'includes/class-bindings.php';
require_once AXIS_CRE_DIR . 'includes/class-blocks.php';
require_once AXIS_CRE_DIR . 'includes/class-rest.php';
require_once AXIS_CRE_DIR . 'includes/class-schema.php';
require_once AXIS_CRE_DIR . 'includes/class-admin.php';
require_once AXIS_CRE_DIR . 'includes/class-sample.php';

Axis_CRE\Post_Types::init();
Axis_CRE\Fields::init();
Axis_CRE\Bindings::init();
Axis_CRE\Blocks::init();
Axis_CRE\Rest::init();
Axis_CRE\Schema::init();
Axis_CRE\Admin::init();
Axis_CRE\Sample::init();

register_activation_hook( __FILE__, array( 'Axis_CRE\Post_Types', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Axis_CRE\Post_Types', 'deactivate' ) );
