<?php
/**
 * Uninstall: remove settings and counters. Content stays, so nothing is lost by accident.
 *
 * To remove sample content too, use Tools > AXIS sample content before uninstalling.
 *
 * @package Axis_CRE
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'axis_cre_settings' );
foreach ( array( 'axis_property', 'axis_market', 'axis_transaction', 'axis_expert', 'axis_research' ) as $axis_cre_type ) {
	delete_option( 'axis_cre_counter_' . $axis_cre_type );
}
