=== AXIS CRE ===
Contributors: devlouiz
Tags: real estate, commercial real estate, property listings, map, block
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.2.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Properties, markets, transactions, experts and research for commercial real estate sites, with a synced map and search.

== Description ==

AXIS CRE adds the content model and blocks behind a commercial real estate advisory site. It is built for the AXIS block theme and works with any block theme.

**Content types**

* Properties, with location, building, financial and listing fields, photos and plans, and open or gated documents.
* Markets, with figures by property type, submarkets and a rent trend.
* Transactions, told as asset, transaction, strategy and outcome.
* Experts, with markets, specialties and a track record counted from their transactions.
* Research, with headline figures, a PDF and a data file.

Each item gets a sequential identifier such as Asset 0047 or Transaction 018.

**Blocks**

Property search, property results, property metrics, property specifications, property gallery, property documents, related listings, related assets, shortlist, listing tools, market snapshot, market map, market explorer, transaction data, expert profile and research index. All are rendered on the server and work without JavaScript.

**Listing cards**

Photo first, with status and price on the photo, a photo counter you can step through or swipe, the three figures that decide a commercial deal and the listing broker. Visitors can save listings and add up to four to compare; both lists stay in their browser, a tray at the foot of the screen opens the comparison, and the Listing tools block puts the counts in the site header.

**Related listings**

A query block that reads the post it sits on. On a property it finds similar assets by market, property type, listing type, broker or team, a price or rent band, a size band and a distance radius. On a market it lists that market's assets, on an expert their listings, and on a transaction or report the assets in the same market. When too few listings meet every rule, rules are relaxed one at a time and the strictest matches are shown first. Order by best match, nearest or newest, as a grid, list or carousel.

**Market explorer**

Filters, a survey map and the results list stay in sync. When results span several markets the map shows one pin per market; choosing a market narrows the results and fits the map to its assets. Pins and cards select each other. The map pans with a pointer or the arrow keys and zooms with buttons, plus and minus, or Ctrl and the scroll wheel. Without JavaScript the filters submit as a normal form and the list is complete.

**Survey maps**

Maps are drawn from each item's coordinates on the theme's grid. They need no map tiles, API keys or third-party requests, so nothing about your visitors leaves your site. Positions are to scale; streets are not drawn. Every map has an equivalent list. Developers can replace map markup through the `axis_cre_map_html` filter.

**Accessibility**

Charts come with a table of the same numbers. Galleries and tabs use real buttons with keyboard support. Filters are labelled, results counts are announced, and empty states say what to do next.

**Structured data**

Property, market, expert, research and transaction pages print JSON-LD. Turn it off with `add_filter( 'axis_cre_schema_enabled', '__return_false' );` if an SEO plugin handles it.

== Installation ==

1. Upload the plugin and activate it.
2. Go to Settings > AXIS CRE to choose the currency symbol, area unit and shortlist page.
3. Optional: go to Tools > AXIS sample content and create sample content, or run `wp axis-cre seed`.

== Frequently Asked Questions ==

= Does it need the AXIS theme? =

No. Blocks read the active theme's colour, spacing and type presets and fall back to their own when a preset is missing. With AXIS, the templates for every content type are already designed.

= Can I use a tile map instead of the survey map? =

Yes, for the market and property maps: filter `axis_cre_map_html` and return your own markup. The explorer keeps the survey map so that filtering, panning and selection stay in sync without a third-party service.

= How do I remove the sample content? =

Tools > AXIS sample content > Remove sample content, or `wp axis-cre remove-sample`. Only items created as samples are removed.

= What happens on uninstall? =

Settings and identifier counters are deleted. Your properties, markets and other content stay in the database.

== Changelog ==

= 0.2.1 =
* Fixed: PHP 7.4 compatibility of the sample floor-plan drawing.
* Fixed: deactivating the plugin now removes its URLs straight away.
* Faster: listing, market, expert and research pages load posts, fields, terms and images in a few queries instead of one per item (about half the database queries).
* Accessibility: heading order on archives and the shortlist, contrast in the dark style, focus rings on the hero search, market pins named by their visible text, native section regions for tables and the gallery.
* The REST properties endpoint accepts the location search and rent filters.
* The shortlist page is kept out of search engines and the sitemap.
* Sample content adds a main menu and gives every page a single main heading.

= 0.2.0 =
* New listing card: photo first, status and price on the photo, photos to step through or swipe, save and compare, three key figures and the listing broker.
* New: Related listings block with market, type, listing, broker, price, size and distance rules, relaxed in order when matches are few.
* New: Shortlist block with saved listings and a side-by-side comparison of up to four, and a compare tray.
* New: Listing tools block for saved and compare counters in the header.
* Property search: hero layout with For sale and For lease tabs, location search and size and price bands.
* Restyled every block to match AXIS 0.2: soft cards, rounded controls, teal map pins.
* Sample content uses photographs, a shortlist page and full-width pages for the theme's page patterns.

= 0.1.0 =
* First release.
